from __future__ import annotations

import copy

from conftest import DIFF_RUNNER, FakeLLM, base_run
from qualagent.checks import run_checks
from qualagent.models import SemanticOut
from qualagent.review import review_run


def by_id(checks):
    return {c.id: c for c in checks}


def test_a_conformant_run_is_approved(cfg):
    checks, stats, files = run_checks(base_run(), cfg)
    c = by_id(checks)
    assert all(x.severity in {"ok", "info"} for x in checks), [(x.id, x.severity, x.detail) for x in checks if x.severity not in {"ok", "info"}]
    assert c["planned_files"].detail.startswith("Les 2 fichier(s) du plan, et seulement eux")
    assert (stats.files, stats.added, stats.removed, stats.build_rounds, stats.tests_passed, stats.tests_total) == (2, 4, 1, 1, 49, 49)
    assert set(files) == {"EasiPlayer/core/runner.cpp", "EasiPlayer/core/runner.h"}


def test_planned_file_not_touched_and_unplanned_file_touched_both_fail(cfg):
    r = base_run()
    r["dev_report"]["diff"] = DIFF_RUNNER.split("diff --git a/EasiPlayer/core/runner.h")[0]                 # le .h prévu n'a pas été modifié
    c = by_id(run_checks(r, cfg)[0])
    assert c["planned_files"].severity == "fail" and "EasiPlayer/core/runner.h" in c["planned_files"].detail
    r = base_run()
    r["dev_report"]["diff"] += DIFF_RUNNER.replace("runner.cpp", "other.cpp").split("diff --git a/EasiPlayer/core/runner.h")[0]
    c = by_id(run_checks(r, cfg)[0])
    assert c["planned_files"].severity == "fail" and "other.cpp" in c["planned_files"].detail and "HORS plan" in c["planned_files"].detail


def test_no_diff_at_all_is_a_failure(cfg):
    r = base_run()
    r["dev_report"]["diff"] = ""
    assert by_id(run_checks(r, cfg)[0])["diff_present"].severity == "fail"


def test_forbidden_zone_is_rechecked_on_the_real_diff(cfg):
    r = base_run()
    r["dev_report"]["diff"] += "diff --git a/build_player/x.cpp b/build_player/x.cpp\n--- a/build_player/x.cpp\n+++ b/build_player/x.cpp\n@@ -1 +1 @@\n-a\n+b\n"
    assert by_id(run_checks(r, cfg)[0])["forbidden_zones"].severity == "fail"


def test_planned_symbols_must_show_up_in_the_diff(cfg):
    r = base_run()
    r["plan"]["plan"]["files_to_modify"][0]["symbols"] = ["Runner::abort", "Runner::neverTouched"]
    c = by_id(run_checks(r, cfg)[0])["planned_symbols"]
    assert c.severity == "warn" and "neverTouched" in c.detail and "abort" not in " ".join(c.evidence)


def test_api_surface_change_is_flagged_unless_announced(cfg):
    r = base_run()
    r["dev_report"]["diff"] = r["dev_report"]["diff"].replace("+    bool m_aborted;", "+    bool m_aborted;\n+    Q_INVOKABLE void stopNow();")
    assert by_id(run_checks(r, cfg)[0])["api_surface"].severity == "warn"
    r["plan"]["plan"]["risks"] = [{"description": "script API", "area": "script_api", "severity": "medium"}]
    assert by_id(run_checks(r, cfg)[0])["api_surface"].severity == "info"


def test_core_files_need_a_recorded_human_approval(cfg):
    r = base_run()
    r["plan"]["plan"]["files_to_modify"][0]["path"] = "EasiPlayer/src/TestCheckValue.cpp"
    r["dev_report"]["diff"] = DIFF_RUNNER.replace("EasiPlayer/core/runner.cpp", "EasiPlayer/src/TestCheckValue.cpp")
    assert by_id(run_checks(r, cfg)[0])["core_gate"].severity == "fail"
    r["events"].append({"step": "gate", "detail": "plan approuvé par l'humain : ok"})
    assert by_id(run_checks(r, cfg)[0])["core_gate"].severity == "ok"


def test_build_tests_and_commit_reservations(cfg):
    r = base_run()
    r["loop_report"]["rounds"] = [{}, {}, {}]
    r["qa_report"].update(scope="targeted", selection={"tests": [], "unknown_suggestions": ["tst_NOPE"]})
    r["dev_report"]["commit_subject"] = "[EAP-TODO][Sequencer]Stop button"
    c = by_id(run_checks(r, cfg)[0])
    assert c["build"].severity == "warn" and "3 tours" in c["build"].detail
    assert c["tests"].severity == "warn" and "suite complète n'a PAS tourné" in c["tests"].detail
    assert c["plan_tests"].severity == "warn" and "tst_NOPE" in c["plan_tests"].detail
    assert c["commit"].severity == "warn" and "EAP-TODO" in c["commit"].detail


async def test_verdicts_follow_the_checks(cfg):
    assert (await review_run(base_run(), cfg, None)).verdict == "concerns"                          # tout est vert, mais l'intention du plan n'a PAS été relue
    r = base_run()
    r["dev_report"]["diff"] = ""
    rep = await review_run(r, cfg, None)
    assert rep.verdict == "reject" and "Une modification existe" in rep.concerns[0]


async def test_without_llm_the_report_says_the_intent_was_not_reviewed(cfg):
    rep = await review_run(base_run(), cfg, None)
    assert not rep.semantic.performed and "aucun LLM" in rep.semantic.skipped_reason and "intention du plan NON relue" in rep.summary


def out(findings, unplanned=(), concerns=()):
    return SemanticOut(findings=[SemanticOut.F(**f) for f in findings], unplanned_changes=[SemanticOut.U(**u) for u in unplanned], concerns=list(concerns))


GOOD = [{"planned_path": "EasiPlayer/core/runner.cpp", "status": "implemented", "evidence_quote": "if (!m_aborted)", "note": "guard added"},
        {"planned_path": "EasiPlayer/core/runner.h", "status": "implemented", "evidence_quote": "bool m_aborted;", "note": "declared"}]


async def test_semantic_review_with_real_quotes_approves(cfg):
    llm = FakeLLM(out(GOOD))
    rep = await review_run(base_run(), cfg, llm)
    assert rep.verdict == "approve" and rep.semantic.performed and all(f.verified for f in rep.semantic.findings)
    assert "Guard the emit with m_aborted" in llm.prompts[0] and "if (!m_aborted)" in llm.prompts[0] and "Refactoring of start()" in llm.prompts[0]      # plan + diff réel dans le prompt


async def test_fabricated_evidence_is_discarded_not_believed(cfg):
    fake = [{"planned_path": "EasiPlayer/core/runner.cpp", "status": "implemented", "evidence_quote": "std::lock_guard<std::mutex> g(m_mutex);", "note": "locked"},
            GOOD[1]]
    rep = await review_run(base_run(), cfg, FakeLLM(out(fake)))
    f = next(x for x in rep.semantic.findings if x.planned_path.endswith("runner.cpp"))
    assert f.status == "unclear" and not f.verified and rep.semantic.discarded and rep.verdict == "concerns"        # une citation inventée ne valide RIEN
    assert any("Non vérifié" in c for c in rep.concerns)


async def test_llm_cannot_reject_a_file_that_was_actually_modified(cfg):
    bad = [{"planned_path": "EasiPlayer/core/runner.cpp", "status": "missing", "evidence_quote": "", "note": "nothing done"}, GOOD[1]]
    rep = await review_run(base_run(), cfg, FakeLLM(out(bad)))
    assert rep.verdict != "reject" and any("missing" in d for d in rep.semantic.discarded)


async def test_unplanned_change_needs_a_real_quote(cfg):
    real = out(GOOD, unplanned=[{"path": "EasiPlayer/core/runner.cpp", "evidence_quote": "m_aborted = true;", "note": "extra state change"}])
    rep = await review_run(base_run(), cfg, FakeLLM(real))
    assert rep.verdict == "concerns" and any("hors plan" in c for c in rep.concerns)
    fake = out(GOOD, unplanned=[{"path": "x.cpp", "evidence_quote": "delete everything();", "note": "invented"}])
    rep = await review_run(base_run(), cfg, FakeLLM(fake))
    assert rep.verdict == "approve" and rep.semantic.discarded


async def test_llm_failure_never_blocks_the_review(cfg):
    rep = await review_run(base_run(), cfg, FakeLLM(RuntimeError("serveur LLM arrêté")))
    assert not rep.semantic.performed and "relecture LLM impossible" in rep.semantic.skipped_reason and rep.verdict in {"concerns", "approve"}
