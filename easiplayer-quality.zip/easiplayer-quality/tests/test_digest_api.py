from __future__ import annotations

import json
from datetime import datetime

from fastapi.testclient import TestClient

from conftest import DIFF_RUNNER, FakeLLM, base_run
from qualagent.api import create_app
from qualagent.digest import build_digest, write_digest
from qualagent.runs import parse_ts

NOW = datetime.strptime("2026-11-24T07:00:00+0100", "%Y-%m-%dT%H:%M:%S%z")


def put(cfg, run):
    d = cfg.runs_dir / run["run_id"]
    d.mkdir(parents=True, exist_ok=True)
    (d / "run.json").write_text(json.dumps(run))


def world(cfg):
    # 1. correctif prêt, attend la validation finale (commit à renseigner)
    put(cfg, base_run(run_id="a1", ticket_id="1739", dev_report={**base_run()["dev_report"], "commit_subject": "[EAP-TODO][Sequencer]Stop button"}))
    # 2. validé par l'humain : reste la fusion
    r = base_run(run_id="b2", ticket_id="1698", state="done", status="ready_for_merge", gate=None, eap_ref="EAP-12616", updated="2026-11-24T02:00:00+0100")
    r["plan"]["ticket"]["title"] = "Plugin API answers late"
    put(cfg, r)
    # 3. arrêté : tests Squish en échec malgré 2 corrections
    r = base_run(run_id="c3", ticket_id="2312", state="done", status="qa_failed", gate=None, reason="1 nouvel échec", test_fixes=2, replans=1, updated="2026-11-24T04:00:00+0100")
    r["plan"]["ticket"]["title"] = "Script loading order"
    r["qa_report"] = {"status": "failed", "summary": {"total": 49, "passed": 48, "failed": 1}, "briefs": [{"test": "tst_STD-EAP-JAVA_SCRIPT_USE-00001", "failed": {"message": "ReferenceError: base is not defined"}}]}
    put(cfg, r)
    # 4. plan sensible en attente (même ancien : toujours listé)
    r = base_run(run_id="d4", ticket_id="1900", state="waiting_human", gate={"gate": "plan_review", "reasons": ["Le plan touche le noyau critique : Information.cpp"], "files": ["EasiPlayer/src/Information.cpp"]},
                 updated="2026-11-20T09:00:00+0100", dev_report={}, loop_report={}, qa_report={})
    r["plan"]["ticket"]["title"] = "Min/max limits"
    put(cfg, r)
    # 5. ancien et terminé : hors fenêtre
    put(cfg, base_run(run_id="e5", ticket_id="1500", state="done", status="rejected_by_human", gate=None, updated="2026-11-19T10:00:00+0100"))


def test_morning_report_tells_what_happened_what_changed_and_what_to_do(cfg):
    world(cfg)
    md, data = build_digest(cfg, now=NOW, since=parse_ts("2026-11-23T07:00:00+0100"))
    assert md.startswith("# Rapport du matin — mardi 24 novembre 2026")
    assert data["counts"] == {"final_wait": 1, "plan_wait": 1, "ready": 1, "stopped": 1, "running": 0}                  # e5 est hors fenêtre
    assert "4 ticket(s)" in md and "1 attend ta validation finale" in md and "1 arrêté" in md
    # ce qui était voulu / ce qui a été fait / vérifié
    assert "abort() emits finished even when the run already finished" in md
    assert "| `EasiPlayer/core/runner.cpp` | 3 | 1 |" in md and "| `EasiPlayer/core/runner.h` | 1 | 0 |" in md                     # le diff réel, par fichier
    assert "tests Squish : **passed** — 49/49 réussis ; tests choisis pour cette modification : tst_STD-EAP-SEQUENCER-00002" in md
    assert "compilation : réussie (1 tour)" in md
    # à faire par toi, avec les commandes exactes
    acts = data["actions"]
    assert any("POST /runs/a1/decision" in a for a in acts) and any("POST /runs/d4/decision" in a and "plan" in a for a in acts)
    assert any("git merge --no-ff fix/1739" in md.split("## ✅ Validés")[1] for _ in [0])
    assert any("Renseigner la vraie référence EAP" in a and "#1739" in a for a in acts)                            # commit [EAP-TODO]
    # arrêté : pourquoi + test en échec + quoi faire
    stopped = md.split("## ❌ Arrêtés")[1]
    assert "des tests Squish échouent malgré les corrections" in stopped and "ReferenceError: base is not defined" in stopped and "2 correction(s) après échec de test, 1 nouveau(x) plan(s)" in stopped
    assert "Le plan touche le noyau critique : Information.cpp" in md.split("## ⏳ Plans en attente")[1]
    assert "## Chiffres" in md and "exécution(s) de test Squish" in md


def test_quality_verdict_shown_and_recomputed_when_the_agent_was_not_wired(cfg):
    r = base_run(run_id="q1", quality={"verdict": "concerns", "concerns": ["Taille de la modification : 400 lignes"], "summary": "x"})
    put(cfg, r)
    md, _ = build_digest(cfg, now=NOW, since=parse_ts("2026-11-23T07:00:00+0100"))
    assert "contrôle qualité (agent qualité) : **⚠️ conforme avec réserves**" in md and "Taille de la modification : 400 lignes" in md
    cfg2 = cfg.model_copy(update={"runs_dir": cfg.runs_dir.parent / "runs2"})
    put(cfg2, base_run(run_id="q2"))
    md, _ = build_digest(cfg2, now=NOW, since=parse_ts("2026-11-23T07:00:00+0100"))
    assert "contrôles automatiques simples, agent qualité non branché" in md


def test_window_advances_after_each_report_but_not_for_on_demand_ones(cfg):
    world(cfg)
    md, data = build_digest(cfg, now=NOW)                                       # sans « depuis » : 24 h avant NOW
    assert data["counts"]["ready"] == 1 and data["counts"]["stopped"] == 1
    write_digest(cfg, md, data, advance=False)
    assert not (cfg.work_dir / "reports" / "last_digest.json").exists()
    write_digest(cfg, md, data, advance=True)
    assert (cfg.work_dir / "reports" / "morning-2026-11-24.md").exists() and (cfg.work_dir / "reports" / "latest.md").read_text() == md
    later = datetime.strptime("2026-11-25T07:00:00+0100", "%Y-%m-%dT%H:%M:%S%z")
    md2, data2 = build_digest(cfg, now=later)                                   # depuis le dernier rapport : seuls les runs en attente d'un humain restent
    assert data2["counts"] == {"final_wait": 1, "plan_wait": 1, "ready": 0, "stopped": 0, "running": 0}


def test_empty_and_corrupt_data(cfg):
    md, data = build_digest(cfg, now=NOW)
    assert "Aucune activité depuis le dernier rapport." in md and "dossier des runs introuvable" in md
    cfg.runs_dir.mkdir(parents=True)
    (cfg.runs_dir / "bad").mkdir()
    (cfg.runs_dir / "bad" / "run.json").write_text("{pas du json")
    md, data = build_digest(cfg, now=NOW)
    assert "run.json illisible" in md and data["warnings"]


def test_api_review_and_digest_with_token(cfg):
    cfg = cfg.model_copy(update={"api_token": "t"})
    world(cfg)
    h = {"Authorization": "Bearer t"}
    with TestClient(create_app(cfg, llm=None), headers=h) as c:
        assert TestClient(c.app).get("/health").status_code == 401
        assert c.get("/health").json() == {"ok": True, "agent": "quality", "version": "0.1.0", "llm": False}
        rid = c.post("/reviews", json={"run": base_run()}).json()["review_id"]
        import time
        for _ in range(100):
            st = c.get(f"/reviews/{rid}", params={"full": True}).json()
            if st["state"] == "done":
                break
            time.sleep(0.05)
        assert st["verdict"] == "concerns" and st["report"]["stats"]["files"] == 2 and "Contrôle qualité" in c.get(f"/reviews/{rid}/report").text
        r = c.post("/digests", json={"hours": 24 * 30, "advance": False}).json()
        assert "Rapport du matin" in r["markdown"] and (cfg.work_dir / "reports" / "latest.md").exists()
        assert "Rapport du matin" in c.get("/digests/latest").text
        assert c.get("/reviews/inconnu").status_code == 404


def test_cli_digest_writes_the_report(cfg, monkeypatch, capsys, tmp_path):
    import sys
    from qualagent.cli import main
    world(cfg)
    monkeypatch.setattr(sys, "argv", ["qualagent", "digest", "--runs-dir", str(cfg.runs_dir), "--out", str(tmp_path / "out"), "--hours", "720", "--print"])
    main()
    out = capsys.readouterr().out
    assert "Rapport du matin" in out and (tmp_path / "out" / "reports" / "latest.md").exists()
