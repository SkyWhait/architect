"""Le rapport du matin lit les run.json PRODUITS par le vrai orchestrateur (ignoré si `orchagent` n'est pas installé) : le contrat tient des deux côtés."""
from __future__ import annotations

import asyncio

import pytest

from conftest import DIFF_RUNNER
from qualagent.digest import build_digest
from qualagent.config import Settings

orch = pytest.importorskip("orchagent.service")


class Ag:
    def __init__(self, ans):
        self.ans = ans

    async def plan(self, body):
        return self.ans["plan"]

    async def apply(self, plan, **kw):
        return self.ans["dev"]

    async def loop(self, dev_report, **kw):
        return self.ans["loop"]

    async def run(self, ticket_id, build, change, focus_tests):
        return self.ans["qa"]


async def test_digest_from_a_real_orchestrator_run(tmp_path):
    from conftest import base_run
    from langgraph.checkpoint.memory import MemorySaver
    from orchagent.clients import Agents
    from orchagent.config import Settings as OS
    from orchagent.models import StartRequest
    r = base_run()
    ans = {"plan": r["plan"], "dev": {**r["dev_report"], "build_hints": {"changed_files": [], "squish_tests": []}}, "loop": r["loop_report"], "qa": r["qa_report"]}
    a = Ag(ans)
    ocfg = OS(work_dir=tmp_path / "orch", poll_interval_s=0.01)
    runs = orch.Runs(ocfg, Agents(a, a, a, a), MemorySaver())
    rid = runs.start(StartRequest(mantis_id=1739, eap_ref="EAP-12610"))
    for _ in range(200):
        await runs.wait(rid)
        st = await runs.status(rid)
        if st["state"] == "waiting_human":
            break
        await asyncio.sleep(0.02)
    assert st["state"] == "waiting_human"
    md, data = build_digest(Settings(runs_dir=ocfg.work_dir, work_dir=tmp_path / "q"))
    assert data["counts"]["final_wait"] == 1 and data["runs"][0]["run_id"] == rid
    assert "Stop button: finished reported twice" in md and "| `EasiPlayer/core/runner.cpp` | 3 | 1 |" in md and f"POST /runs/{rid}/decision" in md
