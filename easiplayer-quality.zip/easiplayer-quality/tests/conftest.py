from __future__ import annotations

import copy

import pytest

from qualagent.config import Settings

DIFF_RUNNER = """diff --git a/EasiPlayer/core/runner.cpp b/EasiPlayer/core/runner.cpp
index 1111111..2222222 100644
--- a/EasiPlayer/core/runner.cpp
+++ b/EasiPlayer/core/runner.cpp
@@ -10,7 +10,9 @@ void Runner::abort()
 {
     m_running = false;
-    emit finished(-1);
+    if (!m_aborted)
+        emit finished(-1);
+    m_aborted = true;
 }
 
 void Runner::start()
diff --git a/EasiPlayer/core/runner.h b/EasiPlayer/core/runner.h
index 3333333..4444444 100644
--- a/EasiPlayer/core/runner.h
+++ b/EasiPlayer/core/runner.h
@@ -18,6 +18,7 @@ class Runner : public QObject
 private:
     bool m_running;
+    bool m_aborted;
 };
"""


def base_run(**over) -> dict:
    run = {
        "schema_version": "1.0", "run_id": "r1739", "ticket_id": "1739", "eap_ref": "EAP-12610", "state": "waiting_human", "status": None, "reason": "",
        "started": "2026-11-24T01:10:00+0100", "updated": "2026-11-24T03:40:00+0100", "replans": 0, "test_fixes": 0, "attempt": 1,
        "gate": {"gate": "final_review", "question": "Valider le correctif ?"},
        "request": {"mantis_id": 1739},
        "plan": {"ticket_id": "1739", "status": "ready", "ticket": {"id": "1739", "title": "Stop button: finished reported twice", "category": "Sequencer"},
                 "plan": {"root_cause": "abort() emits finished even when the run already finished",
                          "files_to_modify": [{"path": "EasiPlayer/core/runner.cpp", "change_type": "modify", "symbols": ["Runner::abort"], "logic_change": "Guard the emit with m_aborted"},
                                              {"path": "EasiPlayer/core/runner.h", "change_type": "modify", "symbols": ["Runner"], "logic_change": "Declare bool m_aborted"}],
                          "risks": [], "out_of_scope": ["Refactoring of start()"], "verification": {"squish_tests": ["tst_STD-EAP-SEQUENCER-00002"], "build_targets": [], "manual_checks": []}}},
        "dev_report": {"status": "applied", "commit_subject": "[EAP-12610][Sequencer]Stop button: finished reported twice", "branches": {"EasiPlayer": "fix/1739"},
                       "worktrees": {"EasiPlayer": "/w/1739/EasiPlayer"}, "warnings": [], "diff": DIFF_RUNNER},
        "loop_report": {"status": "success", "rounds": [{"status": "success"}], "final": {"status": "success"}},
        "qa_report": {"status": "passed", "scope": "full", "verdict_reason": "aucune régression", "summary": {"total": 49, "passed": 49, "failed": 0},
                      "selection": {"tests": [{"name": "tst_STD-EAP-SEQUENCER-00002"}], "unknown_suggestions": []},
                      "tests": [{"name": "tst_STD-EAP-SEQUENCER-00002", "status": "PASS"}], "briefs": []},
        "quality": {}, "events": [{"ts": "2026-11-24T01:10:05+0100", "step": "plan", "detail": "plan ready"}],
    }
    for k, v in over.items():
        run[k] = v
    return copy.deepcopy(run)


class FakeLLM:
    def __init__(self, out):
        self.out, self.prompts = out, []

    async def json(self, system, user, schema):
        self.prompts.append(user)
        if isinstance(self.out, Exception):
            raise self.out
        return self.out


@pytest.fixture
def cfg(tmp_path):
    return Settings(runs_dir=tmp_path / "runs", work_dir=tmp_path / "qual")
