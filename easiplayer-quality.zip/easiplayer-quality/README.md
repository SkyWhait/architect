# EasiPlayer Quality v0.1 — l'agent qualité et le rapport du matin

Deux rôles, un seul agent (port 8860) :

1. **Contrôle de conformité d'un correctif** (appelé par l'orchestrateur après la QA, avant ta revue) : le résultat final est-il ce que le Stratège avait décidé ?
2. **Rapport du matin** : « voici ce qui s'est passé, voici les modifications, voici ce que tu dois faire ».

## 1. Contrôle de conformité
Tout est recalculé depuis le **diff réel** et les rapports bruts, jamais depuis ce qu'un agent dit de son propre travail :

| Contrôle | Verdict |
|---|---|
| fichiers modifiés = fichiers du plan (ni manquant, ni hors plan) | échec |
| zones interdites (`build_*`, `install`, `redist`, `moc_/ui_/qrc_`) | échec |
| noyau critique touché → approbation humaine enregistrée au journal | échec sinon |
| symboles prévus présents dans le diff | réserve |
| API exposée aux scripts / D-Bus touchée sans que le plan l'ait annoncée | réserve |
| compilation (tours de correction), tests Squish (suite complète lancée ? un test vise-t-il la modification ? tests demandés par le Stratège exécutés ?) | échec / réserve |
| message de commit `[EAP-xxxxx][Catégorie]Titre` (EAP-TODO à renseigner) ; avertissements du Développeur ; taille du diff | réserve |

**Relecture de l'intention** (si `QUAL_LLM_BASE_URL`) : le LLM compare plan et diff, mais **ne peut rien affirmer sans citer le diff**. Une citation qui n'existe pas dans le diff réel écarte l'affirmation (listée « écartée », jamais comptée) : un LLM qui invente ne peut ni faire refuser un bon correctif ni en faire valider un mauvais. Sans LLM, le verdict ne dépasse pas « conforme avec réserves » et le rapport dit que l'intention n'a pas été relue.

Verdict : `approve` · `concerns` · `reject` (`reject` : l'orchestrateur s'arrête avant de te demander de valider).

## 2. Rapport du matin
Lit les `run.json` de l'orchestrateur (état complet de chaque run, réécrit à chaque étape et avant chaque point d'arrêt). Sections : **En bref** · **✋ À faire par toi** (avec les commandes exactes) · correctifs en attente de ta validation · plans en attente · validés à fusionner · arrêtés (pourquoi, test en échec, que faire) · chiffres. Chaque ticket : ce qui était voulu, ce qui a été fait (commit, branche, diff par fichier), build, tests choisis et résultat, verdict qualité, parcours (corrections, nouveaux plans).
Fenêtre : depuis le dernier rapport ; les tickets qui **attendent une décision humaine** sont toujours listés.

```bash
pip install -e .[dev] && pytest                      # 22 tests
qualagent digest --runs-dir /data/easiplayer/orch_runs --print      # écrit reports/morning-AAAA-MM-JJ.md + latest.md
qualagent digest --hours 72 --no-advance             # à la demande, sans décaler la fenêtre du prochain rapport
qualagent review /data/easiplayer/orch_runs/<run>    # relit un run (code de sortie 2 si non conforme)
qualagent serve                                      # API : POST /reviews, POST /digests, GET /digests/latest
# chaque matin à 7 h (cron) :
0 7 * * 1-5  cd /opt/qualagent && qualagent digest >> digest.log 2>&1
```
n8n peut lire `GET /digests/latest` (Markdown) et l'envoyer par courriel/Teams.

## Vérifié / non vérifié
Vérifié : chaque contrôle sur des cas conformes et non conformes ; relecture LLM avec citations réelles, inventées, « manquant » contredit ; rapport lu et relu sur un jeu de runs (validation attendue, plan en attente, validé, arrêté, ancien) ; contrat avec le **vrai orchestrateur** dans les deux sens (son `run.json` -> rapport ; son nœud qualité -> ce service).
Non vérifié : la qualité des relectures d'un vrai LLM (testé avec un LLM scripté) ; l'envoi du rapport (fichier + API seulement) ; l'heure de planification.
