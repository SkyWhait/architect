"""Le rapport du matin : « voici ce qui s'est passé, voici les modifications, voici ce que tu dois faire ».

Source : les `run.json` de l'orchestrateur (état complet de chaque run). Rien n'est reconstitué de mémoire : plan voulu, diff réel, build, tests, verdict qualité.
Fenêtre : depuis le dernier rapport (ou N heures) ; les runs qui ATTENDENT une décision humaine sont toujours listés, même anciens."""
from __future__ import annotations

import json
import time
from datetime import datetime, timedelta
from pathlib import Path

from .checks import run_checks
from .config import Settings
from .diffs import parse_diff
from .models import QualityReport
from .report_md import diff_table
from .runs import load_runs, parse_ts

JOURS = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"]
MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"]

WHY = {
    "ineligible": ("catégorie non éligible à l'automatisation", "Traiter ce ticket à la main (ou ajouter la catégorie aux catégories éligibles)."),
    "needs_info": ("le Stratège manque d'informations pour planifier", "Compléter le ticket (étapes de reproduction, logs) puis relancer."),
    "failed": ("le Stratège n'a pas produit de plan exploitable", "Regarder le plan.json du run ; relancer ou traiter à la main."),
    "rejected_by_human": ("refusé lors d'une validation humaine", "Rien à faire : refus enregistré."),
    "quality_rejected": ("refusé par le contrôle qualité", "Lire le contrôle qualité du run ; relancer avec un ticket plus précis ou corriger à la main."),
    "agent_error": ("un agent était injoignable ou a dépassé son délai", "Vérifier que les agents tournent puis relancer le run."),
    "qa_failed": ("des tests Squish échouent malgré les corrections", "Lire les tests en échec ci-dessous ; reprise manuelle probable."),
}


def _label(status: str | None) -> tuple[str, str]:
    s = status or ""
    if s in WHY:
        return WHY[s]
    if s.startswith("develop_"):
        return ("le Développeur n'a pas pu appliquer le plan", "Lire le rapport du Développeur du run (plan peut-être inadapté au code actuel).")
    if s.startswith("build_"):
        return ("la compilation n'a pas abouti", "Lire les erreurs de build du run (boucle de corrections épuisée ou erreur d'environnement).")
    if s.startswith("qa_"):
        return ("résultat de test non concluant", "Vérifier l'environnement Squish (licence, affichage) puis relancer.")
    return (s or "inconnu", "À examiner.")


def category(run: dict) -> str:
    if run.get("state") == "waiting_human" or (run.get("gate") and not run.get("status")):
        return "plan_wait" if (run.get("gate") or {}).get("gate") == "plan_review" else "final_wait"
    if run.get("status") == "ready_for_merge":
        return "ready"
    if not run.get("status"):
        return "running"
    return "stopped"


def fr_date(d: datetime) -> str:
    return f"{JOURS[d.weekday()]} {d.day} {MOIS[d.month - 1]} {d.year}"


def _title(run: dict) -> str:
    t = (run.get("plan") or {}).get("ticket") or {}
    return f"#{run.get('ticket_id') or t.get('id') or '?'} — {t.get('title') or '(titre inconnu)'}"


def _duration(run: dict) -> str:
    a, b = parse_ts(run.get("started")), parse_ts(run.get("updated"))
    if not a or not b:
        return ""
    m = int((b - a).total_seconds() // 60)
    if m < 0:
        return ""
    return f"{m // 60} h {m % 60:02d}" if m >= 60 else f"{m} min"


def _quality(run: dict, cfg: Settings) -> tuple[str, list[str], str]:
    """(verdict, réserves, origine). Le verdict de l'agent qualité s'il a tourné ; sinon contrôles déterministes recalculés à l'instant."""
    q = run.get("quality") or {}
    if q.get("verdict"):
        return q["verdict"], list(q.get("concerns", [])), "agent qualité"
    if not (run.get("dev_report") or {}).get("diff"):
        return "", [], ""
    checks, _s, _d = run_checks(run, cfg)
    conc = [f"{c.title} : {c.detail}" for c in checks if c.severity in {"fail", "warn"}]
    return ("reject" if any(c.severity == "fail" for c in checks) else "concerns" if conc else "approve"), conc, "contrôles automatiques simples, agent qualité non branché"


def card(run: dict, cfg: Settings) -> tuple[list[str], list[str]]:
    """(lignes Markdown, actions pour l'humain) d'un run."""
    cat = category(run)
    plan, body = run.get("plan") or {}, (run.get("plan") or {}).get("plan") or {}
    dev, loop, qa = run.get("dev_report") or {}, run.get("loop_report") or {}, run.get("qa_report") or {}
    t = plan.get("ticket") or {}
    ref = run.get("eap_ref") or ""
    head = _title(run) + (f"  ·  {ref}" if ref else "") + (f"  ·  {t.get('category')}" if t.get("category") else "")
    o = [f"### {head}", f"_run `{run.get('run_id')}`" + (f" · durée {_duration(run)}" if _duration(run) else "") + "_", ""]
    act: list[str] = []
    if body.get("root_cause"):
        o += [f"**Ce qui était voulu** — {body['root_cause']}"]
        o += [f"- `{f.get('path')}` : {f.get('logic_change', '')[:200]}" for f in body.get("files_to_modify", [])[:6]]
        o += [""]
    if dev.get("diff"):
        o += ["**Ce qui a été fait**", f"- commit : `{dev.get('commit_subject', '')}`  ·  branche(s) : " + ", ".join(f"`{r}:{b}`" for r, b in (dev.get('branches') or {}).items()), "", *diff_table(dev["diff"]), ""]
    ver = []
    if loop:
        n = len(loop.get("rounds", []))
        ver.append(f"- compilation : {'réussie' if loop.get('status') == 'success' else loop.get('status')} ({n} tour{'s' if n > 1 else ''})")
    if qa:
        sel = [x.get("name") for x in ((qa.get("selection") or {}).get("tests") or [])]
        s = qa.get("summary") or {}
        ver.append(f"- tests Squish : **{qa.get('status')}**" + (f" — {s.get('passed', '?')}/{s.get('total', '?')} réussis" if s else "") + (" (suite complète non lancée)" if qa.get("scope") == "targeted" else "")
                   + (f" ; tests choisis pour cette modification : {', '.join(sel)}" if sel else " ; aucun test ciblé identifié"))
    if run.get("test_fixes") or run.get("replans"):
        ver.append(f"- parcours : {run.get('test_fixes', 0)} correction(s) après échec de test, {run.get('replans', 0)} nouveau(x) plan(s)")
    verdict, concerns, origin = _quality(run, cfg)
    if verdict:
        ver.append(f"- contrôle qualité ({origin}) : **{ {'approve': '✅ conforme au plan', 'concerns': '⚠️ conforme avec réserves', 'reject': '❌ non conforme'}[verdict] }**")
        ver += [f"  - {c}" for c in concerns[:4]]
    if ver:
        o += ["**Vérifications**", *ver, ""]
    if cat == "final_wait":
        g = run.get("gate") or {}
        o += [f"**⏳ Attend ta validation finale** — {g.get('question', '')}", ""]
        act.append(f"Valider ou refuser le correctif {_title(run).split(' — ')[0]} : `POST /runs/{run['run_id']}/decision {{\"approve\": true|false}}`")
    elif cat == "plan_wait":
        g = run.get("gate") or {}
        o += ["**⏳ Attend ta validation du PLAN** (rien n'est écrit tant que tu n'as pas répondu) :", *[f"- {r}" for r in g.get("reasons", [])], f"- fichiers visés : {', '.join(g.get('files', []))}", ""]
        act.append(f"Valider ou refuser le plan de {_title(run).split(' — ')[0]} : `POST /runs/{run['run_id']}/decision {{\"approve\": true|false}}`")
    elif cat == "ready":
        o += ["**Validé par toi — reste la fusion manuelle :**", *[f"- `cd <racine>/{r} && git checkout development && git merge --no-ff {b}`" for r, b in (dev.get('branches') or {}).items()], ""]
        act.append(f"Fusionner {_title(run).split(' — ')[0]} dans `development` (commandes dans sa fiche).")
    elif cat == "stopped":
        why, todo = _label(run.get("status"))
        o += [f"**Arrêté : {why}** — {run.get('reason', '')}", f"→ {todo}", ""]
        briefs = qa.get("briefs") or []
        o += [f"- test en échec : `{b.get('test')}` — {((b.get('failed') or {}).get('message') or '')[:160]}" for b in briefs[:4]] + [""]
        act.append(f"{_title(run).split(' — ')[0]} : {todo}")
    if str(dev.get("commit_subject", "")).startswith("[EAP-TODO]") and cat in {"final_wait", "ready"}:
        act.append(f"Renseigner la vraie référence EAP dans le commit de {_title(run).split(' — ')[0]} (`git commit --amend`) avant de fusionner.")
    return o, act


def build_digest(cfg: Settings, now: datetime | None = None, since: datetime | None = None) -> tuple[str, dict]:
    now = now or datetime.now().astimezone()
    last = cfg.work_dir / "reports" / "last_digest.json"
    if since is None and last.exists():
        try:
            since = parse_ts(json.loads(last.read_text()).get("generated_at"))
        except (OSError, ValueError):
            since = None
    since = since or (now - timedelta(hours=cfg.digest_hours))
    runs, warns = load_runs(cfg.runs_dir)
    sel = [r for r in runs if category(r) in {"plan_wait", "final_wait"} or (parse_ts(r.get("updated")) or now) >= since]
    sel.sort(key=lambda r: r.get("updated") or "", reverse=True)
    groups: dict[str, list[dict]] = {k: [] for k in ("final_wait", "plan_wait", "ready", "stopped", "running")}
    for r in sel:
        groups[category(r)].append(r)
    counts = {k: len(v) for k, v in groups.items()}

    all_actions: list[str] = []
    sections: dict[str, list[str]] = {}
    for k, rs in groups.items():
        lines: list[str] = []
        for r in rs:
            c, a = card(r, cfg)
            lines += c
            all_actions += a
        sections[k] = lines

    o = [f"# Rapport du matin — {fr_date(now)}", f"_Activité depuis le {fr_date(since)} à {since.strftime('%H:%M')} · généré à {now.strftime('%H:%M')}_", ""]
    if not sel:
        o += ["## En bref", "Aucune activité depuis le dernier rapport.", ""]
    else:
        def pl(n: int, one: str, many: str) -> str:
            return f"{n} {one if n == 1 else many}"
        bits = [pl(counts["final_wait"], "attend ta validation finale", "attendent ta validation finale"), pl(counts["plan_wait"], "attend ta validation de son plan", "attendent ta validation de leur plan"),
                pl(counts["ready"], "validé, à fusionner", "validés, à fusionner"), pl(counts["stopped"], "arrêté", "arrêtés"), pl(counts["running"], "en cours", "en cours")]
        o += ["## En bref", f"{len(sel)} ticket(s) : " + " · ".join(b for b in bits if not b.startswith("0 ")) + ".", ""]
    if all_actions:
        o += ["## ✋ À faire par toi", *[f"{i}. {a}" for i, a in enumerate(dict.fromkeys(all_actions), 1)], ""]
    titles = {"final_wait": "⏳ Correctifs prêts, en attente de ta validation", "plan_wait": "⏳ Plans en attente de ta validation", "ready": "✅ Validés, prêts à fusionner",
              "stopped": "❌ Arrêtés (et pourquoi)", "running": "🔄 En cours"}
    for k in ("final_wait", "plan_wait", "ready", "stopped", "running"):
        if sections[k]:
            o += [f"## {titles[k]}", "", *sections[k]]
    stats = _stats(sel)
    if stats:
        o += ["## Chiffres", *stats, ""]
    if warns:
        o += ["## ⚠️ Données illisibles", *[f"- {w}" for w in warns], ""]
    md = "\n".join(o).rstrip() + "\n"
    data = {"generated_at": now.strftime("%Y-%m-%dT%H:%M:%S%z"), "since": since.strftime("%Y-%m-%dT%H:%M:%S%z"), "counts": counts, "actions": list(dict.fromkeys(all_actions)),
            "runs": [{"run_id": r.get("run_id"), "ticket_id": r.get("ticket_id"), "category": category(r), "status": r.get("status"), "title": _title(r)} for r in sel], "warnings": warns}
    return md, data


def _stats(runs: list[dict]) -> list[str]:
    if not runs:
        return []
    files = sum(len(parse_diff((r.get("dev_report") or {}).get("diff") or "")) for r in runs)
    added = sum(f.added for r in runs for f in parse_diff((r.get("dev_report") or {}).get("diff") or "").values())
    removed = sum(f.removed for r in runs for f in parse_diff((r.get("dev_report") or {}).get("diff") or "").values())
    tests = sum(int(((r.get("qa_report") or {}).get("summary") or {}).get("total", 0)) for r in runs)
    fixes = sum(r.get("test_fixes", 0) for r in runs)
    replans = sum(r.get("replans", 0) for r in runs)
    return [f"- {files} fichier(s) modifié(s), +{added}/−{removed} lignes", f"- {tests} exécution(s) de test Squish", f"- {fixes} correction(s) après échec de test, {replans} nouveau(x) plan(s) demandé(s)"]


def write_digest(cfg: Settings, md: str, data: dict, advance: bool = True) -> Path:
    d = cfg.work_dir / "reports"
    d.mkdir(parents=True, exist_ok=True)
    day = data["generated_at"][:10]
    (d / f"morning-{day}.md").write_text(md, encoding="utf-8")
    (d / f"morning-{day}.json").write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")
    (d / "latest.md").write_text(md, encoding="utf-8")
    if advance:                                   # un rapport « à la demande » (advance=False) ne décale pas la fenêtre du prochain rapport du matin
        (d / "last_digest.json").write_text(json.dumps({"generated_at": data["generated_at"]}), encoding="utf-8")
    return d / f"morning-{day}.md"
