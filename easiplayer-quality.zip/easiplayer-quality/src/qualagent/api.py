from __future__ import annotations

import asyncio
import re
import time
from datetime import datetime, timedelta

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel

from . import __version__
from .config import Settings, get_settings
from .digest import build_digest, write_digest
from .llm import LLMLike, make_llm
from .report_md import review_markdown
from .review import review_run


class ReviewRequest(BaseModel):
    run: dict                              # le run.json de l'orchestrateur


class DigestRequest(BaseModel):
    hours: int | None = None
    advance: bool = True                   # False : rapport à la demande, sans décaler la fenêtre du prochain rapport du matin


def sid(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", str(s)) or "unknown"


def create_app(settings: Settings | None = None, llm: LLMLike | None = None) -> FastAPI:
    cfg = settings or get_settings()
    lm = llm if llm is not None else make_llm(cfg)

    def auth(authorization: str | None = Header(default=None)):
        if cfg.api_token and authorization != f"Bearer {cfg.api_token}":
            raise HTTPException(401, "jeton invalide")

    app = FastAPI(title="EasiPlayer Quality", version=__version__, dependencies=[Depends(auth)])
    jobs: dict[str, dict] = {}
    rdir = cfg.work_dir / "reviews"

    async def work(rid: str, run: dict) -> None:
        try:
            rep = await review_run(run, cfg, lm)
            rdir.mkdir(parents=True, exist_ok=True)
            (rdir / f"{rid}.json").write_text(rep.model_dump_json(indent=1))
            (rdir / f"{rid}.md").write_text(review_markdown(rep), encoding="utf-8")
            jobs[rid].update(state="done", verdict=rep.verdict)
        except Exception as e:                                               # noqa: BLE001
            jobs[rid].update(state="done", verdict="error", error=f"{type(e).__name__}: {e}")

    @app.post("/reviews", status_code=202)
    async def start(req: ReviewRequest):
        rid = sid(req.run.get("run_id") or req.run.get("ticket_id") or "run")
        if jobs.get(rid, {}).get("state") == "running":
            raise HTTPException(409, "relecture déjà en cours pour ce run")
        jobs[rid] = {"state": "running", "started": time.time()}
        asyncio.create_task(work(rid, req.run))
        return {"review_id": rid, "state": "running"}

    @app.get("/reviews/{rid}")
    async def status(rid: str, full: bool = False):
        rid = sid(rid)
        j = jobs.get(rid)
        if j is None:
            raise HTTPException(404, "relecture inconnue")
        out = dict(j)
        if full and j.get("state") == "done" and (rdir / f"{rid}.json").exists():
            import json
            out["report"] = json.loads((rdir / f"{rid}.json").read_text())
        return out

    @app.get("/reviews/{rid}/report", response_class=PlainTextResponse)
    async def review_report(rid: str):
        p = rdir / f"{sid(rid)}.md"
        if not p.exists():
            raise HTTPException(404, "pas de rapport")
        return p.read_text(encoding="utf-8")

    @app.post("/digests")
    async def digest(req: DigestRequest | None = None):
        req = req or DigestRequest()
        since = (datetime.now().astimezone() - timedelta(hours=req.hours)) if req.hours else None
        md, data = build_digest(cfg, since=since)
        path = write_digest(cfg, md, data, advance=req.advance)
        return {"path": str(path), "markdown": md, "data": data}

    @app.get("/digests/latest", response_class=PlainTextResponse)
    async def latest():
        p = cfg.work_dir / "reports" / "latest.md"
        if not p.exists():
            raise HTTPException(404, "aucun rapport généré")
        return p.read_text(encoding="utf-8")

    @app.get("/health")
    async def health():
        return {"ok": True, "agent": "quality", "version": __version__, "llm": bool(lm)}

    return app
