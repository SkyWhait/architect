"""Client LLM minimal (API compatible OpenAI : vLLM), sortie JSON imposée par schéma. Facultatif : sans `llm_base_url` l'agent travaille sans."""
from __future__ import annotations

import json
from typing import Protocol, TypeVar

from pydantic import BaseModel

from .config import Settings

T = TypeVar("T", bound=BaseModel)


class LLMLike(Protocol):
    async def json(self, system: str, user: str, schema: type[T]) -> T: ...


class LLM:
    def __init__(self, cfg: Settings):
        from openai import AsyncOpenAI
        self.cfg = cfg
        self.c = AsyncOpenAI(base_url=cfg.llm_base_url, api_key=cfg.llm_api_key, timeout=cfg.llm_timeout_s)

    async def json(self, system: str, user: str, schema: type[T]) -> T:
        last: Exception | None = None
        for _ in range(3):
            r = await self.c.chat.completions.create(
                model=self.cfg.llm_model, temperature=0, seed=7, max_tokens=2500,
                messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
                response_format={"type": "json_schema", "json_schema": {"name": schema.__name__, "schema": schema.model_json_schema(), "strict": True}})
            try:
                return schema.model_validate_json(r.choices[0].message.content or "")
            except ValueError as e:
                last = e
        raise RuntimeError(f"sortie LLM invalide après 3 essais : {last}")


def make_llm(cfg: Settings) -> LLMLike | None:
    return LLM(cfg) if cfg.llm_base_url else None
