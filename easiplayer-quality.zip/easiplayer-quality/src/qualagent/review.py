"""Relecture d'un run : contrôles déterministes + (si un LLM est configuré) relecture sémantique « le code fait-il ce que le plan demandait ? ».

Règle d'or de la relecture sémantique : le LLM ne peut RIEN affirmer sans citer le diff. Chaque affirmation porte une citation ; si elle n'existe pas dans le diff réel,
l'affirmation est écartée (listée dans `discarded`, jamais comptée). Un LLM qui invente ne peut donc ni faire refuser un bon correctif ni en faire valider un mauvais."""
from __future__ import annotations

import time

from .checks import run_checks
from .config import Settings
from .diffs import quote_in_diff
from .llm import LLMLike
from .models import Check, Finding, QualityReport, Semantic, SemanticOut, Unplanned

SYSTEM = """You are a strict senior C++/Qt code reviewer. You compare a PLAN written by a strategist with the REAL DIFF produced by a developer, and say whether the diff implements the plan.
Rules:
- For every planned file, give a finding: implemented | partial | missing | unclear, with a short note.
- `evidence_quote` MUST be copied VERBATIM from the diff (one or two lines of code, no +/- prefix). Without a real quote, use status `unclear`.
- List in `unplanned_changes` any change in the diff that the plan does not call for (with a verbatim quote).
- `concerns`: real risks only (behaviour change not requested, thread-safety, ownership, script/D-Bus API). No style remarks, no praise.
- Never invent code that is not in the diff. Be brief."""

USER = """TICKET: {ticket}

PLAN
Root cause: {root_cause}
Files and intended change:
{files}
Out of scope: {out_of_scope}
Risks announced: {risks}

REAL DIFF
{diff}
"""


def _plan_files(plan: dict) -> str:
    return "\n".join(f"- {f.get('path')} (symbols: {', '.join(f.get('symbols', [])) or '-'}): {f.get('logic_change', '')}" for f in (plan.get("plan") or {}).get("files_to_modify", []))


async def semantic_review(run: dict, diff_text: str, llm: LLMLike | None, cfg: Settings, model: str = "") -> Semantic:
    if llm is None:
        return Semantic(performed=False, skipped_reason="aucun LLM configuré (QUAL_LLM_BASE_URL) : seuls les contrôles déterministes ont été faits ; l'intention du plan n'a pas été relue")
    plan = run.get("plan") or {}
    body = plan.get("plan") or {}
    user = USER.format(ticket=f"{(plan.get('ticket') or {}).get('title', '')}", root_cause=body.get("root_cause", ""), files=_plan_files(plan),
                       out_of_scope="; ".join(body.get("out_of_scope", [])) or "-", risks="; ".join(r.get("description", "") for r in body.get("risks", [])) or "-",
                       diff=diff_text[: cfg.max_diff_chars] + ("\n[diff truncated]" if len(diff_text) > cfg.max_diff_chars else ""))
    try:
        out = await llm.json(SYSTEM, user, SemanticOut)
    except Exception as e:                                                       # noqa: BLE001 — la relecture est un plus : jamais bloquante
        return Semantic(performed=False, skipped_reason=f"relecture LLM impossible : {type(e).__name__}: {str(e)[:160]}")
    sem = Semantic(performed=True, model=model or cfg.llm_model, concerns=[c for c in out.concerns if c.strip()][:6])
    planned_paths = {f.get("path") for f in body.get("files_to_modify", [])}
    from .diffs import parse_diff
    files = parse_diff(diff_text)
    for f in out.findings:
        if f.planned_path not in planned_paths:
            sem.discarded.append(f"constat sur un fichier absent du plan : {f.planned_path}")
            continue
        if f.status in {"implemented", "partial"}:
            ok = quote_in_diff(f.evidence_quote, diff_text)
            if not ok:
                sem.discarded.append(f"{f.planned_path} : « {f.status} » affirmé sans citation retrouvée dans le diff")
                sem.findings.append(Finding(planned_path=f.planned_path, status="unclear", note="affirmation non vérifiable (citation absente du diff) : " + f.note, verified=False))
                continue
            sem.findings.append(Finding(planned_path=f.planned_path, status=f.status, note=f.note, evidence=f.evidence_quote, verified=True))
        elif f.status == "missing":
            if f.planned_path in files:                                             # « manquant » alors que le fichier a des modifications : invérifié
                sem.discarded.append(f"{f.planned_path} : « missing » affirmé alors que le fichier est modifié")
                sem.findings.append(Finding(planned_path=f.planned_path, status="unclear", note="jugé manquant par le LLM mais le fichier est modifié : " + f.note, verified=False))
            else:
                sem.findings.append(Finding(planned_path=f.planned_path, status="missing", note=f.note, verified=True))
        else:
            sem.findings.append(Finding(planned_path=f.planned_path, status="unclear", note=f.note, verified=False))
    for u in out.unplanned_changes:
        if quote_in_diff(u.evidence_quote, diff_text):
            sem.unplanned.append(Unplanned(path=u.path, note=u.note, evidence=u.evidence_quote, verified=True))
        else:
            sem.discarded.append(f"changement « hors plan » dans {u.path} sans citation retrouvée dans le diff")
    return sem


def verdict_of(checks: list[Check], sem: Semantic) -> tuple[str, list[str]]:
    concerns: list[str] = []
    fails = [c for c in checks if c.severity == "fail"]
    warns = [c for c in checks if c.severity == "warn"]
    concerns += [f"{c.title} : {c.detail}" for c in fails + warns]
    if not sem.performed:                                                  # « conforme » sans avoir relu l'intention du plan serait mentir : au mieux « avec réserves »
        concerns.append(f"L'intention du plan n'a pas été relue : {sem.skipped_reason}")
    reject = bool(fails)
    for f in sem.findings:
        if f.verified and f.status == "missing":
            reject = True
            concerns.append(f"Prévu mais absent du diff — {f.planned_path} : {f.note}")
        elif f.status == "partial" and f.verified:
            concerns.append(f"Implémentation partielle — {f.planned_path} : {f.note}")
        elif f.status == "unclear":
            concerns.append(f"Non vérifié — {f.planned_path} : {f.note}")
    concerns += [f"Changement hors plan — {u.path} : {u.note}" for u in sem.unplanned if u.verified]
    concerns += [f"Relecture : {c}" for c in sem.concerns]
    verdict = "reject" if reject else ("concerns" if concerns else "approve")
    return verdict, concerns


async def review_run(run: dict, cfg: Settings, llm: LLMLike | None, core_files: list[str] | None = None) -> QualityReport:
    checks, stats, _files = run_checks(run, cfg, core_files)
    diff_text = (run.get("dev_report") or {}).get("diff") or ""
    sem = await semantic_review(run, diff_text, llm, cfg) if diff_text else Semantic(performed=False, skipped_reason="pas de diff")
    verdict, concerns = verdict_of(checks, sem)
    nfail, nwarn = sum(c.severity == "fail" for c in checks), sum(c.severity == "warn" for c in checks)
    ticket = (run.get("plan") or {}).get("ticket") or {}
    head = {"approve": "Conforme au plan", "concerns": "Conforme avec réserves", "reject": "Non conforme"}[verdict]
    summary = (f"{head} — {stats.files} fichier(s), +{stats.added}/-{stats.removed} ; build en {stats.build_rounds} tour(s) ; tests : {stats.tests_passed}/{stats.tests_total} réussis ; "
               f"{nfail} contrôle(s) en échec, {nwarn} réserve(s)" + ("" if sem.performed else " ; intention du plan NON relue (pas de LLM)"))
    return QualityReport(run_id=run.get("run_id", ""), ticket_id=run.get("ticket_id") or ticket.get("id", ""), verdict=verdict, summary=summary, concerns=concerns,  # type: ignore[arg-type]
                         checks=checks, semantic=sem, stats=stats, generated_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"))
