"""Lecture des `run.json` de l'orchestrateur (contrat : voir orchagent.graph.write_snapshot)."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

TS = "%Y-%m-%dT%H:%M:%S%z"


def parse_ts(s: str | None) -> datetime | None:
    if not s:
        return None
    try:
        return datetime.strptime(s, TS)
    except ValueError:
        try:
            return datetime.fromisoformat(s)
        except ValueError:
            return None


def load_runs(runs_dir: Path) -> tuple[list[dict], list[str]]:
    """(runs, avertissements). Un run illisible est signalé, jamais ignoré en silence."""
    runs, warns = [], []
    if not runs_dir.is_dir():
        return [], [f"dossier des runs introuvable : {runs_dir}"]
    for p in sorted(runs_dir.glob("*/run.json")):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            warns.append(f"{p.parent.name}/run.json illisible : {e}")
            continue
        if not isinstance(d, dict) or "run_id" not in d:
            warns.append(f"{p.parent.name}/run.json : format inattendu")
            continue
        runs.append(d)
    return runs, warns
