from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

Sev = Literal["ok", "info", "warn", "fail"]


class Check(BaseModel):
    id: str
    title: str
    severity: Sev
    detail: str = ""
    evidence: list[str] = Field(default_factory=list)


class Finding(BaseModel):
    """Une affirmation de la relecture sémantique, VÉRIFIÉE : la citation doit exister dans le diff réel."""
    planned_path: str
    status: Literal["implemented", "partial", "missing", "unclear"]
    note: str = ""
    evidence: str = ""
    verified: bool = False


class Unplanned(BaseModel):
    path: str
    note: str = ""
    evidence: str = ""
    verified: bool = False


class Semantic(BaseModel):
    performed: bool = False
    skipped_reason: str = ""
    model: str = ""
    findings: list[Finding] = Field(default_factory=list)
    unplanned: list[Unplanned] = Field(default_factory=list)
    concerns: list[str] = Field(default_factory=list)
    discarded: list[str] = Field(default_factory=list)          # affirmations écartées car invérifiables (jamais comptées)


class Stats(BaseModel):
    files: int = 0
    added: int = 0
    removed: int = 0
    build_rounds: int = 0
    tests_total: int = 0
    tests_passed: int = 0
    tests_failed: int = 0
    tests_selected: list[str] = Field(default_factory=list)
    replans: int = 0
    test_fixes: int = 0
    seconds: float = 0.0


class QualityReport(BaseModel):
    schema_version: str = "1.0"
    run_id: str
    ticket_id: str
    verdict: Literal["approve", "concerns", "reject"]
    summary: str
    concerns: list[str] = Field(default_factory=list)           # les points à regarder, par ordre d'importance
    checks: list[Check] = Field(default_factory=list)
    semantic: Semantic = Field(default_factory=Semantic)
    stats: Stats = Field(default_factory=Stats)
    generated_at: str = ""


class SemanticOut(BaseModel):
    """Sortie imposée au LLM (schéma JSON strict)."""
    class F(BaseModel):
        planned_path: str
        status: Literal["implemented", "partial", "missing", "unclear"]
        evidence_quote: str = ""
        note: str = ""

    class U(BaseModel):
        path: str
        evidence_quote: str = ""
        note: str = ""

    findings: list[F]
    unplanned_changes: list[U] = Field(default_factory=list)
    concerns: list[str] = Field(default_factory=list)
