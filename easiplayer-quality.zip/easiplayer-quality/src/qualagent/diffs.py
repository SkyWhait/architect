"""Lecture du diff RÉEL (celui du dépôt, pas le résumé de l'agent) : fichiers touchés, lignes ajoutées/supprimées, ce qui a été ajouté."""
from __future__ import annotations

import re
from dataclasses import dataclass, field

_HDR = re.compile(r"^diff --git a/(?P<a>.+?) b/(?P<b>.+)$")


@dataclass
class FileDiff:
    path: str
    added: int = 0
    removed: int = 0
    new: bool = False
    deleted: bool = False
    hunks: list[str] = field(default_factory=list)              # en-têtes @@ (contiennent souvent le nom de la fonction)
    added_lines: list[str] = field(default_factory=list)
    removed_lines: list[str] = field(default_factory=list)
    context: list[str] = field(default_factory=list)


def parse_diff(text: str) -> dict[str, FileDiff]:
    out: dict[str, FileDiff] = {}
    cur: FileDiff | None = None
    for line in (text or "").splitlines():
        m = _HDR.match(line)
        if m:
            cur = out.setdefault(m.group("b"), FileDiff(path=m.group("b")))
            continue
        if cur is None:
            continue
        if line.startswith("new file mode"):
            cur.new = True
        elif line.startswith("deleted file mode"):
            cur.deleted = True
        elif line.startswith("@@"):
            cur.hunks.append(line)
        elif line.startswith("+++") or line.startswith("---") or line.startswith("index "):
            continue
        elif line.startswith("+"):
            cur.added += 1
            cur.added_lines.append(line[1:])
        elif line.startswith("-"):
            cur.removed += 1
            cur.removed_lines.append(line[1:])
        elif line.startswith(" "):
            cur.context.append(line[1:])
    return out


def norm(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def quote_in_diff(quote: str, diff_text: str) -> bool:
    """La citation (espaces normalisés) existe-t-elle réellement dans le diff ? (sans les préfixes +/-/espace de début de ligne)"""
    q = norm(quote)
    if len(q) < 6:
        return False
    body = norm("\n".join(l[1:] if l[:1] in "+- " else l for l in diff_text.splitlines()))
    return q in body
