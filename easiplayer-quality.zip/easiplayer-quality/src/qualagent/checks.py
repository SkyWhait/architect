"""Contrôles de conformité DÉTERMINISTES : le résultat final correspond-il à ce que le Stratège avait décidé ? Tout est recalculé depuis le diff réel
et les rapports bruts (jamais depuis le résumé qu'un agent donne de son propre travail)."""
from __future__ import annotations

import fnmatch
import re
from pathlib import PurePosixPath

from .config import Settings
from .diffs import FileDiff, parse_diff
from .models import Check, Stats

COMMIT_RE = re.compile(r"^\[(?P<ref>EAP-[A-Z0-9]+)\]\[(?P<cat>General|Sequencer|Avatar import|NH90|NH90_AAP)\]\S")
API_RE = re.compile(r"Q_INVOKABLE|Q_PROPERTY|Q_SIGNALS|\bsignals\s*:|public\s+slots\s*:|\bQ_SLOT\b|Q_ENUM|Q_DECLARE_METATYPE|qScriptRegisterMetaType")
FORBIDDEN = ["build_*", "install", "redist"]
GENERATED = re.compile(r"(^|/)(moc_|ui_|qrc_)[^/]*$")
CORE_DEFAULT = ["Information.cpp", "TestCheckValue.cpp"]


def _c(id_: str, title: str, sev: str, detail: str = "", evidence: list[str] | None = None) -> Check:
    return Check(id=id_, title=title, severity=sev, detail=detail, evidence=evidence or [])  # type: ignore[arg-type]


def _short(sym: str) -> str:
    return sym.strip().rstrip("()").split("::")[-1]


def run_checks(run: dict, cfg: Settings, core_files: list[str] | None = None) -> tuple[list[Check], Stats, dict[str, FileDiff]]:
    plan = run.get("plan") or {}
    body = plan.get("plan") or {}
    dev = run.get("dev_report") or {}
    loop = run.get("loop_report") or {}
    qa = run.get("qa_report") or {}
    diff = parse_diff(dev.get("diff") or "")
    planned = {f["path"]: f for f in body.get("files_to_modify", []) if f.get("path")}
    out: list[Check] = []

    # 1. un diff existe
    if not diff:
        out.append(_c("diff_present", "Une modification existe", "fail", "Le rapport du Développeur ne contient aucun diff : rien n'a été modifié."))
        return out + _rest(run, cfg, planned, diff, body, dev, loop, qa, core_files), _stats(run, diff, loop, qa), diff
    out.append(_c("diff_present", "Une modification existe", "ok", f"{len(diff)} fichier(s) modifié(s)."))
    return out + _rest(run, cfg, planned, diff, body, dev, loop, qa, core_files), _stats(run, diff, loop, qa), diff


def _rest(run, cfg, planned, diff, body, dev, loop, qa, core_files) -> list[Check]:
    out: list[Check] = []
    touched = set(diff)

    # 2. fichiers prévus <-> fichiers modifiés
    missing = sorted(p for p, f in planned.items() if f.get("change_type", "modify") != "remove" and p not in touched)
    removed_ok = sorted(p for p, f in planned.items() if f.get("change_type") == "remove" and p in diff and diff[p].deleted)
    unplanned = sorted(p for p in touched if p not in planned)
    if missing:
        out.append(_c("planned_files", "Fichiers prévus par le plan modifiés", "fail", "Prévus mais NON modifiés : " + ", ".join(missing), missing))
    elif unplanned:
        out.append(_c("planned_files", "Fichiers prévus par le plan modifiés", "fail", "Modifiés mais HORS plan : " + ", ".join(unplanned), unplanned))
    else:
        out.append(_c("planned_files", "Fichiers prévus par le plan modifiés", "ok", f"Les {len(planned)} fichier(s) du plan, et seulement eux."
                      + (f" ({len(removed_ok)} suppression(s) conforme(s))" if removed_ok else "")))
    if missing and unplanned:
        out.append(_c("unplanned_files", "Fichiers hors plan", "fail", "Modifiés mais HORS plan : " + ", ".join(unplanned), unplanned))

    # 3. symboles prévus réellement touchés
    nothing: list[str] = []
    for p, f in planned.items():
        d = diff.get(p)
        if d is None:
            continue
        hay = "\n".join([*d.hunks, *d.added_lines, *d.removed_lines])
        near = "\n".join(d.context)
        for sym in f.get("symbols", []):
            s = _short(sym)
            if s and not re.search(rf"\b{re.escape(s)}\b", hay) and not re.search(rf"\b{re.escape(s)}\b", near):
                nothing.append(f"{p}: {sym}")
    out.append(_c("planned_symbols", "Symboles prévus touchés", "warn" if nothing else "ok",
                  ("Aucune trace dans le diff de : " + ", ".join(nothing)) if nothing else "Chaque symbole du plan apparaît dans le diff.", nothing))

    # 4. surface d'API (scripts / D-Bus)
    api_hits = [f"{p}: {l.strip()[:90]}" for p, d in diff.items() for l in [*d.added_lines, *d.removed_lines] if API_RE.search(l)]
    announced = any(str(r.get("area", "")).lower() in {"script_api", "dbus", "d-bus", "public_api"} for r in body.get("risks", []))
    if api_hits:
        out.append(_c("api_surface", "Surface d'API (scripts / D-Bus)", "info" if announced else "warn",
                      "Le diff touche l'API exposée aux scripts/D-Bus" + (" (annoncé par le Stratège)." if announced else " SANS que le plan l'ait annoncé comme un risque."), api_hits[:6]))
    else:
        out.append(_c("api_surface", "Surface d'API (scripts / D-Bus)", "ok", "Aucune ligne d'API exposée (Q_INVOKABLE, Q_PROPERTY, signaux, slots publics) touchée."))

    # 5. zones interdites (re-vérifiées sur le diff)
    bad = [p for p in diff if any(fnmatch.fnmatch(c, pat) for c in PurePosixPath(p).parts[:-1] for pat in FORBIDDEN) or GENERATED.search(p)]
    out.append(_c("forbidden_zones", "Aucune zone interdite touchée", "fail" if bad else "ok", ("Zone interdite : " + ", ".join(bad)) if bad else "build_*, install, redist et fichiers générés intacts.", bad))

    # 6. noyau critique : approbation humaine enregistrée ?
    core = {c.lower() for c in (core_files or CORE_DEFAULT)}
    core_hit = [p for p in diff if PurePosixPath(p).name.lower() in core]
    approved = any(e.get("step") == "gate" and "approuvé" in (e.get("detail") or "") for e in run.get("events", []))
    if core_hit:
        out.append(_c("core_gate", "Noyau critique : plan validé par un humain", "ok" if approved else "fail",
                      ("Plan approuvé par l'humain avant l'écriture du code." if approved else "Le diff touche le noyau critique SANS approbation humaine enregistrée dans le journal."), core_hit))

    # 7. build
    rounds = len(loop.get("rounds", []))
    if loop.get("status") != "success":
        out.append(_c("build", "Compilation", "fail", f"Statut du build : {loop.get('status', 'inconnu')}."))
    elif rounds > cfg.max_build_rounds_ok:
        out.append(_c("build", "Compilation", "warn", f"Réussie, mais après {rounds} tours de correction : le premier jet du Développeur ne compilait pas."))
    else:
        out.append(_c("build", "Compilation", "ok", "Réussie du premier coup." if rounds <= 1 else f"Réussie en {rounds} tours."))

    # 8. tests Squish
    sel = [t.get("name") for t in ((qa.get("selection") or {}).get("tests") or [])]
    ran = [t.get("name") for t in qa.get("tests", [])]
    if qa.get("status") != "passed":
        out.append(_c("tests", "Tests Squish", "fail", f"Statut QA : {qa.get('status', 'inconnu')} — {qa.get('verdict_reason', '')}"))
    elif qa.get("scope") == "targeted":
        out.append(_c("tests", "Tests Squish", "warn", "Seuls les tests ciblés ont été lancés : la suite complète n'a PAS tourné (verdict partiel)."))
    elif not sel:
        out.append(_c("tests", "Tests Squish", "warn", "Suite complète réussie, mais aucun test ciblé n'a été identifié pour cette modification (pas de test qui la vise directement)."))
    else:
        out.append(_c("tests", "Tests Squish", "ok", f"{len(sel)} test(s) ciblé(s) + suite complète réussis : {', '.join(sel)}."))
    wanted = [s.split("/")[-1] for s in ((body.get("verification") or {}).get("squish_tests") or [])]
    not_run = [w for w in wanted if w not in ran and w not in sel]
    unknown = list((qa.get("selection") or {}).get("unknown_suggestions") or [])
    if wanted:
        out.append(_c("plan_tests", "Tests demandés par le Stratège exécutés", "warn" if (not_run or unknown) else "ok",
                      ("Non exécutés : " + ", ".join(not_run) if not_run else "") + (" ; introuvables dans la suite : " + ", ".join(unknown) if unknown else "") or "Tous exécutés.", not_run + unknown))

    # 9. commit
    subj = dev.get("commit_subject", "")
    m = COMMIT_RE.match(subj)
    if not subj:
        out.append(_c("commit", "Message de commit", "warn", "Aucun message de commit dans le rapport."))
    elif not m:
        out.append(_c("commit", "Message de commit", "warn", f"Ne suit pas [EAP-xxxxx][Catégorie]Titre : « {subj} »."))
    elif m.group("ref") == "EAP-TODO":
        out.append(_c("commit", "Message de commit", "warn", f"La référence EAP est à renseigner avant fusion (git commit --amend) : « {subj} »."))
    else:
        out.append(_c("commit", "Message de commit", "ok", subj))

    # 10. avertissements du Développeur
    ignore = {"commit_ref_missing", "reconfigure_needed", "commit_category_fallback", "build_not_verified"}
    dw = [f"[{w.get('code')}] {w.get('message', '')[:140]}" for w in dev.get("warnings", []) if w.get("severity") != "info" and w.get("code") not in ignore]
    if dw:
        out.append(_c("dev_warnings", "Avertissements du Développeur", "warn", f"{len(dw)} avertissement(s) non bloquant(s).", dw[:6]))

    # 11. taille
    total = sum(d.added + d.removed for d in diff.values())
    if total > 300:
        out.append(_c("diff_size", "Taille de la modification", "warn", f"{total} lignes modifiées : beaucoup pour un correctif ciblé, à relire avec attention."))
    # 12. effort
    if run.get("replans") or run.get("test_fixes"):
        out.append(_c("effort", "Parcours", "info", f"{run.get('replans', 0)} nouveau(x) plan(s), {run.get('test_fixes', 0)} correction(s) après échec de test."))
    return out


def _stats(run: dict, diff: dict[str, FileDiff], loop: dict, qa: dict) -> Stats:
    summ = qa.get("summary") or {}
    tests = qa.get("tests", [])
    return Stats(files=len(diff), added=sum(d.added for d in diff.values()), removed=sum(d.removed for d in diff.values()), build_rounds=len(loop.get("rounds", [])),
                 tests_total=int(summ.get("total", len(tests))), tests_passed=int(summ.get("passed", sum(1 for t in tests if t.get("status") == "PASS"))),
                 tests_failed=int(summ.get("failed", sum(1 for t in tests if t.get("status") in {"FAIL", "ERROR", "FATAL"}))),
                 tests_selected=[t.get("name") for t in ((qa.get("selection") or {}).get("tests") or [])], replans=run.get("replans", 0), test_fixes=run.get("test_fixes", 0),
                 seconds=float(qa.get("seconds") or 0))
