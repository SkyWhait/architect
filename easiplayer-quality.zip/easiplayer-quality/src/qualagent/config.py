from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="QUAL_", env_file=".env", extra="ignore")

    runs_dir: Path = Path("/data/easiplayer/orch_runs")        # = ORCH_WORK_DIR de l'orchestrateur (les run.json)
    work_dir: Path = Path("./qual_runs")                        # relectures (reviews/) et rapports du matin (reports/)
    api_token: str | None = None

    # LLM facultatif : relecture « le code fait-il ce que le plan demandait ? ». Sans lui, seuls les contrôles déterministes sont faits (et le rapport le dit).
    llm_base_url: str | None = None                             # ex. http://localhost:8000/v1 (vLLM)
    llm_model: str = "Qwen2.5-Coder-32B-Instruct-AWQ"
    llm_api_key: str = "none"
    llm_timeout_s: float = 300.0
    max_diff_chars: int = 24000

    digest_hours: int = 24                                      # fenêtre par défaut du rapport du matin (sinon : depuis le dernier rapport)
    max_build_rounds_ok: int = 1                                # plus de tours de correction de build que ça => avertissement


def get_settings() -> Settings:
    return Settings()
