"""Rendu Markdown (français) : relecture d'UN ticket, et fiche d'un ticket pour le rapport du matin."""
from __future__ import annotations

from .diffs import parse_diff
from .models import QualityReport

ICON = {"ok": "✅", "info": "ℹ️", "warn": "⚠️", "fail": "❌"}
VERDICT = {"approve": "✅ Conforme au plan", "concerns": "⚠️ Conforme avec réserves", "reject": "❌ Non conforme"}


def review_markdown(r: QualityReport) -> str:
    o = [f"# Contrôle qualité — ticket {r.ticket_id}", "", f"**{VERDICT[r.verdict]}** — {r.summary}", ""]
    if r.concerns:
        o += ["## Points à regarder", *[f"{i}. {c}" for i, c in enumerate(r.concerns, 1)], ""]
    o += ["## Contrôles", *[f"- {ICON[c.severity]} **{c.title}** — {c.detail}" for c in r.checks], ""]
    s = r.semantic
    o += ["## Relecture de l'intention du plan"]
    if not s.performed:
        o += [f"_Non effectuée : {s.skipped_reason}_"]
    else:
        o += [f"_Modèle : {s.model}. Chaque constat cite le diff réel ; les affirmations invérifiables sont écartées._", ""]
        o += [f"- {'✅' if f.status == 'implemented' else '⚠️' if f.status in ('partial', 'unclear') else '❌'} `{f.planned_path}` : **{f.status}** — {f.note}"
              + (f"\n  > {f.evidence}" if f.evidence else "") for f in s.findings]
        o += [f"- ⚠️ hors plan `{u.path}` : {u.note}\n  > {u.evidence}" for u in s.unplanned]
        if s.discarded:
            o += ["", f"_{len(s.discarded)} affirmation(s) du LLM écartée(s) car invérifiables._"]
    return "\n".join(o) + "\n"


def diff_table(diff_text: str) -> list[str]:
    files = parse_diff(diff_text)
    if not files:
        return ["_(aucun diff)_"]
    rows = ["| Fichier | + | − |", "|---|---:|---:|"]
    rows += [f"| `{p}`{' (nouveau)' if d.new else ' (supprimé)' if d.deleted else ''} | {d.added} | {d.removed} |" for p, d in files.items()]
    return rows
