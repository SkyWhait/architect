from __future__ import annotations

import argparse
import asyncio
import json
from datetime import datetime, timedelta
from pathlib import Path

from .config import Settings


def main() -> None:
    ap = argparse.ArgumentParser(prog="qualagent", description="Agent qualité : relecture d'un correctif et rapport du matin")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("review", help="relit un run (dossier de l'orchestrateur contenant run.json)")
    r.add_argument("run_dir", type=Path)
    r.add_argument("--no-llm", action="store_true")
    d = sub.add_parser("digest", help="écrit le rapport du matin (à planifier : cron / timer systemd / n8n)")
    d.add_argument("--runs-dir", type=Path)
    d.add_argument("--out", type=Path, help="dossier de sortie (défaut : QUAL_WORK_DIR)")
    d.add_argument("--hours", type=int, help="fenêtre fixe au lieu de « depuis le dernier rapport »")
    d.add_argument("--no-advance", action="store_true", help="ne décale pas la fenêtre du prochain rapport")
    d.add_argument("--print", dest="show", action="store_true")
    s = sub.add_parser("serve")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=8860)
    a = ap.parse_args()
    cfg = Settings()
    if a.cmd == "serve":
        import uvicorn
        uvicorn.run("qualagent.api:create_app", factory=True, host=a.host, port=a.port)
        return
    if a.cmd == "review":
        from .llm import make_llm
        from .report_md import review_markdown
        from .review import review_run
        run = json.loads((a.run_dir / "run.json").read_text())
        rep = asyncio.run(review_run(run, cfg, None if a.no_llm else make_llm(cfg)))
        print(review_markdown(rep))
        raise SystemExit({"approve": 0, "concerns": 0, "reject": 2}[rep.verdict])
    if a.cmd == "digest":
        from .digest import build_digest, write_digest
        if a.runs_dir:
            cfg = cfg.model_copy(update={"runs_dir": a.runs_dir})
        if a.out:
            cfg = cfg.model_copy(update={"work_dir": a.out})
        since = datetime.now().astimezone() - timedelta(hours=a.hours) if a.hours else None
        md, data = build_digest(cfg, since=since)
        path = write_digest(cfg, md, data, advance=not a.no_advance)
        print(md if a.show else f"Rapport écrit : {path}")


if __name__ == "__main__":
    main()
