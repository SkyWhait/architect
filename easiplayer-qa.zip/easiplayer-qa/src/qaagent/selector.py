"""Choix des « bons » tests Squish pour une modification : déterministe, expliqué, vérifiable. Jamais de nom de test inventé.

Signaux (chacun laisse une RAISON lisible dans le rapport) :
  1. suggestion du Stratège  : retenue si le test existe dans le catalogue ; sinon listée dans `unknown_suggestions` (on ne l'ignore pas en silence) ;
  2. table domaine -> zones  : fichiers/symboles modifiés -> zones de tests (table configurable, par défaut celle fournie par l'équipe) ;
  3. recoupement lexical     : mots du changement (chemins, symboles, diff, plan, ticket) contre ce que le test dit et fait réellement
                               (messages de vérification, objets GUI, fichiers de données) pondérés par la rareté du mot (idf) ;
  4. groupes de la suite     : un test retenu qui appartient à un groupe de `Squish_run.sh` le signale (information, pas de sélection supplémentaire).
Sans aucun signal suffisant : sélection VIDE (« aucun test ciblé fiable »), jamais un test choisi au hasard.
"""
from __future__ import annotations

import math
import re
from pathlib import PurePosixPath

from pydantic import BaseModel, Field

from .catalog import Catalog, split_words
from .models import ChangeContext, SelectedTest, Selection

# fichiers/symboles -> zones (sous-chaînes du nom de zone). D'après la correspondance fournie par l'équipe ; à compléter via QA_DOMAIN_MAP.
DEFAULT_DOMAIN_MAP: list[dict] = [
    {"pattern": r"TestCheck|CheckValue|Check2Value|CheckReceived|Sequencer|Timer|Delay", "zones": ["CHECK_OPER", "SEQUENCER"], "why": "séquenceur / checks temporisés"},
    {"pattern": r"ScriptEngine|/custom/|QScript|javascript|\bJS\b", "zones": ["JAVA_SCRIPT_USE"], "why": "moteur de scripts JavaScript"},
    {"pattern": r"[Aa]vatar|A2xtp|InterfaceItem|1553|find1553", "zones": ["AVATAR_CONVERSION"], "why": "import Avatar / interfaces 1553"},
    {"pattern": r"Information|IcdFinder|FieldValidator|MinMax|numeric|UCHAR|USHORT|LONGLONG", "zones": ["_CHECKS"], "why": "types de variables et limites"},
    {"pattern": r"[Pp]lugin|DBus|Dbus|Agent", "zones": ["PLUGIN_API", "AGENT_CHECKS"], "why": "plugins / D-Bus / agent"},
    {"pattern": r"[Bb]atch", "zones": ["BATCH_MODE"], "why": "mode batch"},
]

# groupes définis dans Squish_run.sh (-o group1..group4), recopiés du script réel ; remplaçables via QA_SUITE_GROUPS
DEFAULT_GROUPS: dict[str, list[str]] = {
    "group1": ["INTERNAL_VARIABLE-00001", "STP_CREATION-00001", "STP_BLOCK-00001", "CONFIG_DIRECTORIES-00001", "STP_EXTERNAL-00001", "STP-LOADING_SAVING-00001",
               "STP_EXTERNAL-00002", "REPORT-00001", "GRAMMAR_CHECKS-00001", "TYPE_CONSISTENCY-00001"],
    "group2": ["INFO_IDENTIFICATION-00001", "CHAR_CHECKS-00001", "USHORT_CHECKS-00001", "SHORT_CHECKS-00001", "ULONG_CHECKS-00001", "LONG_CHECKS-00001", "FLOAT_CHECKS-00001",
               "DOUBLE_CHECKS-00001", "ENUM_CHECKS-00001", "ULONGLONG_CHECKS-00001", "LONGLONG_CHECKS-00001", "STRING_CHECKS-00001"],
    "group3": ["TEST_SESSION-00001", "SIGNED_MODE-00001", "BATCH_MODE-00001", "INTERACTIVE_MODE-00001"],
    "group4": ["ARRAY_PARSER-00001", "MARGIN-00001", "COPY_OPER-00001", "INTERACTIVE_MODE-00001", "TYPE_CONSISTENCY-00001", "PERFO-00001", "PRESS_OPER-00001",
               "AVATAR_CONVERSION-00001", "INIT_OPER-00001", "MAIN_WIDGETS-00002", "PLUGIN_API-00001"],
}


def _short(name: str) -> str:
    return name.removeprefix("tst_STD-EAP-")


def change_tokens(ch: ChangeContext) -> dict[str, list[str]]:
    """Mots du changement, par provenance (pour expliquer le recoupement)."""
    paths = " ".join(f"{PurePosixPath(p).stem} {p}" for p in ch.files)
    diff_ids = " ".join(re.findall(r"^[+-](?![+-]).*$", ch.diff, flags=re.M)[:400]) if ch.diff else ""
    return {"files": split_words(paths), "symbols": split_words(" ".join(ch.symbols)), "diff": split_words(diff_ids), "plan": split_words(ch.plan_text), "ticket": split_words(ch.ticket_text)}


def select_tests(ch: ChangeContext, cat: Catalog, *, domain_map: list[dict] | None = None, groups: dict[str, list[str]] | None = None,
                 max_tests: int = 6, min_score: float = 4.0) -> Selection:
    dmap = domain_map if domain_map is not None else DEFAULT_DOMAIN_MAP
    groups = groups if groups is not None else DEFAULT_GROUPS
    cards = cat.cards
    sel = Selection(catalog_size=len(cards))
    if not cards:
        sel.note = "Catalogue de tests vide : aucun test ciblé possible (dossier de suite introuvable ou sans test)."
        return sel
    score: dict[str, float] = {k: 0.0 for k in cards}
    why: dict[str, list[str]] = {k: [] for k in cards}

    # 1. suggestions du Stratège
    for s in ch.suggested_tests:
        name = s.split("/")[-1].strip()
        cand = name if name in cards else next((k for k in cards if k.endswith(name) or _short(k) == name), None)
        if cand:
            score[cand] += 10
            why[cand].append("suggested by the Strategist's plan")
        else:
            sel.unknown_suggestions.append(s)

    # 2. table domaine -> zones
    probe = " ".join([*ch.files, *ch.symbols])
    for rule in dmap:
        if re.search(rule["pattern"], probe):
            hit = [r for r in ch.files + ch.symbols if re.search(rule["pattern"], r)][:2]
            for k, c in cards.items():
                if any(z in c.zone for z in rule["zones"]):
                    score[k] += 6
                    why[k].append(f"domain rule ({rule.get('why', rule['pattern'])}): matches {', '.join(hit)}")

    # 3. recoupement lexical pondéré par la rareté
    n = len(cards)
    df: dict[str, int] = {}
    for c in cards.values():
        for t in c.tokens:
            df[t] = df.get(t, 0) + 1
    ct = change_tokens(ch)
    weight = {"files": 1.0, "symbols": 1.2, "diff": 0.6, "plan": 0.5, "ticket": 0.5}
    best: dict[str, float] = {}
    origin: dict[str, str] = {}
    for src, toks in ct.items():
        for t in set(toks):
            if t in df and df[t] < n * 0.5:
                best[t] = max(best.get(t, 0), weight[src] * math.log(1 + n / df[t]))
                origin.setdefault(t, src)
    for k, c in cards.items():
        common = [t for t in c.tokens if t in best]
        if common:
            lex = min(6.0, sum(best[t] for t in common))
            score[k] += lex
            top = sorted(common, key=lambda t: -best[t])[:4]
            why[k].append("shares words with the change: " + ", ".join(f"{t} ({origin[t]})" for t in top))

    ranked = sorted((k for k in cards if score[k] >= min_score), key=lambda k: (-score[k], k))[:max_tests]
    in_groups = {k: [g for g, names in groups.items() if _short(k) in names] for k in ranked}
    for k in ranked:
        c = cards[k]
        sel.tests.append(SelectedTest(name=k, score=round(score[k], 1), reasons=why[k], tests_what=c.summary(), groups=in_groups[k]))
    if not ranked:
        sel.note = "Aucun test du catalogue n'a de lien assez net avec ce changement : pas de sélection ciblée (la suite complète reste le filet de sécurité)."
    return sel
