"""qaagent : agent QA (validation Squish) — non-régression comportementale décidée sur les RAPPORTS, jamais sur le code de sortie."""
__version__ = "0.1.0"
