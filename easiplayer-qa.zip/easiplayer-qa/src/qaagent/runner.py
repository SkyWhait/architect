"""Exécution des commandes de l'opérateur (Squish_run.sh, préparation, nettoyage) : sans shell implicite, journal, timeout, arrêt du groupe de processus.

Une suite Squish dure des heures : l'état du run (pid, progression) est écrit sur disque (run.json) pour pouvoir reprendre le suivi
si le service est redémarré pendant le run (voir adopt dans api.py).
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import signal
import time
from pathlib import Path
from typing import Callable

from .config import Settings
from .models import BuildIn, RunInfo
from .squish_parser import progress_from_line

BASE_ENV = {"LC_ALL": "C.UTF-8", "TERM": "dumb", "NO_COLOR": "1"}
_PH = re.compile(r"\{(results_dir|ticket|testcases_joined|testcases|keys)\}|\{build_dir:([\w.-]+)\}")


class RunState:
    """run.json : ce que le service sait d'un run en cours (survit à un redémarrage du service)."""

    def __init__(self, path: Path):
        self.path = path

    def write(self, **kv) -> None:
        cur = self.read()
        cur.update(kv)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(cur, indent=1, default=str))
        os.replace(tmp, self.path)

    def read(self) -> dict:
        try:
            return json.loads(self.path.read_text())
        except (OSError, ValueError):
            return {}


def build_dirs(build: BuildIn | None, cfg: Settings) -> dict[str, Path]:
    """Dossiers de build du Compilateur, retrouvés dans ses commandes (`-B <dir>` / `--build <dir>`), limités aux racines autorisées."""
    out: dict[str, Path] = {}
    for st in (build.steps if build else []):
        cmd = st.get("command") or []
        for flag in ("-B", "--build"):
            if flag in cmd and cmd.index(flag) + 1 < len(cmd):
                p = Path(cmd[cmd.index(flag) + 1]).resolve()
                if not cfg.build_roots or any(r.resolve() == p or r.resolve() in p.parents for r in cfg.build_roots):
                    out[st.get("repo", "")] = p
    return out


def expand(args: list[str], *, results_dir: Path, ticket: str, bdirs: dict[str, Path], testcases: list[str] | None = None,
           keys: list[str] | None = None, join: str = " ") -> list[str]:
    def sub(m: re.Match) -> str:
        if m.group(2):
            if m.group(2) not in bdirs:
                raise KeyError(f"build_dir inconnu pour {m.group(2)!r} (pas dans le rapport du Compilateur ou hors QA_BUILD_ROOTS)")
            return str(bdirs[m.group(2)])
        return {"results_dir": str(results_dir), "ticket": ticket, "testcases": join.join(testcases or []), "testcases_joined": join.join(testcases or []), "keys": join.join(keys or [])}[m.group(1)]

    out = []
    for a in args:
        if a == "{testcases}":
            out += testcases or []                         # un argument par test (évite tout problème d'échappement)
        elif a == "{keys}":
            out += keys or []
        else:
            out.append(_PH.sub(sub, a))
    return out


async def run_command(cmd: list[str], *, cwd: Path | None, env_extra: dict[str, str], log_path: Path, timeout: float, xvfb: bool = False,
                      state: RunState | None = None, stage: str = "") -> RunInfo:
    info = RunInfo(command=cmd, log_path=str(log_path))
    if xvfb and shutil.which("xvfb-run"):
        cmd = ["xvfb-run", "-a", *cmd]
    env = {**os.environ, **BASE_ENV, **env_extra}
    log_path.parent.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    try:
        proc = await asyncio.create_subprocess_exec(*cmd, cwd=cwd, env=env, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
                                                    start_new_session=True, limit=4 * 1024 * 1024)
    except (FileNotFoundError, PermissionError, NotADirectoryError) as e:
        info.note = f"impossible de lancer {cmd[0]!r} : {e}"
        return info
    if state:
        state.write(pid=proc.pid, stage=stage, started=t0, command=cmd, log_path=str(log_path), state="running")
    progress: dict = {}

    async def pump() -> None:
        n, last_write = 0, time.time()
        with open(log_path, "wb") as f:
            assert proc.stdout is not None
            while True:
                try:
                    line = await proc.stdout.readline()
                except (asyncio.LimitOverrunError, ValueError):
                    line = (await proc.stdout.read(65536)) + b"\n"
                if not line:
                    break
                f.write(line)
                f.flush()
                n += 1
                progress_from_line(line.decode("utf-8", "replace"), progress)
                if state and time.time() - last_write > 20:
                    state.write(progress=progress, log_lines=n, heartbeat=time.time())
                    last_write = time.time()

    try:
        await asyncio.wait_for(asyncio.gather(pump(), proc.wait()), timeout=timeout)
        info.exit_code = proc.returncode
    except asyncio.TimeoutError:
        info.timed_out, info.note = True, f"timeout après {int(timeout)} s : processus arrêtés"
        _kill(proc)
        await proc.wait()
    except asyncio.CancelledError:
        _kill(proc)
        raise
    info.seconds = round(time.time() - t0, 1)
    if state:
        state.write(progress=progress, heartbeat=time.time())
    return info


def _kill(proc: asyncio.subprocess.Process) -> None:
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass


def pid_alive(pid: int, expect: str = "") -> bool:
    """Le processus existe ET c'est bien le nôtre (pas un pid réutilisé après un redémarrage de la machine)."""
    try:
        os.kill(pid, 0)
    except (ProcessLookupError, PermissionError):
        return False
    try:
        cmdline = Path(f"/proc/{pid}/cmdline").read_bytes().decode("utf-8", "replace")
    except OSError:
        return True
    return not expect or os.path.basename(expect) in cmdline


def tail(path: Path, n: int = 60) -> str:
    try:
        return "\n".join(path.read_bytes().decode("utf-8", "replace").splitlines()[-n:])
    except OSError:
        return ""
