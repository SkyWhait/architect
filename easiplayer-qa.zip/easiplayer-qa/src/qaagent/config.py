from __future__ import annotations

from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="QA_", env_file=".env", extra="ignore")

    work_dir: Path = Path("./qa_runs")
    baseline_dir: Path = Path("./qa_baseline")

    # --- la suite complète : TA commande (liste JSON, jamais un texte fourni par un LLM) -------------------------------
    # Placeholders : {results_dir} {ticket} {build_dir:<Repo>} ({testcases} dans targeted_command / rerun_command)
    run_command: list[str] = Field(default_factory=lambda: ["./Squish_run.sh", "-o", "all"])
    run_cwd: Path | None = None
    results_env_var: str = "RESULTS_FOLDER"          # variable d'environnement lue par le script pour écrire ses résultats
    results_dir_override: Path | None = None         # si le script écrit ailleurs, en dur : dossier à analyser (et à vider avant le run)
    env: dict[str, str] = Field(default_factory=dict)
    timeout_s: int = 10 * 3600                       # la suite dure ~6 h : marge raisonnable

    # --- intégration avec le vrai Squish_run.sh (voir squish_env.py) ------------------------------------------------------------
    squish_dir: Path | None = None                   # ex. /data/easiplayer/EasiPlayerSquishTests : déduit commandes, dossier de résultats, suite, licence
    suite_dir: Path | None = None                    # dossier de la suite (suite_EasiPlayer) : catalogue des tests ; sinon déduit de Environment.sh
    check_license: bool = True
    domain_map: list[dict] | None = None             # fichiers/symboles -> zones de tests (défaut : selector.DEFAULT_DOMAIN_MAP)
    suite_groups: dict[str, list[str]] | None = None # groupes group1..4 de Squish_run.sh (défaut : selector.DEFAULT_GROUPS)
    max_targeted: int = 6
    min_select_score: float = 4.0

    # --- étapes facultatives ---------------------------------------------------------------------------------------------------
    prepare_command: list[str] | None = None         # ex. installer le build du Compilateur là où Squish lance l'AUT
    prepare_timeout_s: int = 1800
    cleanup_command: list[str] | None = None         # ex. arrêter squishserver / tuer les AUT restants (toujours exécuté)
    targeted_command: list[str] | None = None        # lancer SEULEMENT certains tests, d'abord (échec rapide). ex. ["./Squish_run.sh","-o","{testcases}"]
    rerun_command: list[str] | None = None           # rejouer UN test échoué (détection des tests instables). ex. ["./Squish_run.sh","-o","{testcases}"]
    max_reruns: int = 1
    testcase_join: str = " "                         # séparateur utilisé pour {testcases}
    xvfb: bool = False                               # enrober avec `xvfb-run -a` (serveur X virtuel) si l'AUT a besoin d'un affichage

    # --- règles de verdict ------------------------------------------------------------------------------------------------------------
    suites_dir: Path | None = None                   # dossier des suites Squish (suite_*/tst_*) : sert à détecter les tests NON exécutés
    flaky_is_failure: bool = False                   # un test qui échoue puis passe au rejeu : avertissement (False) ou échec (True)
    fail_on_missing: bool = True                     # tests attendus absents du rapport => « incomplete »
    max_failures_listed: int = 15

    # --- sécurité : on ne publie des « build_dir » que sous ces racines (placeholders) -----------------------------------------------
    build_roots: list[Path] = Field(default_factory=list)

    # --- lien optionnel avec l'Agent Architecte (suspects C++) --------------------------------------------------------------------
    architect_url: str | None = None
    architect_token: str | None = None
    api_token: str | None = None


def get_settings() -> Settings:
    s = Settings()
    s.work_dir.mkdir(parents=True, exist_ok=True)
    s.baseline_dir.mkdir(parents=True, exist_ok=True)
    return s
