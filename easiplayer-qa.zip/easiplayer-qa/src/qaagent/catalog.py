"""Catalogue des tests Squish : ce que CHAQUE test vérifie, lu dans ses sources (jamais deviné).

Pour chaque `tst_*` : zone et numéro (d'après le nom `tst_STD-EAP-<ZONE>-<N>`), commentaires, messages des vérifications `test.compare/verify/...`
(l'intention du test, en clair), objets GUI utilisés (`names.xxx` décrits par `names.py`), fichiers de données chargés, scripts partagés (`source(findFile(...))`,
analysés eux aussi). Les tests Squish Python (`test.py`) sont analysés avec `ast` ; les tests JavaScript (`test.js`) par expressions régulières (moins précis).
"""
from __future__ import annotations

import ast
import hashlib
import io
import re
import tokenize
from pathlib import Path

from pydantic import BaseModel, Field

NAME_RE = re.compile(r"^tst_STD-EAP-(?P<zone>.+)-(?P<num>\d+)$")
TEST_METHODS = {"compare", "verify", "fail", "fatal", "passes", "warning", "xcompare", "xverify", "vp", "log", "startSection", "endSection"}
ACTION_CALLS = {"startApplication", "attachToApplication", "clickButton", "mouseClick", "doubleClick", "type", "typeText", "setText", "invokeMenuItem",
                "activateItem", "waitForObject", "waitForObjectExists", "waitFor", "snooze", "selectOption", "clickTab", "openContextMenu", "installEventHandler"}
_FILE_RE = re.compile(r"^[\w .\-/\\]+\.[A-Za-z0-9]{1,5}$")
_WORD = re.compile(r"[A-Za-z][A-Za-z0-9]+")
STOP = {"the", "and", "for", "with", "from", "that", "this", "test", "tests", "names", "true", "false", "none", "main", "def", "import", "squish", "object", "waitforobject"}


class Verification(BaseModel):
    line: int
    method: str
    message: str = ""


class ObjectInfo(BaseModel):
    name: str
    type: str = ""
    text: str = ""
    object_name: str = ""

    def describe(self) -> str:
        bits = [self.type, f"'{self.text}'" if self.text else "", f"objectName={self.object_name}" if self.object_name else ""]
        return f"{self.name}: " + " ".join(b for b in bits if b)


class TestCard(BaseModel):
    __test__ = False
    name: str
    zone: str = ""
    number: int = 0
    path: str = ""
    language: str = "python"
    notes: list[str] = Field(default_factory=list)                  # docstring + commentaires (intention écrite par les auteurs)
    verifications: list[Verification] = Field(default_factory=list)
    actions: list[str] = Field(default_factory=list)
    objects: list[ObjectInfo] = Field(default_factory=list)
    data_files: list[str] = Field(default_factory=list)
    shared_scripts: list[str] = Field(default_factory=list)
    helpers: list[str] = Field(default_factory=list)                # fonctions définies dans le test
    tokens: list[str] = Field(default_factory=list)
    digest: str = ""

    def summary(self, n: int = 4) -> str:
        msgs = [v.message for v in self.verifications if v.message and v.method not in {"log", "startSection", "endSection"}][:n]
        head = (self.notes[0] if self.notes else "")[:160]
        return "; ".join(x for x in [head, *msgs] if x)[:400]


class Catalog(BaseModel):
    suite: str = ""
    cards: dict[str, TestCard] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)

    def zones(self) -> dict[str, list[str]]:
        out: dict[str, list[str]] = {}
        for c in self.cards.values():
            out.setdefault(c.zone, []).append(c.name)
        return out


def split_words(s: str) -> list[str]:
    out: list[str] = []
    for w in _WORD.findall(s or ""):
        w2 = re.sub(r"([A-Za-z])(\d)", r"\1 \2", re.sub(r"(\d)([A-Za-z])", r"\1 \2", w))          # TestCheck2Value -> test check 2 value
        for p in re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", w2).replace("_", " ").split():
            p = p.lower()
            if len(p) >= 3 and p not in STOP:
                out.append(p)
    return out


# ======================================================================= names.py (carte d'objets)
def parse_names(path: Path) -> dict[str, ObjectInfo]:
    """`mRunBt = {"container": names.x, "text": "Run", "type": "QPushButton"}` -> {name: ObjectInfo}. Tolérant : un fichier illisible donne une carte vide."""
    try:
        tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
    except (OSError, SyntaxError):
        return {}
    out: dict[str, ObjectInfo] = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and isinstance(node.value, ast.Dict):
            props = {k.value: v.value for k, v in zip(node.value.keys, node.value.values)
                     if isinstance(k, ast.Constant) and isinstance(v, ast.Constant)}
            nm = node.targets[0].id
            out[nm] = ObjectInfo(name=nm, type=str(props.get("type", "")), text=str(props.get("text", "")), object_name=str(props.get("objectName", "")))
    return out


# ======================================================================= analyse d'un script
def _comments(src: str) -> list[str]:
    out = []
    try:
        for tok in tokenize.generate_tokens(io.StringIO(src).readline):
            if tok.type == tokenize.COMMENT:
                t = tok.string.lstrip("#").strip()
                if len(t) > 3 and not t.startswith(("-*-", "!/", "coding")):
                    out.append(t)
    except (tokenize.TokenError, IndentationError):
        pass
    return out


def _const_str(n: ast.AST) -> str:
    return n.value if isinstance(n, ast.Constant) and isinstance(n.value, str) else ""


class _Scan(ast.NodeVisitor):
    def __init__(self):
        self.verifs: list[Verification] = []
        self.actions: list[str] = []
        self.objects: list[str] = []
        self.files: list[str] = []
        self.shared: list[str] = []
        self.helpers: list[str] = []
        self.strings: list[str] = []

    def visit_FunctionDef(self, n):
        self.helpers.append(n.name)
        self.generic_visit(n)

    def visit_Attribute(self, n):
        if isinstance(n.value, ast.Name) and n.value.id == "names":
            self.objects.append(n.attr)
        self.generic_visit(n)

    def visit_Call(self, n):
        f = n.func
        if isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) and f.value.id == "test" and f.attr in TEST_METHODS:
            msg = ""
            for a in [*n.args, *[k.value for k in n.keywords if k.arg in {"message", "msg"}]][::-1]:      # le message est le dernier argument texte
                msg = _const_str(a)
                if msg:
                    break
            self.verifs.append(Verification(line=n.lineno, method=f.attr, message=msg))
        name = f.id if isinstance(f, ast.Name) else (f.attr if isinstance(f, ast.Attribute) else "")
        if name in ACTION_CALLS and name not in self.actions:
            self.actions.append(name)
        is_script_lookup = name == "findFile" and n.args and _const_str(n.args[0]) == "scripts"        # findFile("scripts", "x.py") : script partagé, pas une donnée
        if not is_script_lookup and (name in {"findFile", "open", "loadData", "dataset", "testData"} or (isinstance(f, ast.Attribute) and f.attr in {"dataset", "field"})):
            for a in n.args:
                s = _const_str(a)
                if s and _FILE_RE.match(s) and s not in self.files:
                    self.files.append(s)
        if name == "source" and n.args:                                   # source(findFile("scripts", "common.py"))
            for sub in ast.walk(n.args[0]):
                s = _const_str(sub)
                if s and s.endswith((".py", ".js")) and s not in self.shared:
                    self.shared.append(s)
        self.generic_visit(n)

    def visit_Constant(self, n):
        if isinstance(n.value, str) and 3 < len(n.value) < 120:
            self.strings.append(n.value)


def _scan_python(src: str) -> tuple[_Scan, list[str]]:
    tree = ast.parse(src)
    s = _Scan()
    s.visit(tree)
    notes = ([ast.get_docstring(tree)] if ast.get_docstring(tree) else []) + _comments(src)
    return s, [n.strip() for n in notes if n][:20]


_JS_VERIF = re.compile(r"test\.(compare|verify|fail|fatal|passes|warning|log)\s*\((.*)\)\s*;?\s*$")
_JS_STR = re.compile(r"\"((?:\\.|[^\"\\])*)\"|'((?:\\.|[^'\\])*)'")


def _scan_js(src: str) -> tuple[_Scan, list[str]]:
    s, notes = _Scan(), []
    for i, line in enumerate(src.splitlines(), 1):
        if line.strip().startswith("//"):
            notes.append(line.strip().lstrip("/ ").strip())
        m = _JS_VERIF.search(line.strip())
        if m:
            strs = [a or b for a, b in _JS_STR.findall(m.group(2))]
            s.verifs.append(Verification(line=i, method=m.group(1), message=strs[-1] if strs else ""))
        for o in re.findall(r"names\.(\w+)", line):
            s.objects.append(o)
        for a in ACTION_CALLS:
            if re.search(rf"\b{a}\s*\(", line) and a not in s.actions:
                s.actions.append(a)
        for m2 in re.finditer(r"source\(findFile\(\s*[\"']scripts[\"']\s*,\s*[\"']([^\"']+)[\"']", line):
            s.shared.append(m2.group(1))
        for m3 in re.finditer(r"function\s+(\w+)", line):
            s.helpers.append(m3.group(1))
    return s, [n for n in notes if len(n) > 3][:20]


# ======================================================================= le catalogue
def _find_shared(suite: Path, test_dir: Path, fname: str) -> Path | None:
    for base in (test_dir, suite / "shared" / "scripts", suite / "shared", suite, suite.parent / "shared" / "scripts"):
        p = base / fname
        if p.is_file():
            return p
    return None


def build_catalog(suite_dir: Path) -> Catalog:
    cat = Catalog(suite=suite_dir.name)
    if not suite_dir.is_dir():
        cat.warnings.append(f"dossier de suite introuvable : {suite_dir}")
        return cat
    suite_names = {}
    for cand in (suite_dir / "shared" / "scripts" / "names.py", suite_dir / "names.py"):
        suite_names.update(parse_names(cand))
    for tdir in sorted(p for p in suite_dir.glob("tst_*") if p.is_dir()):
        script = next((tdir / n for n in ("test.py", "test.js") if (tdir / n).is_file()), None)
        if script is None:
            cat.warnings.append(f"{tdir.name} : ni test.py ni test.js")
            continue
        lang = "python" if script.suffix == ".py" else "javascript"
        src = script.read_text(encoding="utf-8", errors="replace")
        try:
            scan, notes = _scan_python(src) if lang == "python" else _scan_js(src)
        except SyntaxError as e:
            cat.warnings.append(f"{tdir.name} : test.py illisible pour l'analyse ({e.msg} ligne {e.lineno}) : analyse par expressions régulières")
            scan, notes = _scan_js(src)
        for sh in list(scan.shared):                                              # scripts partagés : leurs vérifications font partie du test
            p = _find_shared(suite_dir, tdir, sh)
            if p is None:
                continue
            try:
                s2, n2 = (_scan_python if p.suffix == ".py" else _scan_js)(p.read_text(encoding="utf-8", errors="replace"))
            except SyntaxError:
                continue
            scan.verifs += [Verification(line=v.line, method=v.method, message=f"[{sh}] {v.message}".strip()) for v in s2.verifs if v.message]
            scan.objects += s2.objects
            scan.files += [f for f in s2.files if f not in scan.files]
            notes += n2[:5]
        local_names = {**suite_names, **parse_names(tdir / "names.py")}
        objs = [local_names.get(o, ObjectInfo(name=o)) for o in dict.fromkeys(scan.objects)]
        m = NAME_RE.match(tdir.name)
        toks = split_words(" ".join([m.group("zone") if m else tdir.name, *notes, *[v.message for v in scan.verifs], *[o.name + " " + o.text + " " + o.object_name for o in objs],
                                     *scan.files, *scan.helpers]))
        cat.cards[tdir.name] = TestCard(
            name=tdir.name, zone=m.group("zone") if m else "", number=int(m.group("num")) if m else 0, path=str(script), language=lang,
            notes=notes, verifications=scan.verifs, actions=scan.actions, objects=objs, data_files=scan.files, shared_scripts=scan.shared, helpers=scan.helpers,
            tokens=sorted(set(toks)), digest=hashlib.sha1(src.encode()).hexdigest()[:12])
    return cat
