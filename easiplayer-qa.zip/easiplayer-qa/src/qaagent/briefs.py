"""Du résultat brut Squish à une explication exploitable par le Développeur : ce que le test vérifie, quelle vérification a échoué (avec la ligne du script de test),
quel objet GUI, ce que le test faisait juste avant, et quelles parties de SA modification recoupent ce test."""
from __future__ import annotations

from pathlib import Path, PurePosixPath

from .catalog import Catalog, TestCard, split_words
from .models import ChangeContext, Classified, FailureBrief, Selection, TestCaseResult


def source_line(card: TestCard | None, line: int, around: int = 1) -> str:
    if card is None or not line or not card.path:
        return ""
    try:
        lines = Path(card.path).read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return ""
    lo, hi = max(1, line - around), min(len(lines), line + around)
    return "\n".join(f"{n}: {lines[n - 1].rstrip()}" for n in range(lo, hi + 1))[:400]


def related_changes(card: TestCard | None, ch: ChangeContext | None) -> list[str]:
    """Fichiers/symboles modifiés qui partagent des mots avec ce test (ce que le test dit ou fait) : où chercher dans SA modification."""
    if card is None or ch is None:
        return []
    ctoks = set(card.tokens)
    out = []
    for item in [*ch.files, *ch.symbols]:
        common = sorted(set(split_words(f"{PurePosixPath(item).stem} {item}")) & ctoks)
        if common:
            out.append(f"{item} (shares: {', '.join(common[:4])})")
    return out[:6]


def make_brief(t: TestCaseResult, c: Classified, card: TestCard | None, ch: ChangeContext | None, sel: Selection | None, baseline_note: str) -> FailureBrief:
    chosen = next((s for s in (sel.tests if sel else []) if s.name == t.name), None)
    f0 = t.failures[0] if t.failures else None
    failed = {}
    if f0:
        failed = {"kind": f0.kind, "verification": f0.verification, "message": f0.message, "detail": f0.detail[:400], "script": f0.script, "line": f0.line,
                  "source": source_line(card, f0.line)}
    objs = []
    if f0 and f0.object_name and card:
        key = f0.object_name.split(".")[-1].rsplit("_", 1)[0]                      # « :MainWindow.Run_QPushButton » -> « Run »
        objs = [o.describe() for o in card.objects if key and (o.name == key or o.text == key or o.object_name == key or key in o.name)][:3] or [f0.object_name]
    elif f0 and f0.object_name:
        objs = [f0.object_name]
    b = FailureBrief(test=t.name, zone=card.zone if card else "", outcome=c.outcome, tests_what=(card.summary() if card else ""),
                     why_selected=(chosen.reasons if chosen else []), failed=failed,
                     steps_before=t.log[-5:], gui_objects=objs, related_changes=related_changes(card, ch), suspects=[s.get("ref", "") for s in c.suspects],
                     baseline=baseline_note)
    b.text = brief_text(b, t)
    return b


def brief_text(b: FailureBrief, t: TestCaseResult) -> str:
    o = [f"FAILING TEST: {b.test}" + (f" (zone {b.zone})" if b.zone else "") + f" — {'NEW failure' if b.outcome == 'new_failure' else b.outcome}; {b.baseline}"]
    if b.tests_what:
        o.append(f"What this test verifies: {b.tests_what}")
    if b.why_selected:
        o.append("Why it was run for your change: " + "; ".join(b.why_selected)[:300])
    if b.failed:
        f = b.failed
        where = f" at {f.get('script')}:{f.get('line')}" if f.get("script") or f.get("line") else ""
        o.append(f"Failure: [{f.get('kind')}] {f.get('verification') or 'result'}{where}: {f.get('message') or f.get('detail')}")
        if f.get("detail") and f.get("detail") != f.get("message"):
            o.append(f"  detail: {f['detail'][:300]}")
        if f.get("source"):
            o.append("  test code:\n    " + f["source"].replace("\n", "\n    "))
    if b.gui_objects:
        o.append("GUI object(s): " + "; ".join(b.gui_objects))
    if b.steps_before:
        o.append("Last steps before the failure: " + " | ".join(b.steps_before)[:300])
    if b.related_changes:
        o.append("Parts of YOUR change related to this test: " + "; ".join(b.related_changes))
    if b.suspects:
        o.append("Other suspect C++ files (index search, heuristic): " + ", ".join(b.suspects))
    return "\n".join(o)


def developer_feedback(briefs: list[FailureBrief], reason: str) -> str:
    if not briefs:
        return ""
    return (f"The Squish tests do NOT pass with your change. {reason}\n\n" + "\n\n".join(f"### {i}. {b.text}" for i, b in enumerate(briefs, 1))
            + "\n\nFix the change so that these tests pass without breaking what it was meant to fix. Do not edit the tests.")
