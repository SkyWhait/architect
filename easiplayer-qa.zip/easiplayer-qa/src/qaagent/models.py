"""Modèles : requête (succès du Compilateur), résultats de tests normalisés, rapport QA."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

Status = Literal["pass", "fail", "error", "skipped"]


class _In(BaseModel):
    model_config = ConfigDict(extra="ignore")


# ===================== entrée : rapport du Compilateur (sous-ensemble tolérant) ========================
class BuildIn(_In):
    """`build_report.json` ou `loop_report.json` du Compilateur : on n'exige que le succès et les emplacements."""
    ticket_id: str
    status: str
    status_reason: str = ""
    final: dict | None = None                 # loop_report : le dernier build
    steps: list[dict] = Field(default_factory=list)


class ChangeContext(_In):
    """Ce que le Développeur a modifié et pourquoi : sert à choisir les BONS tests et à relier un échec à la modification."""
    files: list[str] = Field(default_factory=list)            # fichiers modifiés (chemins du plan)
    symbols: list[str] = Field(default_factory=list)
    diff: str = ""
    plan_text: str = ""                                       # cause racine + changements prévus (rapport du Stratège)
    ticket_text: str = ""
    suggested_tests: list[str] = Field(default_factory=list)  # tests proposés par le Stratège (heuristique : validés contre le catalogue)


class QARequest(BaseModel):
    ticket_id: str | None = None
    build: BuildIn | None = None              # le « signal » : le Compilateur a réussi
    testcases: list[str] | None = None        # tests à lancer d'abord, imposés (sinon sélection d'après `change`)
    skip_gate: bool = False                   # lancer sans rapport de compilation (usage manuel, ex. validation d'un build existant)
    change: ChangeContext | None = None       # la modification à valider : active la SÉLECTION des tests
    scope: Literal["targeted", "full"] = "full"   # "targeted" : seulement les tests choisis (boucle rapide avec le Développeur) ; "full" : + suite complète
    focus_tests: list[str] = Field(default_factory=list)      # tests déjà en échec au tour précédent : toujours rejoués


# ===================== résultats de tests ===========================================================
class Failure(BaseModel):
    kind: str                                 # FAIL | ERROR | FATAL | XPASS | WARNING
    verification: str = ""                    # « Comparison », « Screenshot verification »…
    message: str = ""
    detail: str = ""
    script: str = ""                          # x-testcase:/test.py
    line: int = 0
    object_name: str = ""                     # :MainWindow.Start_QPushButton
    attachments: list[str] = Field(default_factory=list)       # images en échec, captures
    section: str = ""


class TestCaseResult(BaseModel):
    __test__ = False                          # pas une classe de test pour pytest
    suite: str = ""
    name: str
    status: Status
    seconds: float = 0.0
    verifications: int = 0
    passed: int = 0
    failures: list[Failure] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    log: list[str] = Field(default_factory=list)
    retried: int = 0
    source: str = ""                          # fichier de résultats d'origine

    @property
    def key(self) -> str:
        return f"{self.suite}/{self.name}" if self.suite else self.name


class SelectedTest(BaseModel):
    name: str
    score: float
    reasons: list[str] = Field(default_factory=list)
    tests_what: str = ""                      # ce que le test vérifie (extrait de ses sources)
    groups: list[str] = Field(default_factory=list)


class Selection(BaseModel):
    tests: list[SelectedTest] = Field(default_factory=list)
    unknown_suggestions: list[str] = Field(default_factory=list)   # suggestions du Stratège absentes du catalogue (jamais ignorées en silence)
    note: str = ""
    catalog_size: int = 0


class FailureBrief(BaseModel):
    """Ce qu'il faut dire au Développeur d'un test en échec : ce que le test vérifie, ce qui a échoué, où, et ce qui, dans SA modification, est probablement en cause."""
    test: str
    zone: str = ""
    outcome: str = "new_failure"
    tests_what: str = ""
    why_selected: list[str] = Field(default_factory=list)
    failed: dict = Field(default_factory=dict)                      # kind, verification, message, detail, script, line, source
    steps_before: list[str] = Field(default_factory=list)
    gui_objects: list[str] = Field(default_factory=list)
    related_changes: list[str] = Field(default_factory=list)
    suspects: list[str] = Field(default_factory=list)
    baseline: str = ""
    text: str = ""                                                   # version rédigée (anglais) pour le prompt du Développeur


class Classified(BaseModel):
    key: str
    outcome: Literal["pass", "new_failure", "known_failure", "flaky", "fixed", "skipped", "xfail_ok"]
    first: Status
    final: Status
    runs: int = 1
    suspects: list[dict] = Field(default_factory=list)         # fichiers C++ probables (Architecte), heuristique


class RunInfo(BaseModel):
    command: list[str] = Field(default_factory=list)
    exit_code: int | None = None
    seconds: float = 0.0
    timed_out: bool = False
    log_path: str = ""
    results_dir: str = ""
    result_files: list[str] = Field(default_factory=list)
    note: str = ""


class QAReport(BaseModel):
    schema_version: str = "1.0"
    ticket_id: str
    status: Literal["passed", "failed", "incomplete", "error", "rejected"]
    verdict_reason: str = ""
    summary: dict[str, int] = Field(default_factory=dict)
    new_failures: list[str] = Field(default_factory=list)
    known_failures: list[str] = Field(default_factory=list)
    flaky: list[str] = Field(default_factory=list)
    fixed: list[str] = Field(default_factory=list)
    missing_tests: list[str] = Field(default_factory=list)
    classified: list[Classified] = Field(default_factory=list)
    tests: list[TestCaseResult] = Field(default_factory=list)           # résultats FINAUX (après rejeux)
    runs: list[RunInfo] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    baseline: str = ""                                                   # « présente (date) » ou « absente »
    seconds: float = 0.0
    feedback: str = ""                                                   # pour le Développeur / Stratège (Markdown)
    scope: str = "full"                                                  # "targeted" : suite complète NON lancée (verdict partiel)
    selection: Selection | None = None                                   # quels tests ont été choisis, et pourquoi
    briefs: list[FailureBrief] = Field(default_factory=list)             # un par test en échec : l'explication pour le Développeur
    developer_feedback: str = ""                                         # les briefs, rédigés (anglais), prêts à coller dans le prompt du Développeur
