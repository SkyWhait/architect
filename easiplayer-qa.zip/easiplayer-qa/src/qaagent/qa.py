"""Agent QA (LangGraph) : exécute la suite Squish et rend un verdict de NON-RÉGRESSION fondé sur les rapports.

    gate ─► prepare ─► targeted ─(échec rapide)─────────────────────────────┐
                          └─► full ─► analyze ─► rerun ⟲ (tests en échec) ─► verdict ─► finalize (nettoyage toujours exécuté)

Principes :
 * jamais de succès par défaut : pas de résultat exploitable, rapport tronqué, timeout, script introuvable => `error`, pas `passed` ;
 * le code de sortie du script ne décide de rien (squishrunner renvoie 0 même si des tests échouent) : seul le CONTENU du rapport compte ;
 * un échec n'est une régression que s'il est NOUVEAU par rapport à la référence et qu'il persiste au rejeu ;
 * aucun LLM : la décision doit être reproductible.
"""
from __future__ import annotations

import logging
import shutil
import time
from pathlib import Path
from typing import TypedDict

from langgraph.graph import END, START, StateGraph

from .architect import ArchitectSearch, suspects
from .briefs import developer_feedback, make_brief
from .catalog import Catalog, build_catalog
from .config import Settings
from .models import BuildIn, FailureBrief, QAReport, QARequest, RunInfo, Selection, TestCaseResult
from .report import feedback, markdown
from .selector import select_tests
from .squish_env import PreflightError, effective_settings, remove_agent_script
from .runner import RunState, build_dirs, expand, run_command, tail
from .squish_parser import collect
from .verdict import BAD, classify, decide, expected_tests, load_baseline

log = logging.getLogger("qaagent")


def safe_name(s: str) -> str:
    import re
    return re.sub(r"[^A-Za-z0-9_.-]", "_", s).strip("._")[:64] or "unknown"


class State(TypedDict, total=False):
    stop: bool
    todo: list[str]


class Run:
    def __init__(self, cfg: Settings, req: QARequest, ticket: str):
        self.cfg, self.req, self.ticket = cfg, req, ticket
        self.preflight_error = ""
        self.selection: Selection | None = None
        self.targeted_names: list[str] = []
        self.targeted_only = False
        self.fast_failed = False
        self.briefs: list[FailureBrief] = []
        self.tdir = cfg.work_dir / ticket
        self.tdir.mkdir(parents=True, exist_ok=True)
        n = len([p for p in (self.tdir / "runs").glob("*") if p.is_dir()]) + 1 if (self.tdir / "runs").exists() else 1
        self.rdir = self.tdir / "runs" / str(n)
        self.rdir.mkdir(parents=True, exist_ok=True)
        self.state = RunState(self.tdir / "run.json")
        self.runs: list[RunInfo] = []
        self.warnings: list[str] = []
        self.first: dict[str, TestCaseResult] = {}
        self.final: dict[str, TestCaseResult] = {}
        self.reruns: dict[str, int] = {}
        self.baseline: dict | None = None
        self.bdirs: dict[str, Path] = {}
        self.status: str | None = None
        self.reason = ""
        self.t0 = time.time()
        self.full_started = 0.0
        self.full_dir = Path(cfg.results_dir_override) if cfg.results_dir_override else self.rdir / "full"
        self.classified: list = []
        self.missing: list[str] = []

    def env(self, results_dir: Path) -> dict[str, str]:
        return {**self.cfg.env, self.cfg.results_env_var: str(results_dir), "QA_TICKET": self.ticket}

    def stage_dir(self, name: str) -> Path:
        """Où un lancement écrit ses résultats : le dossier IMPOSÉ par le script (EAP_RESULT) s'il y en a un, sinon un dossier par étape."""
        return Path(self.cfg.results_dir_override) if self.cfg.results_dir_override else self.rdir / name

    def archive(self, name: str) -> None:
        """Le script vide EAP_RESULT à chaque lancement : on garde une copie des résultats de l'étape (preuves pour la revue)."""
        if self.cfg.results_dir_override and Path(self.cfg.results_dir_override).is_dir():
            try:
                shutil.copytree(self.cfg.results_dir_override, self.rdir / name, dirs_exist_ok=True)
            except OSError as e:
                self.warnings.append(f"archivage des résultats de l'étape {name} impossible : {e}")

    def fail(self, status: str, reason: str) -> dict:
        self.status, self.reason = status, reason
        return {"stop": True}


class QAAgent:
    def __init__(self, cfg: Settings, architect: ArchitectSearch | None = None):
        self.cfg, self.architect = cfg, architect
        self._cat: Catalog | None = None
        self._cat_dir = None

    # ------------------------------------------------------------------ API publique
    async def run(self, req: QARequest) -> QAReport:
        ticket = safe_name(req.ticket_id or (req.build.ticket_id if req.build else "") or "unknown")
        cfg, notes, pre = self.cfg, [], ""
        try:
            cfg, notes = effective_settings(self.cfg, self.cfg.check_license)
        except PreflightError as e:
            pre = str(e)
        run = Run(cfg, req, ticket)
        run.preflight_error = pre
        run.warnings += notes
        try:
            await self._graph(run, resume=False).ainvoke({"stop": False}, {"recursion_limit": 100})
        except Exception as e:                                                     # noqa: BLE001
            log.exception("échec inattendu du QA pour %s", ticket)
            run.status, run.reason = "error", f"{type(e).__name__}: {e}"
        finally:
            await self._cleanup(run)
        return self._finalize(run)

    async def resume(self, ticket: str, req: QARequest | None = None) -> QAReport:
        """Reprend un run interrompu par un redémarrage du service : on n'a PAS perdu les résultats, on les analyse."""
        st = RunState(self.cfg.work_dir / ticket / "run.json").read()
        run = Run(self.cfg, req or QARequest(ticket_id=ticket, skip_gate=True), ticket)
        run.rdir = Path(st["log_path"]).parent if st.get("log_path") else run.rdir
        run.full_dir = Path(st["results_dir"]) if st.get("results_dir") else run.full_dir
        run.full_started = float(st.get("started", 0))
        run.runs.append(RunInfo(command=st.get("command", []), log_path=st.get("log_path", ""), results_dir=str(run.full_dir), exit_code=None,
                                seconds=round(time.time() - run.full_started, 1), note="suivi repris après redémarrage du service (code de sortie inconnu)"))
        run.warnings.append("Run repris après un redémarrage du service : le code de sortie du script n'est pas connu, seul le rapport décide.")
        try:
            await self._graph(run, resume=True).ainvoke({"stop": False}, {"recursion_limit": 100})
        except Exception as e:                                                     # noqa: BLE001
            run.status, run.reason = "error", f"{type(e).__name__}: {e}"
        finally:
            await self._cleanup(run)
        return self._finalize(run)

    # ------------------------------------------------------------------ graphe
    def _graph(self, run: Run, resume: bool):
        cfg = run.cfg

        async def n_gate(s: State) -> State:
            if run.preflight_error:
                return run.fail("error", "Pré-vol Squish échoué (aucun test lancé) : " + run.preflight_error)
            b: BuildIn | None = run.req.build
            if not run.req.skip_gate:
                if b is None:
                    return run.fail("rejected", "Aucun rapport du Compilateur : la validation QA n'a de sens que sur un build réussi (ou skip_gate=true pour un usage manuel).")
                if b.status != "success":
                    return run.fail("rejected", f"Le Compilateur n'a pas réussi (status={b.status}) : rien à valider. {b.status_reason}")
            run.baseline = load_baseline(cfg)
            try:
                run.bdirs = build_dirs(b, cfg)
            except Exception as e:                                                  # noqa: BLE001
                run.warnings.append(f"build_dirs illisibles : {e}")
            run.state.write(state="queued", ticket=run.ticket, results_dir=str(run.full_dir), stage="gate")
            return {"stop": False}

        async def n_select(s: State) -> State:
            """Quels tests lancer d'abord ? Imposés par l'appelant, rejoués (échecs du tour précédent), ou CHOISIS d'après la modification (catalogue des tests)."""
            names = [k.split("/")[-1] for k in [*run.req.focus_tests, *(run.req.testcases or [])]]
            ch = run.req.change
            if ch is not None:
                cat = self._catalog(run)
                run.warnings += cat.warnings[:5]
                sel = select_tests(ch, cat, domain_map=cfg.domain_map, groups=cfg.suite_groups, max_tests=cfg.max_targeted, min_score=cfg.min_select_score)
                run.selection = sel
                names += [t.name for t in sel.tests]
                if sel.unknown_suggestions:
                    run.warnings.append("Tests suggérés par le Stratège introuvables dans la suite : " + ", ".join(sel.unknown_suggestions))
                if sel.note:
                    run.warnings.append(sel.note)
                if cat.cards:
                    unknown = [n for n in names if n not in cat.cards]
                    if unknown:
                        run.warnings.append("Tests demandés absents du catalogue (ignorés) : " + ", ".join(unknown))
                        names = [n for n in names if n in cat.cards]
            run.targeted_names = list(dict.fromkeys(names))
            run.targeted_only = run.req.scope == "targeted"
            if run.targeted_only and not run.targeted_names:
                return run.fail("incomplete", "Aucun test ciblé fiable pour cette modification : rien n'a été exécuté (jamais traité comme un succès). Lancer la suite complète ou choisir les tests à la main.")
            return {"stop": False}

        async def n_prepare(s: State) -> State:
            if not cfg.prepare_command:
                return {"stop": False}
            try:
                cmd = expand(cfg.prepare_command, results_dir=run.rdir, ticket=run.ticket, bdirs=run.bdirs)
            except KeyError as e:
                return run.fail("error", f"commande de préparation : {e}")
            info = await run_command(cmd, cwd=cfg.run_cwd, env_extra=run.env(run.rdir), log_path=run.rdir / "prepare.log", timeout=cfg.prepare_timeout_s, state=run.state, stage="prepare")
            run.runs.append(info)
            if info.note or info.exit_code != 0:
                return run.fail("error", f"La préparation (installation du build à tester) a échoué : {info.note or 'code ' + str(info.exit_code)}. {tail(Path(info.log_path), 5)}")
            return {"stop": False}

        async def n_targeted(s: State) -> State:
            if not run.targeted_names:
                return {"stop": False}
            if not cfg.targeted_command:
                if run.targeted_only:
                    return run.fail("error", "Tests ciblés demandés mais aucune commande de lancement ciblé n'est configurée (QA_TARGETED_COMMAND ou QA_SQUISH_DIR).")
                return {"stop": False}
            rdir = run.stage_dir("targeted")
            rdir.mkdir(parents=True, exist_ok=True)
            names = run.targeted_names
            cmd = expand(cfg.targeted_command, results_dir=rdir, ticket=run.ticket, bdirs=run.bdirs, testcases=names, keys=names, join=cfg.testcase_join)
            t0 = time.time()
            info = await run_command(cmd, cwd=cfg.run_cwd, env_extra=run.env(rdir), log_path=run.rdir / "targeted.log", timeout=cfg.timeout_s, xvfb=cfg.xvfb, state=run.state, stage="targeted")
            info.results_dir = str(rdir)
            run.runs.append(info)
            tests, used, broken = collect(rdir, since=t0 - 1)
            info.result_files = used
            run.archive("targeted")
            if broken:
                run.warnings.append("Rapport(s) ciblé(s) tronqué(s)/illisible(s) : " + ", ".join(broken))
            if not tests:
                return run.fail("error", f"Les tests ciblés n'ont produit aucun résultat exploitable dans {rdir} (code {info.exit_code}). Fin du journal : {tail(Path(info.log_path), 6)}")
            base = (run.baseline or {}).get("tests", {})
            run.first = {t.key: t for t in tests}
            run.final = dict(run.first)                        # copie : le rejeu met à jour `final`, `first` garde le 1er passage (détection des tests instables)
            bad = [t for t in tests if t.status in BAD and base.get(t.key) not in BAD]
            if bad:                                            # échec rapide : inutile de brûler 6 h si le test directement lié échoue ; un rejeu confirme d'abord
                run.fast_failed = True
                run.warnings.append("Échec rapide : les tests ciblés échouent ; la suite complète n'a PAS été lancée.")
                return {"stop": False}
            return {"stop": False}

        def after_targeted(s: State) -> str:
            if s.get("stop"):
                return "verdict"
            if run.fast_failed:
                return "rerun" if (cfg.rerun_command and candidates()) else "verdict"
            return "verdict" if run.targeted_only and run.final else "full"

        async def n_full(s: State) -> State:
            run.full_dir.mkdir(parents=True, exist_ok=True)
            try:
                cmd = expand(cfg.run_command, results_dir=run.full_dir, ticket=run.ticket, bdirs=run.bdirs)
            except KeyError as e:
                return run.fail("error", f"commande de test : {e}")
            run.full_started = time.time()
            run.state.write(results_dir=str(run.full_dir), started=run.full_started)
            info = await run_command(cmd, cwd=cfg.run_cwd, env_extra=run.env(run.full_dir), log_path=run.rdir / "full.log", timeout=cfg.timeout_s, xvfb=cfg.xvfb, state=run.state, stage="full")
            info.results_dir = str(run.full_dir)
            run.runs.append(info)
            run.state.write(state="finished", exit_code=info.exit_code)
            return {"stop": False}

        async def n_analyze(s: State) -> State:
            info = run.runs[-1]
            tests, used, broken = collect(run.full_dir, since=run.full_started - 1)
            info.result_files = used
            if info.timed_out:
                run.warnings.append(info.note)
            if info.note and not info.timed_out and not tests:                       # script introuvable...
                return run.fail("error", info.note)
            if broken:
                run.warnings.append("Rapport(s) tronqué(s)/illisible(s) : " + ", ".join(broken) + " (squishrunner interrompu ?)")
            if not tests:
                why = ("timeout" if info.timed_out else f"le script a terminé (code {info.exit_code})") + " sans produire de résultat exploitable"
                return run.fail("error", f"{why} dans {run.full_dir}. Le script écrit-il bien dans ${cfg.results_env_var} (ou QA_RESULTS_DIR_OVERRIDE) ? Fin du journal : {tail(Path(info.log_path), 6)}")
            if info.exit_code not in (0, None):
                run.warnings.append(f"Le script a terminé avec le code {info.exit_code} (--exitCodeOnFail ?) : le verdict repose sur le rapport.")
            dup = {t.key for t in tests if sum(1 for u in tests if u.key == t.key) > 1}
            if dup:
                run.warnings.append("Tests présents plusieurs fois dans les rapports (dernier résultat retenu) : " + ", ".join(sorted(dup)[:5]))
            run.first = {t.key: t for t in tests}
            run.final = dict(run.first)
            if info.timed_out:
                return run.fail("error", f"Timeout de la suite ({cfg.timeout_s} s) : {len(tests)} test(s) seulement ont un résultat.")
            return {"stop": False}

        def candidates() -> list[str]:
            base = (run.baseline or {}).get("tests", {})
            return [k for k, t in run.final.items() if t.status in BAD and base.get(k) not in BAD and run.reruns.get(k, 1) <= cfg.max_reruns]

        def after_analyze(s: State) -> str:
            return "verdict" if s.get("stop") or not (cfg.rerun_command and candidates()) else "rerun"

        async def n_rerun(s: State) -> State:
            keys = candidates()
            rname = f"rerun{max(run.reruns.values(), default=1)}"
            rdir = run.stage_dir(rname)
            rdir.mkdir(parents=True, exist_ok=True)
            names = [k.split("/")[-1] for k in keys]
            cmd = expand(cfg.rerun_command or [], results_dir=rdir, ticket=run.ticket, bdirs=run.bdirs, testcases=names, keys=keys, join=cfg.testcase_join)
            t0 = time.time()
            info = await run_command(cmd, cwd=cfg.run_cwd, env_extra=run.env(rdir), log_path=run.rdir / f"{rname}.log", timeout=cfg.timeout_s, xvfb=cfg.xvfb, state=run.state, stage=rname)
            info.results_dir = str(rdir)
            run.runs.append(info)
            tests, used, _ = collect(rdir, since=t0 - 1)
            info.result_files = used
            run.archive(rname)
            got = {t.key: t for t in tests}
            for k in keys:
                run.reruns[k] = run.reruns.get(k, 1) + 1
                if k in got:
                    run.final[k] = got[k]
                else:
                    run.warnings.append(f"Rejeu de {k} : aucun résultat (test non retrouvé par la commande de rejeu).")
            return {"stop": False}

        def after_rerun(s: State) -> str:
            return "rerun" if candidates() else "verdict"

        async def n_verdict(s: State) -> State:
            if s.get("stop") and run.status in {"error", "rejected", "incomplete"}:
                return {}
            run.classified = classify(run.first, run.final, run.reruns, run.baseline, cfg)
            partial = run.targeted_only or run.fast_failed                       # la suite complète n'a pas tourné : on n'attend que les tests ciblés
            if partial:
                got = {t.name for t in run.final.values()}
                run.missing = sorted(n for n in run.targeted_names if n not in got)
            else:
                exp = expected_tests(cfg, run.baseline)
                run.missing = sorted(exp - set(run.final)) if exp else []
            if run.status is None or run.status == "failed":
                if run.status is None:
                    st, why = decide(run.classified, run.missing, len(run.final), run.baseline is not None, cfg)
                    run.status, run.reason = st, why
            if run.fast_failed and run.status == "failed":
                run.reason = "Échec rapide sur les tests ciblés : " + run.reason
            if run.status == "passed" and partial:
                run.reason += " — tests ciblés seulement : la suite complète n'a PAS été lancée (verdict partiel)"
            if self.architect:
                for c in run.classified:
                    if c.outcome == "new_failure":
                        try:
                            c.suspects = await suspects(self.architect, run.final[c.key])
                        except Exception as e:                                       # noqa: BLE001
                            run.warnings.append(f"Architecte injoignable (suspects ignorés) : {type(e).__name__}")
                            break
            self._briefs(run)
            return {}

        g = StateGraph(State)
        for name, fn in [("gate", n_gate), ("select", n_select), ("prepare", n_prepare), ("targeted", n_targeted), ("full", n_full), ("analyze", n_analyze),
                         ("rerun", n_rerun), ("verdict", n_verdict)]:
            g.add_node(name, fn)
        stop_or = lambda nxt: (lambda s: "verdict" if s.get("stop") else nxt)          # noqa: E731
        g.add_conditional_edges(START, lambda s: "analyze" if resume else "gate", {"analyze": "analyze", "gate": "gate"})
        g.add_conditional_edges("gate", stop_or("select"), {"verdict": "verdict", "select": "select"})
        g.add_conditional_edges("select", stop_or("prepare"), {"verdict": "verdict", "prepare": "prepare"})
        g.add_conditional_edges("prepare", stop_or("targeted"), {"verdict": "verdict", "targeted": "targeted"})
        g.add_conditional_edges("targeted", after_targeted, {"verdict": "verdict", "full": "full", "rerun": "rerun"})
        g.add_edge("full", "analyze")
        g.add_conditional_edges("analyze", after_analyze, {"verdict": "verdict", "rerun": "rerun"})
        g.add_conditional_edges("rerun", after_rerun, {"rerun": "rerun", "verdict": "verdict"})
        g.add_edge("verdict", END)
        return g.compile()

    # ------------------------------------------------------------------ compréhension des tests
    def _catalog(self, run: Run) -> Catalog:
        if self._cat is None or self._cat_dir != run.cfg.suite_dir:
            suite = run.cfg.suite_dir or (next(iter(sorted(run.cfg.suites_dir.glob("suite_*"))), None) if run.cfg.suites_dir else None)
            self._cat = build_catalog(Path(suite)) if suite else Catalog(warnings=["QA_SUITE_DIR / QA_SQUISH_DIR non défini : pas de catalogue des tests"])
            self._cat_dir = run.cfg.suite_dir
        return self._cat

    def _briefs(self, run: Run) -> None:
        """Un « brief » par test en échec : ce que le test vérifie, ce qui a échoué et où, quelles parties de la modification y sont liées."""
        bad = [c for c in run.classified if c.outcome == "new_failure"]
        if not bad:
            return
        cat = self._cat if self._cat is not None else (self._catalog(run) if run.cfg.suite_dir or run.cfg.suites_dir else Catalog())
        note = "passed in the reference run" if run.baseline else "no reference run recorded (every failure counts as new)"
        for c in bad[: self.cfg.max_failures_listed]:
            t = run.final[c.key]
            run.briefs.append(make_brief(t, c, cat.cards.get(t.name), run.req.change, run.selection, note))

    # ------------------------------------------------------------------ nettoyage et rapport
    async def _cleanup(self, run: Run) -> None:
        remove_agent_script(run.cfg)
        """Toujours exécuté (même en cas d'erreur) : arrêter squishserver / les AUT restants, sinon le run suivant démarre sur un état sale."""
        if not self.cfg.cleanup_command:
            return
        try:
            cmd = expand(self.cfg.cleanup_command, results_dir=run.rdir, ticket=run.ticket, bdirs=run.bdirs)
            info = await run_command(cmd, cwd=self.cfg.run_cwd, env_extra=run.env(run.rdir), log_path=run.rdir / "cleanup.log", timeout=300)
            if info.exit_code != 0:
                run.warnings.append(f"Le nettoyage a échoué (code {info.exit_code}) : {info.note or tail(Path(info.log_path), 3)}")
        except Exception as e:                                                       # noqa: BLE001
            run.warnings.append(f"Nettoyage impossible : {e}")

    def _finalize(self, run: Run) -> QAReport:
        out = {c.outcome: 0 for c in run.classified}
        for c in run.classified:
            out[c.outcome] += 1
        status = run.status or "error"
        rep = QAReport(
            ticket_id=run.ticket, status=status, verdict_reason=run.reason or "(aucune raison enregistrée)",                  # type: ignore[arg-type]
            summary={"total": len(run.final), **out, "missing": len(run.missing)} if run.final else {},
            new_failures=[c.key for c in run.classified if c.outcome == "new_failure"], known_failures=[c.key for c in run.classified if c.outcome == "known_failure"],
            flaky=[c.key for c in run.classified if c.outcome == "flaky"], fixed=[c.key for c in run.classified if c.outcome == "fixed"],
            missing_tests=run.missing, classified=run.classified, tests=list(run.final.values()), runs=run.runs, warnings=run.warnings,
            baseline=(f"présente ({run.baseline.get('updated', '?')})" if run.baseline else "absente"), seconds=round(time.time() - run.t0, 1))
        rep.scope = "targeted" if (run.targeted_only or run.fast_failed) else "full"
        rep.selection, rep.briefs = run.selection, run.briefs
        rep.developer_feedback = developer_feedback(run.briefs, run.reason) if rep.status == "failed" else ""
        rep.feedback = feedback(rep, self.cfg.max_failures_listed)
        (run.tdir).mkdir(parents=True, exist_ok=True)
        (run.tdir / "qa_report.json").write_text(rep.model_dump_json(indent=2))
        (run.tdir / "qa_report.md").write_text(markdown(rep))
        run.state.write(state="done", status=rep.status)
        return rep
