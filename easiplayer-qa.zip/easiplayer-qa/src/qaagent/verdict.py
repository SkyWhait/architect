"""Verdict de non-régression : on ne décide pas « tout vert / pas tout vert » mais « qu'est-ce qui est NOUVEAU par rapport à la référence ? ».

 * nouvel échec   : échoue (après rejeu) et n'était pas déjà en échec dans la référence      -> bloque
 * échec connu    : échoue et échouait déjà dans la référence (mis en quarantaine)            -> signalé, ne bloque pas
 * instable (flaky): échoue puis passe au rejeu                                                -> avertissement (bloque si flaky_is_failure)
 * corrigé         : passait mal dans la référence, passe maintenant
 * manquant        : test attendu absent du rapport (suite interrompue, --abortOnFail...)      -> « incomplete »
Sans référence, tout échec est « nouveau » (on ne peut pas prouver qu'il préexistait) : l'avertissement est explicite.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from .config import Settings
from .models import Classified, TestCaseResult

BAD = {"fail", "error"}


# ----------------------------------------------------------------------------------------------------------------- référence
def baseline_path(cfg: Settings, name: str = "default") -> Path:
    return cfg.baseline_dir / f"{name}.json"


def load_baseline(cfg: Settings, name: str = "default") -> dict | None:
    p = baseline_path(cfg, name)
    return json.loads(p.read_text()) if p.exists() else None


def save_baseline(cfg: Settings, tests: list[TestCaseResult], name: str = "default", note: str = "") -> dict:
    data = {"updated": time.strftime("%Y-%m-%dT%H:%M:%S"), "note": note, "tests": {t.key: t.status for t in tests}}
    cfg.baseline_dir.mkdir(parents=True, exist_ok=True)
    baseline_path(cfg, name).write_text(json.dumps(data, indent=2, sort_keys=True))
    return data


def expected_tests(cfg: Settings, baseline: dict | None) -> set[str]:
    if cfg.suites_dir and cfg.suites_dir.is_dir():
        return {f"{s.name}/{t.name}" for s in cfg.suites_dir.glob("suite_*") if s.is_dir() for t in s.glob("tst_*") if t.is_dir()}
    return set(baseline["tests"]) if baseline else set()


# ----------------------------------------------------------------------------------------------------------------- classification
def classify(first: dict[str, TestCaseResult], final: dict[str, TestCaseResult], runs: dict[str, int], baseline: dict | None,
             cfg: Settings) -> list[Classified]:
    base = (baseline or {}).get("tests", {})
    out: list[Classified] = []
    for key, f in final.items():
        first_status = first[key].status if key in first else f.status
        if f.status == "skipped":
            outcome = "skipped"
        elif f.status == "pass":
            outcome = "flaky" if first_status in BAD else ("fixed" if base.get(key) in BAD else "pass")
        else:
            outcome = "known_failure" if base.get(key) in BAD else "new_failure"
        out.append(Classified(key=key, outcome=outcome, first=first_status, final=f.status, runs=runs.get(key, 1)))      # type: ignore[arg-type]
    return out


def decide(classified: list[Classified], missing: list[str], total_tests: int, has_baseline: bool, cfg: Settings) -> tuple[str, str]:
    new = [c for c in classified if c.outcome == "new_failure"]
    flaky = [c for c in classified if c.outcome == "flaky"]
    known = [c for c in classified if c.outcome == "known_failure"]
    if total_tests == 0:
        return "error", "Aucun résultat de test exploitable : on ne peut pas conclure (jamais traité comme un succès)."
    if new:
        why = f"{len(new)} nouvel(le)(s) échec(s)" + ("" if has_baseline else " (aucune référence : tous les échecs sont comptés comme nouveaux)")
        return "failed", why + (f", {len(missing)} test(s) non exécuté(s)" if missing else "")
    if flaky and cfg.flaky_is_failure:
        return "failed", f"{len(flaky)} test(s) instable(s) (échec puis succès au rejeu) et flaky_is_failure=true"
    if missing and cfg.fail_on_missing:
        return "incomplete", f"{len(missing)} test(s) attendu(s) absent(s) du rapport (suite interrompue ?) : {', '.join(missing[:5])}"
    bits = []
    if known:
        bits.append(f"{len(known)} échec(s) connu(s) de la référence")
    if flaky:
        bits.append(f"{len(flaky)} test(s) instable(s)")
    return "passed", "Aucune régression" + (" ; " + ", ".join(bits) if bits else "")
