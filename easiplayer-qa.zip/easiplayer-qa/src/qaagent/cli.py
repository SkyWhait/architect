from __future__ import annotations

import argparse
import asyncio
import json
import logging
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser(prog="qaagent")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("parse", help="analyser un dossier de résultats Squish existant (sans rien lancer) : vérifier que TES rapports sont compris")
    p.add_argument("results", type=Path)
    r = sub.add_parser("run", help="lancer la suite et rendre le verdict")
    r.add_argument("--build-report", type=Path, help="build_report.json / loop_report.json du Compilateur (le signal)")
    r.add_argument("--ticket"); r.add_argument("--skip-gate", action="store_true"); r.add_argument("--testcases", nargs="*")
    b = sub.add_parser("baseline", help="enregistrer une RÉFÉRENCE à partir d'un dossier de résultats (build connu comme bon)")
    b.add_argument("results", type=Path); b.add_argument("--name", default="default"); b.add_argument("--note", default="")
    s = sub.add_parser("serve"); s.add_argument("--host", default="0.0.0.0"); s.add_argument("--port", type=int, default=8840)
    c = sub.add_parser("catalog", help="ce que l'agent COMPREND de tes tests (à vérifier sur les vrais test.py avant tout)")
    c.add_argument("--suite-dir", type=Path, required=True, help="ex. /data/easiplayer/EasiPlayerSquishTests/suite_EasiPlayer")
    sl = sub.add_parser("select", help="quels tests seraient choisis pour une modification (sans rien lancer)")
    sl.add_argument("--suite-dir", type=Path, required=True)
    sl.add_argument("--file", action="append", default=[]); sl.add_argument("--symbol", action="append", default=[])
    sl.add_argument("--plan-text", default=""); sl.add_argument("--ticket-text", default=""); sl.add_argument("--suggested", nargs="*", default=[])
    pf = sub.add_parser("preflight", help="contrôle du dossier Squish d'Airbus : variables, licence, copie xml3 du script (rien n'est lancé)")
    pf.add_argument("--squish-dir", type=Path, required=True)
    pr = sub.add_parser("probe", help="lance UN test réel via la copie xml3 du script et dit si le rapport est lisible (à faire une fois)")
    pr.add_argument("--squish-dir", type=Path, required=True); pr.add_argument("--test", required=True)
    sub.add_parser("schema")
    a = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")

    if a.cmd == "schema":
        from .models import QAReport
        print(json.dumps(QAReport.model_json_schema(), indent=2)); return
    if a.cmd == "serve":
        import uvicorn
        uvicorn.run("qaagent.api:create_app", factory=True, host=a.host, port=a.port); return
    if a.cmd == "catalog":
        from .catalog import build_catalog
        cat = build_catalog(a.suite_dir)
        for z, names in sorted(cat.zones().items()):
            print(f"[{z}] {len(names)} test(s)")
        for n, cd in cat.cards.items():
            print(f"\n{n}  ({cd.language}; {len(cd.verifications)} vérif., {len(cd.objects)} objet(s) GUI, données : {', '.join(cd.data_files) or '-'})\n    {cd.summary() or '(rien de lisible extrait : à examiner)'}")
        print(f"\n{len(cat.cards)} test(s)" + "".join(f"\nAVERTISSEMENT {w}" for w in cat.warnings)); return
    if a.cmd == "select":
        from .catalog import build_catalog
        from .models import ChangeContext
        from .selector import select_tests
        sel = select_tests(ChangeContext(files=a.file, symbols=a.symbol, plan_text=a.plan_text, ticket_text=a.ticket_text, suggested_tests=a.suggested), build_catalog(a.suite_dir))
        for t in sel.tests:
            print(f"{t.score:5.1f}  {t.name}  {t.groups or ''}\n        {t.tests_what}\n" + "".join(f"        - {r}\n" for r in t.reasons))
        print(sel.note or f"{len(sel.tests)} test(s) choisi(s) sur {sel.catalog_size}", *(f"\nSuggestion inconnue : {u}" for u in sel.unknown_suggestions)); return
    if a.cmd in {"preflight", "probe"}:
        from .config import Settings
        from .squish_env import PreflightError, effective_settings, remove_agent_script
        cfg = Settings(squish_dir=a.squish_dir)
        try:
            eff, notes = effective_settings(cfg)
        except PreflightError as e:
            print(f"ÉCHEC : {e}"); raise SystemExit(1)
        try:
            print("OK — EAP_RESULT :", eff.results_dir_override, "| suite :", eff.suite_dir, *notes, sep="\n  ")
            if a.cmd == "probe":
                import time
                from .qa import QAAgent
                from .models import QARequest
                t0 = time.time()
                rep = asyncio.run(QAAgent(cfg).run(QARequest(ticket_id="probe", skip_gate=True, testcases=[a.test], scope="targeted")))
                print(f"[{rep.status}] {rep.verdict_reason}")
                for ri in rep.runs:
                    print(f"  {' '.join(ri.command)} -> code {ri.exit_code}, fichiers lus : {ri.result_files or 'AUCUN'}")
                print("Si « AUCUN » : le script n'a pas produit de rapport xml3 lisible (voir le journal indiqué) ; envoyer ce journal et le contenu de EAP_RESULT.")
        finally:
            remove_agent_script(cfg)
        return
    from .squish_parser import collect
    if a.cmd in {"parse", "baseline"}:
        tests, used, broken = collect(a.results)
        for t in tests:
            print(f"{t.status.upper():7s} {t.key}  ({t.verifications} vérif., {len(t.failures)} échec(s))" + "".join(f"\n          [{f.kind}] {f.verification} {f.script}:{f.line} {f.message or f.detail}"[:200] for f in t.failures[:2]))
        print(f"\n{len(tests)} test(s) dans {len(used)} fichier(s)" + (f" — ILLISIBLES : {broken}" if broken else ""))
        if a.cmd == "baseline":
            from .config import get_settings
            from .verdict import save_baseline
            cfg = get_settings()
            d = save_baseline(cfg, tests, a.name, a.note)
            print(f"Référence '{a.name}' enregistrée : {len(d['tests'])} test(s) ({sum(v != 'pass' for v in d['tests'].values())} en échec/erreur/ignoré)")
        return
    from .config import get_settings
    from .models import BuildIn, QARequest
    from .qa import QAAgent
    cfg = get_settings()
    build = BuildIn.model_validate_json(a.build_report.read_text()) if a.build_report else None
    rep = asyncio.run(QAAgent(cfg).run(QARequest(ticket_id=a.ticket, build=build, skip_gate=a.skip_gate, testcases=a.testcases)))
    print(f"[{rep.status}] {rep.verdict_reason}\n-> {cfg.work_dir / rep.ticket_id / 'qa_report.md'}")


if __name__ == "__main__":
    main()
