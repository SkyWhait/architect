"""API HTTP : n8n envoie le « signal » (succès du Compilateur), suit un run de plusieurs heures, récupère le rapport.

Un run Squish dure des heures : le service écrit l'état dans run.json ; s'il redémarre, il REPREND le suivi (processus encore vivant) ou
analyse les résultats déjà écrits, au lieu de perdre le run.
"""
from __future__ import annotations

import asyncio
import json
import os
import signal
import time
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel

from .architect import HttpArchitect
from .config import Settings, get_settings
from .models import QAReport, QARequest, TestCaseResult
from .qa import QAAgent, safe_name
from .runner import RunState, pid_alive
from .verdict import save_baseline


class BaselineRequest(BaseModel):
    ticket: str
    name: str = "default"
    note: str = ""
    accept_failures: bool = False          # promouvoir aussi les échecs (ils deviennent « connus ») : décision HUMAINE explicite


def create_app(settings: Settings | None = None, architect_factory=None) -> FastAPI:
    cfg = settings or get_settings()
    cfg.work_dir.mkdir(parents=True, exist_ok=True)
    cfg.baseline_dir.mkdir(parents=True, exist_ok=True)
    jobs: dict[str, dict] = {}
    gate = asyncio.Semaphore(1)                                                   # une seule suite GUI à la fois (une seule session d'affichage)

    def make_agent() -> QAAgent:
        arch = architect_factory() if architect_factory else (HttpArchitect(cfg.architect_url, cfg.architect_token) if cfg.architect_url else None)
        return QAAgent(cfg, arch)

    def auth(authorization: str | None = Header(default=None)) -> None:
        token = cfg.api_token or os.environ.get("QA_API_TOKEN")
        if token and authorization != f"Bearer {token}":
            raise HTTPException(401, "unauthorized")

    async def execute(tid: str, req: QARequest | None, resume: bool = False) -> None:
        async with gate:
            jobs[tid].update(state="running")
            agent = make_agent()
            try:
                rep = await (agent.resume(tid, req) if resume else agent.run(req))          # type: ignore[arg-type]
                jobs[tid].update(state="done", status=rep.status, reason=rep.verdict_reason)
            except asyncio.CancelledError:
                jobs[tid].update(state="done", status="error", reason="annulé par l'opérateur")
                raise
            except Exception as e:                                                    # noqa: BLE001
                jobs[tid].update(state="done", status="error", reason=f"{type(e).__name__}: {e}")
            finally:
                if agent.architect:
                    await agent.architect.aclose()

    async def reconcile() -> None:
        """Au démarrage : que sont devenus les runs qui tournaient ?"""
        for rj in cfg.work_dir.glob("*/run.json"):
            tid, st = rj.parent.name, RunState(rj).read()
            if st.get("state") not in {"running", "queued"}:
                continue
            pid = st.get("pid")
            alive = bool(pid) and pid_alive(int(pid), (st.get("command") or [""])[0])
            has_results = bool(st.get("results_dir")) and any(__import__("pathlib").Path(st["results_dir"]).rglob("*.xml"))

            async def follow(tid=tid, pid=pid, alive=alive) -> None:
                while alive and pid_alive(int(pid), (st.get("command") or [""])[0]):
                    jobs[tid]["heartbeat"] = time.time()
                    await asyncio.sleep(15)
                await execute(tid, None, resume=True)

            if alive or has_results:
                jobs[tid] = {"state": "adopted" if alive else "running", "started": st.get("started", time.time()), "adopted": True}
                jobs[tid]["task"] = asyncio.create_task(follow())
            else:
                RunState(rj).write(state="done", status="error", reason="run interrompu avant d'avoir produit des résultats (service redémarré)")

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        await reconcile()
        yield
        for j in jobs.values():
            if j.get("task") and not j["task"].done():
                j["task"].cancel()

    app = FastAPI(title="EasiPlayer QA (Squish)", version="0.1.0", lifespan=lifespan, dependencies=[Depends(auth)])

    @app.post("/runs", status_code=202)
    async def submit(req: QARequest):
        tid = safe_name(req.ticket_id or (req.build.ticket_id if req.build else ""))
        if tid == "unknown":
            raise HTTPException(422, "ticket_id manquant (ou build.ticket_id)")
        if jobs.get(tid, {}).get("state") in ("queued", "running", "adopted"):
            raise HTTPException(409, f"une validation est déjà en cours pour {tid}")
        jobs[tid] = {"state": "queued", "started": time.time()}
        jobs[tid]["task"] = asyncio.create_task(execute(tid, req))
        return {"ticket_id": tid, "state": "queued"}

    def report_of(tid: str) -> dict | None:
        p = cfg.work_dir / safe_name(tid) / "qa_report.json"
        return json.loads(p.read_text()) if p.exists() else None

    @app.get("/runs/{tid}")
    async def status(tid: str, full: bool = False):
        tid = safe_name(tid)
        j = jobs.get(tid)
        st = RunState(cfg.work_dir / tid / "run.json").read()
        if j and j["state"] != "done":
            return {"ticket_id": tid, "state": j["state"], "stage": st.get("stage"), "elapsed_s": round(time.time() - float(j.get("started", time.time()))),
                    "progress": st.get("progress", {}), "log_lines": st.get("log_lines"), "last_heartbeat": st.get("heartbeat"), "adopted": j.get("adopted", False)}
        rep = report_of(tid)
        if rep is None:
            if j:
                return {"ticket_id": tid, "state": "done", "status": j.get("status"), "reason": j.get("reason", "")}
            raise HTTPException(404, "inconnu")
        out = {"ticket_id": tid, "state": "done", "status": rep["status"], "reason": rep["verdict_reason"], "summary": rep["summary"],
               "new_failures": rep["new_failures"], "flaky": rep["flaky"], "missing_tests": rep["missing_tests"]}
        return {**out, "report": rep} if full else out

    @app.get("/runs/{tid}/report", response_class=PlainTextResponse)
    async def report(tid: str):
        p = cfg.work_dir / safe_name(tid) / "qa_report.md"
        if not p.exists():
            raise HTTPException(404, "pas de rapport")
        return p.read_text()

    @app.get("/runs/{tid}/feedback", response_class=PlainTextResponse)
    async def feedback(tid: str):
        rep = report_of(tid)
        if rep is None:
            raise HTTPException(404, "pas de rapport")
        return rep["feedback"] or "(aucune régression : rien à corriger)"

    @app.post("/runs/{tid}/cancel")
    async def cancel(tid: str):
        tid = safe_name(tid)
        j = jobs.get(tid)
        st = RunState(cfg.work_dir / tid / "run.json").read()
        if not j or j["state"] == "done":
            raise HTTPException(404, "aucun run en cours")
        if j.get("task") and not j["task"].done():
            j["task"].cancel()
        elif st.get("pid"):                                                           # run adopté : on tue son groupe de processus
            try:
                os.killpg(int(st["pid"]), signal.SIGKILL)
            except (ProcessLookupError, PermissionError):
                pass
        return {"ticket_id": tid, "cancelled": True}

    @app.post("/baseline")
    async def baseline(req: BaselineRequest):
        """Promeut les résultats d'un run en RÉFÉRENCE. Jamais automatique : sinon les régressions deviendraient la norme."""
        rep = report_of(req.ticket)
        if rep is None:
            raise HTTPException(404, "pas de rapport pour ce ticket")
        if rep["status"] not in {"passed"} and not req.accept_failures:
            raise HTTPException(409, f"le run est '{rep['status']}' : promouvoir une référence avec des échecs exige accept_failures=true (décision explicite)")
        tests = [TestCaseResult(**t) for t in rep["tests"]]
        data = save_baseline(cfg, tests, req.name, req.note or f"promu depuis {req.ticket}")
        return {"baseline": req.name, "tests": len(data["tests"]), "updated": data["updated"]}

    @app.get("/health")
    async def health():
        return {"ok": True}

    return app
