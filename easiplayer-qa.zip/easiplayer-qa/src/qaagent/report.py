"""Retour structuré (pour le Développeur / Stratège : anglais, factuel) et rapport lisible (pour l'humain : français)."""
from __future__ import annotations

from .models import QAReport


def feedback(r: QAReport, limit: int = 15) -> str:
    if r.status == "passed":
        return ""
    by = {t.key: t for t in r.tests}
    new = [c for c in r.classified if c.outcome == "new_failure"]
    o = [f"# QA {r.status.upper()} — ticket {r.ticket_id}", "", r.verdict_reason, ""]
    if r.baseline == "absente":
        o.append("_No baseline recorded: every failure is counted as new. Record one on a known-good build to separate regressions from pre-existing failures._\n")
    for i, c in enumerate(new[:limit], 1):
        t = by[c.key]
        o.append(f"## {i}. {c.key} — {t.status.upper()}" + (f" ({c.runs} runs, consistent)" if c.runs > 1 else ""))
        for f in t.failures[:4]:
            where = f" at {f.script}:{f.line}" if f.script else ""
            o.append(f"- [{f.kind}] {f.verification or 'result'}{where}: {f.message or f.detail}".rstrip(": "))
            if f.detail and f.detail != f.message:
                o.append(f"  detail: {f.detail[:300]}")
            if f.object_name:
                o.append(f"  GUI object: {f.object_name}")
            for a in f.attachments[:2]:
                o.append(f"  evidence: {a}")
        if c.suspects:
            o.append("- Suspect C++ files (heuristic search): " + ", ".join(f"{s['ref']}" for s in c.suspects))
        if t.log:
            o.append(f"- Last log lines: {' | '.join(t.log[-3:])[:300]}")
        o.append("")
    if len(new) > limit:
        o.append(f"... and {len(new) - limit} more new failure(s) in the full report.")
    if r.missing_tests:
        o.append("Tests expected but NOT executed: " + ", ".join(r.missing_tests[:10]))
    return "\n".join(o).strip()


def markdown(r: QAReport) -> str:
    badge = {"passed": "SUCCÈS — aucune régression", "failed": "ÉCHEC — régression(s) détectée(s)", "incomplete": "INCOMPLET", "error": "ERREUR D'EXÉCUTION (aucune conclusion)",
             "rejected": "REFUSÉ"}[r.status]
    o = [f"# Rapport QA (Squish) — {r.ticket_id}", "", f"**Verdict** : {badge}", f"_{r.verdict_reason}_", f"_Référence : {r.baseline or 'absente'} · {int(r.seconds)} s_", ""]
    s = r.summary
    if s:
        o.append("| Tests | Réussis | Nouveaux échecs | Échecs connus | Instables | Corrigés | Ignorés | Manquants |\n|---|---|---|---|---|---|---|---|")
        o.append(f"| {s.get('total', 0)} | {s.get('pass', 0)} | {s.get('new_failure', 0)} | {s.get('known_failure', 0)} | {s.get('flaky', 0)} | {s.get('fixed', 0)} | {s.get('skipped', 0)} | {s.get('missing', 0)} |")
    by = {t.key: t for t in r.tests}
    for title, lst in (("Nouveaux échecs", r.new_failures), ("Instables (échec puis succès au rejeu)", r.flaky), ("Échecs connus (référence)", r.known_failures), ("Tests corrigés", r.fixed)):
        if lst:
            o += ["", f"## {title}"]
            for k in lst:
                o.append(f"- `{k}`" + (f" — {by[k].failures[0].message or by[k].failures[0].detail}"[:160] if k in by and by[k].failures else ""))
    if r.missing_tests:
        o += ["", "## Tests attendus mais non exécutés", *[f"- `{k}`" for k in r.missing_tests[:30]]]
    if r.warnings:
        o += ["", "## Avertissements", *[f"- {w}" for w in r.warnings]]
    o += ["", "## Exécutions"] + [f"- `{' '.join(x.command)[:90]}` → code {x.exit_code}" + (" (TIMEOUT)" if x.timed_out else "") + f" en {x.seconds}s — journal `{x.log_path}`" + (f" — {x.note}" if x.note else "") for x in r.runs]
    if r.feedback:
        o += ["", "## Retour pour le Développeur / Stratège", r.feedback]
    return "\n".join(o) + "\n"
