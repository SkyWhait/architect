"""Intégration avec le VRAI `Squish_run.sh` d'Airbus (lu, pas supposé).

Ce que le script fait, d'après son code :
  * `source ./Environment.sh` définit EAP_RESULT, EAP_SUITE_DIR, SQUISH_VERSION… : on les LIT au lieu de les deviner ;
  * `-t <testcase>` : `testcase=$OPTARG` puis `--testcase $testcase` NON quoté => `-t "tst_A --testcase tst_B"` lance plusieurs tests en un appel ;
  * le rapport est forcé en HTML (`--reportgen html,$EAP_RESULT`) : on en fait une COPIE du script avec `xml3` à la place (aucune autre ligne ne change), car le
    HTML n'est pas analysable de façon fiable ;
  * `cleanEnvironment` supprime `~/.squish` au début ET à la fin de chaque lancement : une licence présente seulement dans ~/.squish/licensekey disparaît.
La copie du script est écrite à côté de l'original (WORKSPACE se déduit de son emplacement) puis supprimée en fin de run.
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

from .config import Settings

AGENT_SCRIPT = "Squish_run.agent.sh"
HTML_ARG = "--reportgen html,$EAP_RESULT"
XML_ARG = "--reportgen xml3,$EAP_RESULT/qa_results.xml"
VARS = ("EAP_RESULT", "EAP_SUITE_DIR", "SQUISH_VERSION", "EAP_OUTPUT", "EAP_SERVEUR_TMP")


class PreflightError(RuntimeError):
    pass


def discover_env(squish_dir: Path, timeout: float = 30) -> dict[str, str]:
    """Variables définies par Environment.sh (dans un sous-shell : rien n'est modifié)."""
    env_sh = squish_dir / "Environment.sh"
    if not env_sh.is_file():
        raise PreflightError(f"Environment.sh introuvable dans {squish_dir}")
    # même préambule que Squish_run.sh : WORKSPACE, TMP_BASE_DIR et RESULTS_FOLDER sont exportés AVANT `source ./Environment.sh`
    prog = "cd \"$1\" && export WORKSPACE=\"$1\" TMP_BASE_DIR=/tmp RESULTS_FOLDER=\"$1/Results\" && source ./Environment.sh >/dev/null 2>&1; " + "; ".join(f'printf "%s=%s\\n" {v} "${{{v}}}"' for v in VARS)
    r = subprocess.run(["bash", "-c", prog, "bash", str(squish_dir)], capture_output=True, text=True, timeout=timeout)
    out = dict(line.split("=", 1) for line in r.stdout.splitlines() if "=" in line)
    return {k: v for k, v in out.items() if v}


def license_problem(home: Path | None = None) -> str | None:
    """None si la licence survivra au script ; sinon l'explication. (Squish_run.sh supprime ~/.squish à chaque lancement.)"""
    h = home or Path(os.environ.get("HOME", "~")).expanduser()
    keep, doomed = h / ".squish-3-license", h / ".squish" / "licensekey"
    if keep.exists():
        return None
    if doomed.exists():
        return (f"Licence Squish trouvée seulement dans {doomed} : Squish_run.sh supprime ~/.squish au début de chaque lancement (cleanEnvironment), "
                f"squishrunner n'aurait plus de licence. La placer dans {keep}.")
    return f"Aucune licence Squish ({keep} ou {doomed}) pour l'utilisateur du service : squishrunner bloquerait immédiatement."


def make_agent_script(script: Path) -> Path:
    text = script.read_text(encoding="utf-8")
    if HTML_ARG not in text:
        raise PreflightError(f"{script.name} ne contient plus « {HTML_ARG} » : le script a changé, adapter squish_env.py (aucun résultat analysable sinon).")
    out = script.with_name(AGENT_SCRIPT)
    out.write_text(text.replace(HTML_ARG, XML_ARG), encoding="utf-8")
    out.chmod(0o755)
    return out


def effective_settings(cfg: Settings, check_license: bool = True) -> tuple[Settings, list[str]]:
    """Configuration réelle déduite du dossier Squish d'Airbus (`QA_SQUISH_DIR`). Lève PreflightError si le run ne peut pas donner de résultat."""
    if cfg.squish_dir is None:
        return cfg, []
    d = cfg.squish_dir
    if not (d / "Squish_run.sh").is_file():
        raise PreflightError(f"Squish_run.sh introuvable dans {d}")
    if check_license and (p := license_problem()):
        raise PreflightError(p)
    env = discover_env(d)
    notes = []
    if not env.get("EAP_RESULT"):
        raise PreflightError("EAP_RESULT n'est pas défini par Environment.sh : impossible de savoir où le script écrit ses résultats.")
    script = make_agent_script(d / "Squish_run.sh")
    notes.append(f"copie du script avec rapport xml3 : {script.name} (HTML remplacé, rien d'autre ne change)")
    run = [f"./{script.name}"]
    upd = {"run_cwd": d, "results_dir_override": Path(env["EAP_RESULT"]), "suites_dir": d, "testcase_join": " --testcase ",
           "run_command": [*run, "-o", "all"], "targeted_command": [*run, "-t", "{testcases_joined}"], "rerun_command": [*run, "-t", "{testcases_joined}"],
           "suite_dir": Path(env["EAP_SUITE_DIR"]) if env.get("EAP_SUITE_DIR") else (cfg.suite_dir or d / "suite_EasiPlayer")}
    return cfg.model_copy(update=upd), notes


def remove_agent_script(cfg: Settings) -> None:
    if cfg.squish_dir is not None:
        (cfg.squish_dir / AGENT_SCRIPT).unlink(missing_ok=True)
