"""Lecture des rapports Squish : XML3 (`--reportgen xml3.x,<dossier>` -> <dossier>/results.xml) et JUnit (`--reportgen junit,<fichier>`).

Structure XML3 d'après la documentation officielle de Squish (« How to Do Automated Batch Testing ») :
SquishReport > test[type=testsuite] > test[type=testcase] > (prolog | verification | message | retry | epilog).
Types de résultat : PASS, FAIL, XPASS, XFAIL, FATAL, ERROR ; types de message : LOG, WARNING, FATAL.

Règle d'or : on décide sur le CONTENU du rapport. Le code de sortie de squishrunner est 0 même si des tests échouent
(sauf --exitCodeOnFail), donc il ne prouve rien.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path

from .models import Failure, TestCaseResult

RESULT_TAGS = ("scriptedVerificationResult", "screenshotVerificationResult", "propertyVerificationResult", "tableVerificationResult")
ATTACH_TAGS = {"failedImage", "expectedImage", "diffImage", "actualImage", "attachment", "screenshot", "objectDump", "failedObjectDump"}
BAD = {"FAIL", "ERROR", "FATAL"}


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def _text(el: ET.Element | None) -> str:
    return (el.text or "").strip() if el is not None else ""


def _msg_text(el: ET.Element) -> str:
    """Texte d'un <message> : dans un enfant <text> (forme des autres éléments XML3) ou directement dans l'élément. Les deux sont acceptés (forme exacte non vérifiée)."""
    t = next((c for c in el if _local(c.tag) == "text"), None)
    return _text(t) if t is not None else _text(el)


def _child(el: ET.Element, name: str) -> ET.Element | None:
    return next((c for c in el if _local(c.tag) == name), None)


def _children(el: ET.Element, name: str) -> list[ET.Element]:
    return [c for c in el if _local(c.tag) == name]


def _first(*els: ET.Element | None) -> ET.Element | None:
    """Premier élément NON None (attention : en ElementTree un élément sans enfant est « faux », donc `a or b` est un piège)."""
    return next((e for e in els if e is not None), None)


def _time(s: str | None) -> datetime | None:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None


def _seconds(prolog: ET.Element | None, epilog: ET.Element | None) -> float:
    a, b = _time(prolog.get("time") if prolog is not None else None), _time(epilog.get("time") if epilog is not None else None)
    return round((b - a).total_seconds(), 2) if a and b else 0.0


# ======================================================================= XML3
def _verification(v: ET.Element, section: str) -> tuple[str, Failure | None, bool]:
    """-> (type, échec éventuel, est_une_vérification_comptée)."""
    res = next((c for c in v if _local(c.tag) in RESULT_TAGS or _local(c.tag).endswith("VerificationResult")), None)
    if res is None:
        return "PASS", None, False
    typ = (res.get("type") or "").upper()
    loc = _first(_child(v, "location"), _child(res, "scriptedLocation"), _child(res, "location"))
    uri = _text(_child(loc, "uri")) if loc is not None else ""
    try:
        line = int(_text(_child(loc, "lineNo"))) if loc is not None else 0
    except ValueError:
        line = 0
    if typ not in BAD and typ not in {"XPASS"}:
        return typ, None, True
    atts = [_text(e) for e in res.iter() if _local(e.tag) in ATTACH_TAGS and _text(e) and "identical" not in _text(e).lower()]
    f = Failure(kind=typ, verification=_text(_child(res, "text")) or _local(res.tag).replace("VerificationResult", "").lower(),
                message=_text(_child(res, "text")), detail=_text(_child(res, "detail")), script=uri, line=line,
                object_name=_text(_child(res, "objectName")), attachments=atts, section=section)
    return typ, f, True


def _case_from(el: ET.Element, suite: str, name: str, source: str) -> TestCaseResult:
    pro, epi = _child(el, "prolog"), next(iter(reversed(_children(el, "epilog"))), None)
    res = TestCaseResult(suite=suite, name=name, status="pass", seconds=_seconds(pro, epi), source=source)

    def visit(node: ET.Element, section: str) -> None:
        for c in node:
            tag = _local(c.tag)
            if tag == "verification":
                typ, fail, counted = _verification(c, section)
                res.verifications += counted
                if fail is None:
                    res.passed += typ in {"PASS", "XFAIL"}
                else:
                    res.failures.append(fail)
            elif tag == "message":
                mt, txt = (c.get("type") or "LOG").upper(), _msg_text(c)
                if mt == "FATAL":
                    res.failures.append(Failure(kind="FATAL", message=txt, section=section))
                elif mt == "WARNING":
                    res.warnings.append(txt)
                elif len(res.log) < 200:
                    res.log.append(txt)
            elif tag == "retry":
                res.retried += 1
                visit(c, section)
            elif tag == "test":                                       # BDD : feature/scénario/étapes imbriqués -> aplatis, avec leur chemin
                nm = _text(_child(_first(_child(c, "prolog"), c), "name"))
                visit(c, f"{section} > {nm}".strip(" >") if nm else section)
    visit(el, "")
    bad = [f for f in res.failures if f.kind in BAD]
    if any(f.kind in {"ERROR", "FATAL"} for f in bad):
        res.status = "error"
    elif bad:
        res.status = "fail"
    elif res.verifications == 0:
        res.status, res.warnings = "error", res.warnings + ["no verification at all: the test did not verify anything (script aborted early?)"]
    res.warnings += [f"XPASS: {f.message or f.detail}" for f in res.failures if f.kind == "XPASS"]
    res.failures = [f for f in res.failures if f.kind != "XPASS"]
    return res


def parse_xml3(root: ET.Element, source: str) -> list[TestCaseResult]:
    out: list[TestCaseResult] = []

    def walk(el: ET.Element, suite: str) -> None:
        for t in _children(el, "test"):
            typ = (t.get("type") or "").lower()
            name = _text(_child(_first(_child(t, "prolog"), t), "name")) or typ
            if typ == "testsuite" or (typ not in {"testcase", "scenario", "feature"} and _children(t, "test") and not _children(t, "verification")):
                walk(t, name)
            else:
                out.append(_case_from(t, suite, name, source))

    walk(root, "")
    return out


# ======================================================================= JUnit
def parse_junit(root: ET.Element, source: str) -> list[TestCaseResult]:
    out: list[TestCaseResult] = []
    suites = [root] if _local(root.tag) == "testsuite" else [e for e in root.iter() if _local(e.tag) == "testsuite"]
    seen: set[int] = set()
    for s in suites:
        if id(s) in seen:
            continue
        for tc in _children(s, "testcase"):
            seen.add(id(tc))
            fail, err, skip = _child(tc, "failure"), _child(tc, "error"), _child(tc, "skipped")      # (comparer avec `is not None` : cf. _first)
            r = TestCaseResult(suite=tc.get("classname") or s.get("name") or "", name=tc.get("name") or "?", status="pass", source=source,
                               seconds=float(tc.get("time") or 0), verifications=1, passed=1)
            if err is not None or fail is not None:
                el = err if err is not None else fail
                r.status, r.passed = ("error" if err is not None else "fail"), 0
                r.failures.append(Failure(kind="ERROR" if err is not None else "FAIL", message=el.get("message") or _text(el)[:200], detail=_text(el)[:1500]))
            elif skip is not None:
                r.status, r.verifications, r.passed = "skipped", 0, 0
            out_text = _text(_child(tc, "system-out"))
            if out_text:
                r.log = out_text.splitlines()[:100]
            out.append(r)
    return out


# ======================================================================= dossier de résultats
def parse_file(path: Path) -> list[TestCaseResult] | None:
    """None = ce n'est pas un rapport de test reconnu (pas une erreur : un dossier contient des images, des logs...)."""
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError):
        return None
    tag = _local(root.tag)
    if tag == "SquishReport":
        return parse_xml3(root, path.name)
    if tag in {"testsuite", "testsuites"}:
        return parse_junit(root, path.name)
    return None


def collect(folder: Path, since: float = 0.0) -> tuple[list[TestCaseResult], list[str], list[str]]:
    """Analyse tous les .xml du dossier (récursif) -> (tests, fichiers lus, fichiers XML illisibles).
    `since` : ignore les fichiers plus anciens (dossier de résultats réutilisé : on ne relit jamais les résultats d'un run précédent)."""
    tests: list[TestCaseResult] = []
    used: list[str] = []
    broken: list[str] = []
    for p in sorted(folder.rglob("*.xml")):
        if since and p.stat().st_mtime < since:
            continue
        r = parse_file(p)
        if r is None:
            if p.stat().st_size and _looks_like_report(p):
                broken.append(str(p.relative_to(folder)))
            continue
        tests += r
        used.append(str(p.relative_to(folder)))
    return tests, used, broken


def _looks_like_report(p: Path) -> bool:
    try:
        head = p.read_bytes()[:400].decode("utf-8", "replace")
    except OSError:
        return False
    return "SquishReport" in head or "<testsuite" in head          # fichier de rapport tronqué (ex. squishrunner tué en plein run)


# ======================================================================= progression (texte, heuristique : JAMAIS utilisée pour le verdict)
_LINE = re.compile(r"^\S+\s+(START|END|PASS|FAIL|ERROR|FATAL|XPASS|XFAIL|LOG|WARNING)\s+(.*)$")


def progress_from_line(line: str, state: dict) -> None:
    m = _LINE.match(line.strip())
    if not m:
        return
    kind, rest = m.groups()
    if kind == "START":
        state["current"] = rest.strip()[:120]
        state["started"] = state.get("started", 0) + 1
    elif kind == "END":
        state["ended"] = state.get("ended", 0) + 1
    elif kind in {"FAIL", "ERROR", "FATAL"}:
        state["fails_seen"] = state.get("fails_seen", 0) + 1
