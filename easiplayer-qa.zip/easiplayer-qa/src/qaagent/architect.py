"""Lien OPTIONNEL avec l'Agent Architecte : pour un test en échec, quels fichiers C++ sont les plus probablement concernés ?
Heuristique (recherche plein texte sur le nom du test, les objets Squish et le message) : un point de départ, pas un diagnostic."""
from __future__ import annotations

import re
from typing import Protocol

import httpx

from .models import TestCaseResult


class ArchitectSearch(Protocol):
    async def search(self, query: str, kind: str | None = None, limit: int = 5) -> list[dict]: ...
    async def aclose(self) -> None: ...


class HttpArchitect:
    def __init__(self, base_url: str, token: str | None = None, timeout: float = 30.0, transport: httpx.AsyncBaseTransport | None = None):
        self._c = httpx.AsyncClient(base_url=base_url.rstrip("/"), headers={"Authorization": f"Bearer {token}"} if token else {}, timeout=timeout, transport=transport)

    async def search(self, query: str, kind: str | None = None, limit: int = 5) -> list[dict]:
        r = await self._c.get("/kb/search", params={k: v for k, v in {"q": query, "kind": kind, "limit": limit}.items() if v})
        r.raise_for_status()
        return r.json()

    async def aclose(self) -> None:
        await self._c.aclose()


def query_for(t: TestCaseResult) -> str:
    words: list[str] = [w for w in re.split(r"[_\W]+", t.name.removeprefix("tst_")) if len(w) > 2]
    for f in t.failures[:3]:
        words += [w for w in re.split(r"[:._\W]+", f.object_name) if len(w) > 2]
        words += [w for w in re.findall(r"[A-Za-z_]\w{3,}", f.message + " " + f.detail)][:6]
    return " ".join(dict.fromkeys(words))[:300]


async def suspects(client: ArchitectSearch, t: TestCaseResult, limit: int = 3) -> list[dict]:
    q = query_for(t)
    if not q:
        return []
    hits = await client.search(q, kind="file", limit=limit + 3)
    return [{"ref": h.get("ref"), "why": str(h.get("snip", ""))[:140]} for h in hits if h.get("kind", "file") == "file"][:limit]
