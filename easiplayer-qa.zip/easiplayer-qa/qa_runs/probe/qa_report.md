# Rapport QA (Squish) — probe

**Verdict** : SUCCÈS — aucune régression
_Aucune régression — tests ciblés seulement : la suite complète n'a PAS été lancée (verdict partiel)_
_Référence : absente · 0 s_

| Tests | Réussis | Nouveaux échecs | Échecs connus | Instables | Corrigés | Ignorés | Manquants |
|---|---|---|---|---|---|---|---|
| 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 |

## Avertissements
- copie du script avec rapport xml3 : Squish_run.agent.sh (HTML remplacé, rien d'autre ne change)

## Exécutions
- `./Squish_run.agent.sh -t tst_STD-EAP-CHAR_CHECKS-00001` → code 0 en 0.1s — journal `qa_runs/probe/runs/1/targeted.log`
