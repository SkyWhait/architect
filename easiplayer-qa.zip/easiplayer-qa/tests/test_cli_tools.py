from __future__ import annotations

import sys

from airbus_world import make_squish_dir
from qaagent.cli import main


def run_cli(monkeypatch, capsys, *args):
    monkeypatch.setattr(sys, "argv", ["qaagent", *args])
    try:
        main()
    except SystemExit as e:
        if e.code:
            return capsys.readouterr().out
    return capsys.readouterr().out


def test_catalog_and_select_commands(tmp_path, monkeypatch, capsys):
    suite = make_squish_dir(tmp_path) / "suite_EasiPlayer"
    out = run_cli(monkeypatch, capsys, "catalog", "--suite-dir", str(suite))
    assert "[CHECK_OPER] 1 test(s)" in out and "CHECK completes before CHECK_TimeOut" in out and "8 test(s)" in out
    out = run_cli(monkeypatch, capsys, "select", "--suite-dir", str(suite), "--file", "EasiPlayer/src/EasiPlayer/custom/ScriptEngine.cpp")
    assert "tst_STD-EAP-JAVA_SCRIPT_USE-00001" in out and "domain rule" in out


def test_probe_command_runs_one_real_test_through_the_xml_copy(tmp_path, monkeypatch, capsys):
    home = tmp_path / "home"
    home.mkdir()
    (home / ".squish-3-license").write_text("k")
    monkeypatch.setenv("HOME", str(home))
    world = make_squish_dir(tmp_path)
    out = run_cli(monkeypatch, capsys, "probe", "--squish-dir", str(world), "--test", "tst_STD-EAP-CHAR_CHECKS-00001")
    assert "OK — EAP_RESULT" in out and "[passed]" in out and "qa_results.xml" in out and not (world / "Squish_run.agent.sh").exists()
    (home / ".squish-3-license").unlink()
    assert "ÉCHEC" in run_cli(monkeypatch, capsys, "preflight", "--squish-dir", str(world))
