from __future__ import annotations

import sys
from pathlib import Path

import pytest

from qaagent.config import Settings
from qaagent.models import BuildIn, QARequest

FIX = Path(__file__).parent / "fixtures"
FAKE = str(FIX / "fake_squish.py")


@pytest.fixture
def cfg(tmp_path, monkeypatch) -> Settings:
    monkeypatch.setenv("FAKE_COUNTER", str(tmp_path / "counter"))
    monkeypatch.setenv("FAKE_LOG", str(tmp_path / "calls.log"))
    return Settings(work_dir=tmp_path / "qa", baseline_dir=tmp_path / "baseline", timeout_s=30, prepare_timeout_s=30,
                    run_command=[sys.executable, FAKE, "-o", "all"], max_reruns=1)


def ok_build(ticket: str = "D1", **kw) -> QARequest:
    return QARequest(build=BuildIn(ticket_id=ticket, status="success", steps=[
        {"repo": "EasiPlayer", "step": "build", "command": ["cmake", "--build", "/tmp/builds/EasiPlayer", "--parallel", "4"]}]), **kw)


def calls(tmp_path) -> list[str]:
    p = tmp_path / "calls.log"
    return p.read_text().splitlines() if p.exists() else []
