from __future__ import annotations

import json
import os
import sys
import time

import pytest

from conftest import FAKE, calls, ok_build
from qaagent.models import BuildIn, QARequest
from qaagent.qa import QAAgent
from qaagent.runner import pid_alive
from qaagent.verdict import save_baseline
from qaagent.models import TestCaseResult

ALL = ["tst_start", "tst_screenshot", "tst_load", "tst_prop"]
baseline_of = lambda cfg, **st: save_baseline(cfg, [TestCaseResult(suite="suite_player", name=n, status=st.get(n, "pass")) for n in ALL])      # noqa: E731


async def run(cfg, scenario, monkeypatch, req=None):
    monkeypatch.setenv("FAKE_SCENARIO", scenario)
    return await QAAgent(cfg).run(req or ok_build())


async def test_all_green(cfg, monkeypatch, tmp_path):
    baseline_of(cfg)
    r = await run(cfg, "all_pass", monkeypatch)
    assert r.status == "passed" and r.summary["total"] == 4 and r.summary["pass"] == 4 and r.feedback == ""
    assert "RESULTS_FOLDER=" + str(cfg.work_dir / "D1" / "runs" / "1" / "full") in calls(tmp_path)[0]       # le script reçoit bien son dossier
    for f in ("qa_report.json", "qa_report.md", "run.json"):
        assert (cfg.work_dir / "D1" / f).exists()
    assert r.runs[0].result_files == ["results.xml"]


async def test_failures_with_exit_code_zero_are_still_a_failure(cfg, monkeypatch):
    """LE piège : squishrunner renvoie 0 même quand des tests échouent. On décide sur le rapport, pas sur le code."""
    baseline_of(cfg)
    r = await run(cfg, "exit0_with_failures", monkeypatch)
    assert r.runs[0].exit_code == 0 and r.status == "failed" and r.new_failures == ["suite_player/tst_screenshot"]
    assert "x-testcase:/test.js:14" in r.feedback and ":MainWindow.StatusBar_QStatusBar" in r.feedback and "failed_1.png" in r.feedback
    assert "# QA FAILED" in r.feedback and "1 nouvel" in r.verdict_reason


async def test_non_zero_exit_with_a_report_is_judged_on_the_report(cfg, monkeypatch):
    baseline_of(cfg)
    r = await run(cfg, "exit_code_on_fail", monkeypatch)
    assert r.status == "failed" and any("code 1" in w for w in r.warnings)


async def test_no_results_is_an_error_never_a_pass(cfg, monkeypatch):
    for scen, needle in (("crash_no_results", "code 2"), ("silent_no_results", "RESULTS_FOLDER")):
        r = await run(cfg, scen, monkeypatch)
        assert r.status == "error" and needle in r.verdict_reason, (scen, r.verdict_reason)


async def test_script_that_ignores_the_results_folder_is_diagnosed(cfg, monkeypatch, tmp_path):
    monkeypatch.setenv("FAKE_FIXED_DIR", str(tmp_path / "hardcoded"))
    r = await run(cfg, "ignores_env", monkeypatch)
    assert r.status == "error" and "RESULTS_FOLDER" in r.verdict_reason and "QA_RESULTS_DIR_OVERRIDE" in r.verdict_reason
    cfg.results_dir_override = tmp_path / "hardcoded"                                  # une fois configuré : le rapport est trouvé
    baseline_of(cfg)
    assert (await run(cfg, "ignores_env", monkeypatch)).status == "passed"


async def test_stale_results_from_a_previous_run_are_never_read(cfg, monkeypatch, tmp_path):
    stale = tmp_path / "hardcoded"
    stale.mkdir()
    (stale / "results.xml").write_text(open(os.path.join(os.path.dirname(FAKE), "xml3_full.xml")).read())
    os.utime(stale / "results.xml", (1, 1))                                                # vieux résultats (avec des échecs) laissés par un run précédent
    cfg.results_dir_override = stale
    monkeypatch.setenv("FAKE_FIXED_DIR", str(stale))
    monkeypatch.setenv("FAKE_SCENARIO", "silent_no_results")
    r = await QAAgent(cfg).run(ok_build())
    assert r.status == "error" and r.tests == []


async def test_truncated_report_is_flagged(cfg, monkeypatch):
    r = await run(cfg, "truncated", monkeypatch)
    assert r.status == "error" and any("tronqué" in w for w in r.warnings)


async def test_timeout_kills_the_suite_and_is_an_error(cfg, monkeypatch):
    cfg.timeout_s = 2
    t0 = time.time()
    r = await run(cfg, "sleep", monkeypatch)
    assert r.status == "error" and r.runs[0].timed_out and time.time() - t0 < 20


async def test_known_failures_do_not_block_but_new_ones_do(cfg, monkeypatch):
    baseline_of(cfg, tst_screenshot="fail")
    r = await run(cfg, "regression", monkeypatch)
    assert r.status == "passed" and r.known_failures == ["suite_player/tst_screenshot"] and "connu" in r.verdict_reason
    baseline_of(cfg)                                                                      # même échec, mais la référence était verte
    assert (await run(cfg, "regression", monkeypatch)).status == "failed"


async def test_no_baseline_is_stated_explicitly(cfg, monkeypatch):
    r = await run(cfg, "regression", monkeypatch)
    assert r.status == "failed" and r.baseline == "absente" and "aucune référence" in r.verdict_reason and "No baseline" in r.feedback


async def test_flaky_test_is_detected_by_rerunning_only_the_failed_one(cfg, monkeypatch, tmp_path):
    baseline_of(cfg)
    cfg.rerun_command = [sys.executable, FAKE, "-o", "{testcases}"]
    r = await run(cfg, "flaky", monkeypatch)
    assert r.status == "passed" and r.flaky == ["suite_player/tst_screenshot"] and "instable" in r.verdict_reason
    assert len(r.runs) == 2 and "args=-o tst_screenshot" in calls(tmp_path)[1]            # le rejeu ne relance QUE le test en échec
    cfg.flaky_is_failure = True
    (tmp_path / "counter").unlink()
    assert (await run(cfg, "flaky", monkeypatch)).status == "failed"


async def test_consistent_failure_survives_the_rerun(cfg, monkeypatch):
    baseline_of(cfg)
    cfg.rerun_command = [sys.executable, FAKE, "-o", "{testcases}"]
    r = await run(cfg, "always_fail_rerun", monkeypatch)
    assert r.status == "failed" and r.classified[[c.key for c in r.classified].index("suite_player/tst_screenshot")].runs == 2


async def test_interrupted_suite_is_incomplete(cfg, monkeypatch, tmp_path):
    for s in ("tst_start", "tst_screenshot", "tst_load", "tst_prop"):
        (tmp_path / "suites" / "suite_player" / s).mkdir(parents=True)
    cfg.suites_dir = tmp_path / "suites"
    baseline_of(cfg, tst_screenshot="fail")                      # l'échec est connu : seul le test manquant compte
    r = await run(cfg, "abort_on_fail", monkeypatch)
    assert r.status == "incomplete" and r.missing_tests == ["suite_player/tst_load", "suite_player/tst_prop"]


async def test_targeted_tests_fail_fast_without_burning_the_full_suite(cfg, monkeypatch, tmp_path):
    baseline_of(cfg)
    cfg.targeted_command = [sys.executable, FAKE, "-o", "{testcases}"]
    r = await run(cfg, "regression", monkeypatch, ok_build(testcases=["suite_player/tst_screenshot"]))
    assert r.status == "failed" and "Échec rapide" in r.verdict_reason and len(calls(tmp_path)) == 1
    (tmp_path / "counter").unlink()
    ok = await run(cfg, "all_pass", monkeypatch, ok_build(testcases=["suite_player/tst_start"]))
    assert ok.status == "passed" and len(calls(tmp_path)) == 3                          # ciblé puis suite complète


async def test_gate_requires_a_successful_build(cfg, monkeypatch, tmp_path):
    assert (await QAAgent(cfg).run(QARequest(ticket_id="D1"))).status == "rejected"
    bad = QARequest(build=BuildIn(ticket_id="D1", status="failed", status_reason="1 error"))
    r = await QAAgent(cfg).run(bad)
    assert r.status == "rejected" and "Compilateur n'a pas réussi" in r.verdict_reason and calls(tmp_path) == []
    monkeypatch.setenv("FAKE_SCENARIO", "all_pass")
    baseline_of(cfg)
    assert (await QAAgent(cfg).run(QARequest(ticket_id="D1", skip_gate=True))).status == "passed"


async def test_cleanup_always_runs_even_after_an_error(cfg, monkeypatch, tmp_path):
    marker = tmp_path / "cleaned"
    cfg.cleanup_command = ["touch", str(marker)]
    await run(cfg, "crash_no_results", monkeypatch)
    assert marker.exists()


async def test_prepare_failure_stops_before_any_test_and_still_cleans(cfg, monkeypatch, tmp_path):
    cfg.prepare_command = ["false"]
    cfg.cleanup_command = ["touch", str(tmp_path / "cleaned")]
    r = await run(cfg, "all_pass", monkeypatch)
    assert r.status == "error" and "préparation" in r.verdict_reason and calls(tmp_path) == [] and (tmp_path / "cleaned").exists()


async def test_prepare_receives_the_build_dir_from_the_compiler_report(cfg, monkeypatch, tmp_path):
    out = tmp_path / "prep.txt"
    cfg.prepare_command = [sys.executable, "-c", "import sys; open(sys.argv[1],'w').write(sys.argv[2])", str(out), "{build_dir:EasiPlayer}"]
    baseline_of(cfg)
    r = await run(cfg, "all_pass", monkeypatch)
    assert r.status == "passed" and out.read_text() == "/tmp/builds/EasiPlayer"
    cfg.prepare_command = ["echo", "{build_dir:Unknown}"]
    assert "build_dir inconnu" in (await run(cfg, "all_pass", monkeypatch)).verdict_reason


async def test_suspect_cpp_files_come_from_the_architect(cfg, monkeypatch):
    class Arch:
        async def search(self, q, kind=None, limit=5):
            assert "StatusBar" in q and "screenshot" in q
            return [{"ref": "EasiPlayer/ui/mainwindow.cpp", "kind": "file", "snip": "MainWindow : onFinished met à jour la barre d'état"}]
        async def aclose(self): ...
    monkeypatch.setenv("FAKE_SCENARIO", "regression")
    r = await QAAgent(cfg, Arch()).run(ok_build())
    assert r.classified[[c.key for c in r.classified].index("suite_player/tst_screenshot")].suspects[0]["ref"] == "EasiPlayer/ui/mainwindow.cpp"
    assert "Suspect C++ files" in r.feedback and "mainwindow.cpp" in r.feedback


async def test_unreachable_architect_does_not_break_the_verdict(cfg, monkeypatch):
    class Down:
        async def search(self, *a, **k): raise ConnectionError("down")
        async def aclose(self): ...
    monkeypatch.setenv("FAKE_SCENARIO", "regression")
    r = await QAAgent(cfg, Down()).run(ok_build())
    assert r.status == "failed" and any("Architecte injoignable" in w for w in r.warnings)


async def test_resume_after_a_service_restart_analyzes_the_results(cfg, monkeypatch, tmp_path):
    """Le service redémarre pendant les 6 h de la suite : le script a continué, les résultats existent -> on les analyse au lieu de les perdre."""
    monkeypatch.setenv("FAKE_SCENARIO", "regression")
    res = tmp_path / "qa" / "D1" / "runs" / "1" / "full"
    res.mkdir(parents=True)
    import subprocess
    subprocess.run([sys.executable, FAKE, "-o", "all"], env={**os.environ, "RESULTS_FOLDER": str(res)}, check=True, capture_output=True)
    (tmp_path / "qa" / "D1" / "run.json").write_text(json.dumps({"state": "running", "stage": "full", "results_dir": str(res), "started": time.time() - 60,
                                                                    "command": [sys.executable, FAKE], "log_path": str(res.parent / "full.log")}))
    baseline_of(cfg)
    r = await QAAgent(cfg).resume("D1")
    assert r.status == "failed" and any("redémarrage" in w for w in r.warnings) and r.runs[0].exit_code is None


def test_pid_alive_checks_identity():
    assert pid_alive(os.getpid(), "python") and not pid_alive(999999, "x")
    assert not pid_alive(os.getpid(), "definitely-not-this-program")
