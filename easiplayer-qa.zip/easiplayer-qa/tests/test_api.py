from __future__ import annotations

import json
import sys
import time

from fastapi.testclient import TestClient

from conftest import FAKE, ok_build
from qaagent.api import create_app
from qaagent.models import TestCaseResult
from qaagent.verdict import save_baseline

NAMES = ["tst_start", "tst_screenshot", "tst_load", "tst_prop"]


def wait(c, tid, timeout=30):
    t0 = time.time()
    while time.time() - t0 < timeout:
        st = c.get(f"/runs/{tid}").json()
        if st["state"] == "done":
            return st
        time.sleep(0.1)
    raise AssertionError("run non terminé")


def baseline(cfg, **st):
    save_baseline(cfg, [TestCaseResult(suite="suite_player", name=n, status=st.get(n, "pass")) for n in NAMES])


def test_full_flow_status_report_feedback_and_baseline(cfg, monkeypatch):
    monkeypatch.setenv("FAKE_SCENARIO", "regression")
    baseline(cfg)
    with TestClient(create_app(settings=cfg)) as c:
        assert c.post("/runs", json=ok_build().model_dump()).status_code == 202
        st = wait(c, "D1")
        assert st["status"] == "failed" and st["new_failures"] == ["suite_player/tst_screenshot"]
        assert "Rapport QA" in c.get("/runs/D1/report").text and "# QA FAILED" in c.get("/runs/D1/feedback").text
        assert c.get("/runs/D1?full=true").json()["report"]["tests"]
        # promouvoir une référence avec un échec exige une décision explicite
        assert c.post("/baseline", json={"ticket": "D1"}).status_code == 409
        r = c.post("/baseline", json={"ticket": "D1", "accept_failures": True, "note": "main@abc"}).json()
        assert r["tests"] == 4
        # 2e run : l'échec est désormais « connu » -> plus de régression
        assert c.post("/runs", json=ok_build().model_dump()).status_code == 202
        assert wait(c, "D1")["status"] == "passed"


def test_validation_gate_and_security(cfg):
    with TestClient(create_app(settings=cfg)) as c:
        assert c.post("/runs", json={}).status_code == 422
        r = c.post("/runs", json={"ticket_id": "D2"})
        assert r.status_code == 202 and wait(c, "D2")["status"] == "rejected"
        assert c.get("/runs/inconnu").status_code == 404
    cfg.api_token = "s3cret"
    with TestClient(create_app(settings=cfg)) as c:
        assert c.get("/runs/D1").status_code == 401 and c.get("/health", headers={"Authorization": "Bearer s3cret"}).status_code == 200


def test_running_suite_exposes_progress_and_can_be_cancelled(cfg, monkeypatch):
    monkeypatch.setenv("FAKE_SCENARIO", "sleep")
    cfg.timeout_s = 120
    with TestClient(create_app(settings=cfg)) as c:
        c.post("/runs", json=ok_build().model_dump())
        for _ in range(60):
            st = c.get("/runs/D1").json()
            if st.get("stage") == "full":
                break
            time.sleep(0.1)
        assert st["state"] == "running" and st["stage"] == "full"
        assert c.post("/runs/D1/cancel").json()["cancelled"]
        assert wait(c, "D1")["status"] == "error"


def test_service_restart_adopts_the_run_and_analyzes_its_results(cfg, monkeypatch, tmp_path):
    """Simule un redémarrage pendant la suite : run.json dit « running », le script a fini et écrit ses résultats."""
    import os
    import subprocess
    monkeypatch.setenv("FAKE_SCENARIO", "regression")
    res = cfg.work_dir / "D7" / "runs" / "1" / "full"
    res.mkdir(parents=True)
    subprocess.run([sys.executable, FAKE, "-o", "all"], env={**os.environ, "RESULTS_FOLDER": str(res)}, check=True, capture_output=True)
    (cfg.work_dir / "D7" / "run.json").write_text(json.dumps({"state": "running", "stage": "full", "pid": 999999, "results_dir": str(res), "started": time.time() - 30,
                                                                "command": [sys.executable, FAKE], "log_path": str(res.parent / "full.log")}))
    baseline(cfg)
    with TestClient(create_app(settings=cfg)) as c:
        st = wait(c, "D7")
        assert st["status"] == "failed" and st["new_failures"] == ["suite_player/tst_screenshot"]
    # run interrompu sans AUCUN résultat : marqué comme tel, jamais « passed »
    (cfg.work_dir / "D8").mkdir()
    (cfg.work_dir / "D8" / "run.json").write_text(json.dumps({"state": "running", "pid": 999999, "results_dir": str(tmp_path / "vide")}))
    with TestClient(create_app(settings=cfg)) as c:
        assert json.loads((cfg.work_dir / "D8" / "run.json").read_text())["status"] == "error"
