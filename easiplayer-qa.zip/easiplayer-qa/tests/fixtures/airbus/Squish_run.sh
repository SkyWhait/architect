#!/bin/bash

#-----------------------------------------
# Usage
#-----------------------------------------
function usage() {
	exe=`basename ${BASH_SOURCE[0]}`
	cat << EOF
    $exe [-n <times>] [-o <option>] [-t <test_case>] [-i]
    this script launch squish runner
    options:
      -n : number of execution 
      -o : name of the launch option (all, all_without, perfo, group1, group2, group3, group4)
      -t : testcase to be run
      -i : squish ide
      -h : help
	
EOF
}


function buildEnvironment() {
    #create folder pour squish result
    if [[ -d $EAP_SERVEUR_TMP ]]; then 
        rm -Rf $EAP_SERVEUR_TMP >> /dev/null
        mkdir -p $EAP_SERVEUR_TMP >> /dev/null
    else
        mkdir -p $EAP_SERVEUR_TMP >> /dev/null
    fi
    chmod g+w $EAP_SERVEUR_TMP

    if [[ -d $EAP_OUTPUT ]]; then 
        rm -Rf $EAP_OUTPUT >> /dev/null
        mkdir -p $EAP_OUTPUT >> /dev/null
    else
        mkdir -p $EAP_OUTPUT >> /dev/null
    fi
    chmod g+w $EAP_OUTPUT

    if [[ -d $EAP_RESULT ]]; then 
        rm -Rf $EAP_RESULT >> /dev/null
        mkdir -p $EAP_RESULT >> /dev/null
    else
        mkdir -p $EAP_RESULT >> /dev/null
    fi
    chmod g+w $EAP_RESULT
}

function cleanEnvironment() {
    #folder created by squish test suite
    if [[ -d $EAP_INPUT_TMP ]]; then 
        rm -Rf $EAP_INPUT_TMP >> /dev/null
    fi

    if [[ -d $EAP_OUTPUT_TMP ]]; then 
        rm -Rf $EAP_OUTPUT_TMP >> /dev/null
    fi

    if [[ -d $EAP_SERVEUR_TMP ]]; then 
        rm -Rf $EAP_SERVEUR_TMP >> /dev/null
    fi

    if [[ -d $EAP_TEST_SAVE_TMP ]]; then 
        rm -Rf $EAP_TEST_SAVE_TMP >> /dev/null
    fi

    if [[ -f $EAP_LOG_TMP ]]; then 
        rm -f $EAP_LOG_TMP >> /dev/null
    fi

    if [[ -d ~/.squish ]]; then 
        rm -Rf ~/.squish >> /dev/null
    fi
}

function squishServerStop() {
    $SQUISH_VERSION/bin/squishserver --stop
    rm -Rf  $EAP_SERVEUR_TMP/squish_server_local*.ini >> /dev/null
}

function squishServerStart() {
    sed  -e "s@\#WORKSPACE\#@"$WORKSPACE"@g" $WORKSPACE/server.ini >  $EAP_SERVEUR_TMP/squish_server_local-$SQUISH_DATE.ini
    $SQUISH_VERSION/bin/squishserver --configfile $EAP_SERVEUR_TMP/squish_server_local-$SQUISH_DATE.ini &
}
#-----------------------------------------
# set default values
#-----------------------------------------
SCRIPT_NAME=`basename ${BASH_SOURCE[0]}`
SCRIPT_PATH=$(realpath $0)
SCRIPT_DIR=$(dirname $SCRIPT_PATH)
export WORKSPACE=$SCRIPT_DIR
export TMP_BASE_DIR='/tmp'
export RESULTS_FOLDER=$WORKSPACE/Results

numberoftest=''
option=''
testcase=''
ide=''

# process command line argument parsing
while getopts "n:o:t:ih" opt ; do
	case "$opt" in
		n)  numberoftest=$OPTARG;;
		o)  option=$OPTARG;;
		t)  testcase=$OPTARG;;
		i)  ide='yes';;
		h)  usage; exit 1;;
		\?) echo "Error : Invalid option: -$OPTARG" >&2; usage; exit 1;;
		:)  echo "Error : Option -$OPTARG requires an argument." >&2; usage; exit 1;;
	esac
done

# retrieve last parameter (command) if exist
shift `expr  $OPTIND - 1`
cmd=$@

source ./Environment.sh
cleanEnvironment
squishServerStop

if [[ $ide == 'yes' ]]; then
    buildEnvironment
    $SQUISH_VERSION/bin/squishserver --config addAUT EasiPlayerWrapper.sh $WORKSPACE
    $SQUISH_VERSION/bin/squishserver --config addAUT EasiPlayerWrapperWithoutDBus.sh $WORKSPACE
    $SQUISH_VERSION/bin/squishserver --config addAUT EasiPlayerDBusWrapper.sh $WORKSPACE
    $SQUISH_VERSION/bin/squishide 
    $SQUISH_VERSION/bin/squishserver --config removeAUT EasiPlayerWrapper.sh $WORKSPACE
    $SQUISH_VERSION/bin/squishserver --config removeAUT EasiPlayerWrapperWithoutDBus.sh $WORKSPACE
    $SQUISH_VERSION/bin/squishserver --config removeAUT EasiPlayerDBusWrapper.sh $WORKSPACE
    cleanEnvironment
elif [[ ! -z $numberoftest ]]; then
    echo -e $BLUE"Starting of multiple execution of all tests."$NORMAL
    if [[ ! -d $RESULTS_FOLDER ]]; then
        mkdir $RESULTS_FOLDER
    fi
    i=0
    while [ $i -lt $numberoftest ]
    do
	source ./Environment.sh
        buildEnvironment
        squishServerStart
        $SQUISH_VERSION/bin/squishrunner --testsuite $EAP_SUITE_DIR  --tags ~IN_PROGRESS --tags ~PERFO --reportgen html,$EAP_RESULT
        cleanEnvironment
        squishServerStop
	sleep 10
        i=$[$i+1]
    done
    echo -e $BLUE"End of multiple execution."$NORMAL
elif [[ ! -z $testcase ]]; then
    buildEnvironment
    squishServerStart
    echo -e $BLUE"Starting execution of test case $testcase."$NORMAL
    $SQUISH_VERSION/bin/squishrunner --testsuite $EAP_SUITE_DIR --testcase $testcase --reportgen html,$EAP_RESULT
    echo -e $BLUE"End of execution."$NORMAL
    cleanEnvironment
    squishServerStop
else
    buildEnvironment
    squishServerStart
    case $option in
        "all")
            echo -e $BLUE"Starting execution of $option tests."$NORMAL
            $SQUISH_VERSION/bin/squishrunner --testsuite $EAP_SUITE_DIR  --tags ~IN_PROGRESS --tags ~PERFO --reportgen html,$EAP_RESULT
            ;;
        "all_without")
            echo -e $BLUE"Starting execution of $option tests."$NORMAL
            $SQUISH_VERSION/bin/squishrunner --testsuite $EAP_SUITE_DIR --tags ~WITHOUT --reportgen html,$EAP_RESULT
            ;;
        "perfo")
            echo -e $BLUE"Starting execution of $option tests."$NORMAL
            $SQUISH_VERSION/bin/squishrunner --testsuite $EAP_SUITE_DIR --tags PERFO --reportgen html,$EAP_RESULT
            ;;
        "group1")
            echo -e $BLUE"Starting execution of $option tests."$NORMAL
            $SQUISH_VERSION/bin/squishrunner --testsuite $EAP_SUITE_DIR --testcase tst_STD-EAP-INTERNAL_VARIABLE-00001 --testcase tst_STD-EAP-STP_CREATION-00001 --testcase  tst_STD-EAP-STP_BLOCK-00001 --testcase tst_STD-EAP-CONFIG_DIRECTORIES-00001 --testcase tst_STD-EAP-STP_EXTERNAL-00001 --testcase tst_STD-EAP-STP-LOADING_SAVING-00001 --testcase tst_STD-EAP-STP_EXTERNAL-00002 --testcase tst_STD-EAP-REPORT-00001 --testcase  tst_STD-EAP-GRAMMAR_CHECKS-00001 --testcase tst_STD-EAP-TYPE_CONSISTENCY-00001 --tags ~IN_PROGRESS --tags ~PERFO --reportgen html,$EAP_RESULT
            ;;
        "group2")
            echo -e $BLUE"Starting execution of $option tests."$NORMAL
            $SQUISH_VERSION/bin/squishrunner --testsuite $EAP_SUITE_DIR --testcase tst_STD-EAP-INFO_IDENTIFICATION-00001 --testcase tst_STD-EAP-CHAR_CHECKS-00001 --testcase tst_STD-EAP-USHORT_CHECKS-00001 --testcase tst_STD-EAP-SHORT_CHECKS-00001 --testcase tst_STD-EAP-ULONG_CHECKS-00001 --testcase tst_STD-EAP-LONG_CHECKS-00001 --testcase tst_STD-EAP-FLOAT_CHECKS-00001 --testcase tst_STD-EAP-DOUBLE_CHECKS-00001 --testcase tst_STD-EAP-ENUM_CHECKS-00001 --testcase tst_STD-EAP-ULONGLONG_CHECKS-00001 --testcase tst_STD-EAP-LONGLONG_CHECKS-00001 --testcase tst_STD-EAP-STRING_CHECKS-00001 --tags ~IN_PROGRESS --tags ~PERFO --reportgen html,$EAP_RESULT
            ;;
        "group3")
            echo -e $BLUE"Starting execution of $option tests."$NORMAL
            $SQUISH_VERSION/bin/squishrunner --testsuite $EAP_SUITE_DIR --testcase tst_STD-EAP-TEST_SESSION-00001 --testcase tst_STD-EAP-SIGNED_MODE-00001 --testcase tst_STD-EAP-BATCH_MODE-00001 --testcase tst_STD-EAP-INTERACTIVE_MODE-00001 --tags ~IN_PROGRESS --tags ~PERFO --reportgen html,$EAP_RESULT
            ;;
        "group4")
            echo -e $BLUE"Starting execution of $option test."$NORMAL
            $SQUISH_VERSION/bin/squishrunner --testsuite $EAP_SUITE_DIR --testcase tst_STD-EAP-ARRAY_PARSER-00001 --testcase tst_STD-EAP-MARGIN-00001 --testcase tst_STD-EAP-COPY_OPER-00001 --testcase tst_STD-EAP-INTERACTIVE_MODE-00001 --testcase tst_STD-EAP-TYPE_CONSISTENCY-00001 --testcase tst_STD-EAP-PERFO-00001 --testcase tst_STD-EAP-PRESS_OPER-00001 --testcase tst_STD-EAP-AVATAR_CONVERSION-00001 --testcase tst_STD-EAP-INIT_OPER-00001 --testcase tst_STD-EAP-MAIN_WIDGETS-00002 --testcase tst_STD-EAP-PLUGIN_API-00001 --tags ~IN_PROGRESS --tags ~PERFO --reportgen html,$EAP_RESULT
            ;;
        "debug")
            echo -e $BLUE"Starting execution of $option test."$NORMAL
            $SQUISH_VERSION/bin/squishrunner --testsuite $EAP_SUITE_DIR --testcase tst_STD-EAP-STP_CREATION-00001 --tags ~IN_PROGRESS --tags ~PERFO --reportgen html,$EAP_RESULT
            ;;
        *)
            echo -e $BLUE"Wrong argument $option nothing to do"$NORMAL
            ;;
    esac
    cleanEnvironment
    squishServerStop
fi
