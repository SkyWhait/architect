#!/usr/bin/env python3
"""Faux `Squish_run.sh` : écrit un rapport XML3 dans $RESULTS_FOLDER selon FAKE_SCENARIO. Sert à tester l'agent QA sans Squish.
Les scénarios reproduisent les situations réelles : échecs avec code de sortie 0, crash sans résultat, rapport tronqué, test instable..."""
import os
import sys
import time
from pathlib import Path

SCEN = os.environ.get("FAKE_SCENARIO", "all_pass")
OUT = Path(os.environ.get("FAKE_FIXED_DIR") if SCEN == "ignores_env" else os.environ["RESULTS_FOLDER"])
COUNTER = Path(os.environ.get("FAKE_COUNTER", "/tmp/fake_squish_counter"))
n = int(COUNTER.read_text()) + 1 if COUNTER.exists() else 1
COUNTER.write_text(str(n))
with open(os.environ.get("FAKE_LOG", "/dev/null"), "a") as f:
    f.write(f"call {n} args={' '.join(sys.argv[1:])} scen={SCEN} RESULTS_FOLDER={os.environ.get('RESULTS_FOLDER')}\n")

ALL = ["tst_start", "tst_screenshot", "tst_load", "tst_prop"]
args = sys.argv[1:]
wanted = [a for a in args[args.index("-o") + 1:] if a != "all"] if "-o" in args else []
names = wanted or ALL
if SCEN == "abort_on_fail":
    names = names[:2]


def verdict(name: str) -> str:
    if SCEN in {"regression", "exit0_with_failures", "exit_code_on_fail", "abort_on_fail"} and name == "tst_screenshot":
        return "FAIL"
    if SCEN == "flaky" and name == "tst_screenshot" and n == 1:
        return "FAIL"
    if SCEN == "always_fail_rerun" and name == "tst_screenshot":
        return "FAIL"
    return "PASS"


def case(name: str) -> str:
    v = verdict(name)
    extra = ""
    if v == "FAIL":
        extra = ('<objectName><![CDATA[:MainWindow.StatusBar_QStatusBar]]></objectName>'
                 '<failedImage><![CDATA[x-results:/suite_player/%s/verificationPoints/failedImages/failed_1.png]]></failedImage>' % name)
    return f'''<test type="testcase"><prolog time="2026-10-30T10:00:00+01:00"><name><![CDATA[{name}]]></name></prolog>
<verification><location><uri><![CDATA[x-testcase:/test.js]]></uri><lineNo><![CDATA[14]]></lineNo></location>
<scriptedVerificationResult time="2026-10-30T10:00:01+01:00" type="{v}"><text><![CDATA[Comparison]]></text><detail><![CDATA[status bar shows 'Done twice']]></detail>{extra}</scriptedVerificationResult></verification>
<epilog time="2026-10-30T10:00:05+01:00"/></test>'''


if SCEN == "sleep":
    print("2026-10-30T10:00:00+01:00 START  tst_start", flush=True)
    time.sleep(60)
if SCEN in {"crash_no_results"}:
    print("squishserver: cannot connect to AUT", file=sys.stderr)
    sys.exit(2)
if SCEN == "silent_no_results":
    print("done (but nothing written)")
    sys.exit(0)

OUT.mkdir(parents=True, exist_ok=True)
for nm in names:
    print(f"2026-10-30T10:00:00+01:00 START  {nm}", flush=True)
    print(f"2026-10-30T10:00:05+01:00 {'FAIL' if verdict(nm) == 'FAIL' else 'PASS'}   Comparison", flush=True)
    print(f"2026-10-30T10:00:05+01:00 END    {nm}", flush=True)
xml = ('<?xml version="1.0" encoding="UTF-8"?><SquishReport version="3.4" xmlns="http://www.froglogic.com/resources/schemas/xml3">'
       '<test type="testsuite"><prolog time="2026-10-30T10:00:00+01:00"><name><![CDATA[suite_player]]></name></prolog>'
       + "".join(case(x) for x in names) + '<epilog time="2026-10-30T10:30:00+01:00"/></test></SquishReport>')
if SCEN == "truncated":
    xml = xml[: len(xml) // 2]
(OUT / "results.xml").write_text(xml)
sys.exit(1 if SCEN == "exit_code_on_fail" else 0)
