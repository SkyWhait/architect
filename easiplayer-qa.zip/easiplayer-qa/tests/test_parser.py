"""Analyseur de rapports Squish. Les fixtures sont MODELÉES sur la documentation officielle (xml3_doc_example.xml en est l'exemple
exact) : elles n'ont pas été produites par un vrai squishrunner — voir README pour valider sur tes propres résultats."""
from __future__ import annotations

import shutil
from pathlib import Path

from qaagent.squish_parser import collect, parse_file, progress_from_line

FIX = Path(__file__).parent / "fixtures"


def by_name(tests):
    return {t.name: t for t in tests}


def test_official_doc_example():
    (t,) = parse_file(FIX / "xml3_doc_example.xml")
    assert (t.suite, t.name, t.status, t.verifications, t.passed) == ("suite_test", "tst_case1", "fail", 2, 1)
    f = t.failures[0]
    assert (f.kind, f.verification, f.script, f.line) == ("FAIL", "Comparison", "x-testcase:/test.py", 3) and "not equal" in f.detail


def test_every_result_type_is_interpreted():
    t = by_name(parse_file(FIX / "xml3_full.xml"))
    assert t["tst_start"].status == "pass" and t["tst_start"].warnings == ["slow response"] and t["tst_start"].log == ["Application started"]
    shot = t["tst_screenshot"]
    assert shot.status == "fail" and shot.failures[0].object_name == ":MainWindow.StatusBar_QStatusBar" and shot.failures[0].line == 14
    assert shot.failures[0].attachments == ["x-results:/suite_player/tst_screenshot/verificationPoints/failedImages/failed_1.png"]
    crash = t["tst_crash"]
    assert crash.status == "error" and {f.kind for f in crash.failures} == {"ERROR", "FATAL"} and "SIGSEGV" in crash.failures[1].message
    assert t["tst_xfail"].status == "pass" and not t["tst_xfail"].failures                 # échec attendu : ne casse rien
    assert t["tst_xpass"].status == "pass" and any("XPASS" in w for w in t["tst_xpass"].warnings)
    assert t["tst_prop"].status == "pass" and t["tst_load"].suite == "suite_plugins"


def test_a_test_that_verified_nothing_is_an_error_not_a_pass():
    e = by_name(parse_file(FIX / "xml3_full.xml"))["tst_empty"]
    assert e.status == "error" and "did not verify anything" in e.warnings[0]


def test_durations_come_from_prolog_and_epilog():
    assert by_name(parse_file(FIX / "xml3_full.xml"))["tst_start"].seconds == 9.5


def test_namespaced_and_plain_xml_are_both_read(tmp_path):
    plain = (FIX / "xml3_doc_example.xml").read_text().replace(' xmlns="http://www.froglogic.com/resources/schemas/xml3"', "")
    (tmp_path / "plain.xml").write_text(plain)
    assert parse_file(tmp_path / "plain.xml")[0].status == "fail"


def test_junit():
    t = by_name(parse_file(FIX / "junit.xml"))
    assert [t[n].status for n in ("tst_start", "tst_screenshot", "tst_crash", "tst_manual")] == ["pass", "fail", "error", "skipped"]
    assert t["tst_screenshot"].failures[0].message == "Screenshots are different" and t["tst_start"].seconds == 12.5


def test_results_folder_is_scanned_recursively_and_ignores_other_xml(tmp_path):
    shutil.copy(FIX / "xml3_full.xml", tmp_path / "results.xml")
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "settings.xml").write_text("<config><a/></config>")
    (tmp_path / "sub" / "notes.txt").write_text("hello")
    tests, used, broken = collect(tmp_path)
    assert len(tests) == 8 and used == ["results.xml"] and broken == []


def test_a_truncated_report_is_flagged_not_silently_ignored(tmp_path):
    shutil.copy(FIX / "xml3_truncated.xml", tmp_path / "results.xml")
    tests, used, broken = collect(tmp_path)
    assert tests == [] and broken == ["results.xml"]


def test_progress_lines_are_best_effort_only():
    st: dict = {}
    for ln in ["2026-10-30T10:00:00+01:00 START  tst_start", "2026-10-30T10:00:09+01:00 FAIL   Comparison", "garbage", "2026-10-30T10:00:10 END tst_start"]:
        progress_from_line(ln, st)
    assert st == {"current": "tst_start", "started": 1, "fails_seen": 1, "ended": 1}
