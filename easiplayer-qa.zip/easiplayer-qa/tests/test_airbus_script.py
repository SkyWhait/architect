"""Le QA face au VRAI Squish_run.sh d'Airbus (texte original), avec de faux squishrunner/squishserver : multi-tests par `-t`, rapport xml3 obtenu par copie du script,
licence, sélection des bons tests, explication pour le Développeur."""
from __future__ import annotations

import pytest

from airbus_world import make_squish_dir
from conftest import ok_build
from qaagent.config import Settings
from qaagent.models import ChangeContext, QARequest
from qaagent.qa import QAAgent

CHECK = "tst_STD-EAP-CHECK_OPER-00001"
SEQ = "tst_STD-EAP-SEQUENCER-00002"
CHANGE = ChangeContext(files=["EasiPlayer/src/EasiPlayer/model/std/TestCheck2Value.cpp"], symbols=["TestCheck2Value::runTest"],
                       plan_text="Take the current time after beforeDelay so the CHECK delay is honoured", ticket_text="Delay parameter not working, CHECK takes more time")


@pytest.fixture
def world(tmp_path, monkeypatch):
    home = tmp_path / "home"
    home.mkdir()
    (home / ".squish-3-license").write_text("license")
    monkeypatch.setenv("HOME", str(home))
    return make_squish_dir(tmp_path)


def cfg_for(world, tmp_path, **env):
    return Settings(work_dir=tmp_path / "qa", baseline_dir=tmp_path / "base", squish_dir=world, timeout_s=60, max_reruns=1,
                    env={"HOME": str(tmp_path / "home"), "FAKE_LOG": str(tmp_path / "squishrunner.log"), **env})


def runner_calls(tmp_path):
    p = tmp_path / "squishrunner.log"
    return p.read_text().splitlines() if p.exists() else []


def request(**kw):
    return ok_build(change=CHANGE, scope="targeted", **kw)


async def test_targeted_run_through_the_real_script_with_several_tests_and_xml_report(world, tmp_path):
    original = (world / "Squish_run.sh").read_text()
    r = await QAAgent(cfg_for(world, tmp_path)).run(request())
    assert r.status == "passed" and r.scope == "targeted" and "suite complète n'a PAS été lancée" in r.verdict_reason, (r.status, r.verdict_reason, r.warnings)
    chosen = [t.name for t in r.selection.tests]
    assert CHECK in chosen and SEQ in chosen and all(t.reasons for t in r.selection.tests)
    calls = runner_calls(tmp_path)
    assert len(calls) == 1 and all(f"--testcase {n}" in calls[0] for n in chosen)            # plusieurs tests en UN appel, via -t "a --testcase b"
    assert "--reportgen xml3," in calls[0] and "html" not in calls[0]                         # rapport lisible, pas du HTML
    assert (world / "Squish_run.sh").read_text() == original and not (world / "Squish_run.agent.sh").exists()   # l'original est intact, la copie est supprimée
    assert {t.name for t in r.tests} == set(chosen)


async def test_a_failing_targeted_test_comes_back_explained_for_the_developer(world, tmp_path):
    r = await QAAgent(cfg_for(world, tmp_path, FAKE_FAIL=CHECK)).run(request())
    assert r.status == "failed" and r.scope == "targeted" and r.new_failures == [f"suite_EasiPlayer/{CHECK}"]
    calls = runner_calls(tmp_path)
    assert len(calls) == 2 and calls[1].count("--testcase") == 1 and f"--testcase {CHECK}" in calls[1]          # rejeu du SEUL test en échec : l'échec est confirmé avant d'accuser le Développeur
    b = r.briefs[0]
    assert b.test == CHECK and b.zone == "CHECK_OPER"
    assert "CHECK completes before CHECK_TimeOut" in b.tests_what                                 # ce que le test vérifie
    assert b.failed["script"].endswith("test.py") and "test.compare" in b.failed["source"]       # la ligne du test qui a échoué
    assert b.gui_objects == ["mRunBt: QPushButton 'Run'"]                                         # l'objet GUI, décrit par names.py
    assert b.steps_before == ["Click on Run"]
    assert any("TestCheck2Value.cpp" in c for c in b.related_changes)                            # le lien avec SA modification
    assert any("domain rule" in w for w in b.why_selected)
    fb = r.developer_feedback
    assert "FAILING TEST: " + CHECK in fb and "What this test verifies" in fb and "Parts of YOUR change related to this test" in fb and "Do not edit the tests" in fb


async def test_flaky_targeted_test_is_not_blamed_on_the_developer(world, tmp_path):
    """Un test qui échoue au 1er passage puis réussit au rejeu n'est pas une régression."""
    import os
    flag = tmp_path / "failed_once"
    sr = world / "fake_squish" / "bin" / "squishrunner"
    sr.write_text(sr.read_text().replace('fails = set(filter(None, os.environ.get("FAKE_FAIL", "").split(",")))',
                                         'fails = set(filter(None, os.environ.get("FAKE_FAIL", "").split(",")))\nflag = Path(os.environ["FAKE_ONCE"])\nif fails and not flag.exists():\n    flag.write_text("1")\nelse:\n    fails = set()'))
    r = await QAAgent(cfg_for(world, tmp_path, FAKE_FAIL=CHECK, FAKE_ONCE=str(flag))).run(request())
    assert r.status == "passed" and r.flaky == [f"suite_EasiPlayer/{CHECK}"] and r.briefs == [] and r.developer_feedback == ""


async def test_full_suite_through_the_real_script(world, tmp_path):
    r = await QAAgent(cfg_for(world, tmp_path)).run(ok_build(change=CHANGE))
    assert r.status == "passed" and r.scope == "full" and r.summary["total"] == 8, (r.status, r.verdict_reason)
    calls = runner_calls(tmp_path)
    assert len(calls) == 2 and "--testcase" in calls[0] and "--testcase" not in calls[1] and "~IN_PROGRESS" in calls[1]     # ciblés, puis `-o all` du script


async def test_license_that_the_script_would_delete_is_caught_before_any_test(world, tmp_path, monkeypatch):
    home = tmp_path / "home"
    (home / ".squish-3-license").unlink()
    (home / ".squish").mkdir()
    (home / ".squish" / "licensekey").write_text("k")
    r = await QAAgent(cfg_for(world, tmp_path)).run(request())
    assert r.status == "error" and "supprime ~/.squish" in r.verdict_reason and runner_calls(tmp_path) == []
    (home / ".squish" / "licensekey").unlink()
    r = await QAAgent(cfg_for(world, tmp_path)).run(request())
    assert r.status == "error" and "Aucune licence Squish" in r.verdict_reason


async def test_a_changed_script_is_diagnosed_instead_of_producing_nothing(world, tmp_path):
    s = world / "Squish_run.sh"
    s.write_text(s.read_text().replace("--reportgen html,$EAP_RESULT", "--reportgen html,$OTHER"))
    r = await QAAgent(cfg_for(world, tmp_path)).run(request())
    assert r.status == "error" and "le script a changé" in r.verdict_reason and runner_calls(tmp_path) == []


async def test_without_the_xml_copy_the_html_only_script_gives_no_result_never_a_pass(world, tmp_path):
    """Contrôle : le script d'origine seul (HTML) ne permet aucune conclusion — c'est la copie xml3 qui rend le QA possible."""
    cfg = Settings(work_dir=tmp_path / "qa", baseline_dir=tmp_path / "base", timeout_s=60, run_cwd=world, results_dir_override=world / "out" / "result",
                   targeted_command=["./Squish_run.sh", "-t", "{testcases_joined}"], testcase_join=" --testcase ", suite_dir=world / "suite_EasiPlayer",
                   env={"HOME": str(tmp_path / "home"), "FAKE_LOG": str(tmp_path / "squishrunner.log")})
    r = await QAAgent(cfg).run(request())
    assert r.status == "error" and "aucun résultat exploitable" in r.verdict_reason


async def test_nothing_to_target_is_incomplete_not_passed(world, tmp_path):
    r = await QAAgent(cfg_for(world, tmp_path)).run(ok_build(change=ChangeContext(files=["EasiPlayer/src/zzz/Qwertyuiop.cpp"]), scope="targeted"))
    assert r.status == "incomplete" and runner_calls(tmp_path) == []
