"""Un faux « EasiPlayerSquishTests » qui fait tourner le VRAI Squish_run.sh d'Airbus (copié tel quel depuis easiplayer_claude_context.md).
Seuls les binaires Squish sont simulés (squishrunner / squishserver) ; Environment.sh est reconstitué avec les variables que le script utilise.
Les test.py sont écrits d'après l'API publique documentée de Squish (test.compare, waitForObject, names.xxx…) : ils ne sont PAS tes vrais tests."""
from __future__ import annotations

import shutil
import stat
from pathlib import Path

FIX = Path(__file__).parent / "fixtures" / "airbus"

ENVIRONMENT_SH = r'''#!/bin/bash
export BLUE="" NORMAL=""
export SQUISH_VERSION=$WORKSPACE/fake_squish
export SQUISH_DATE=20261120
export EAP_SUITE_DIR=$WORKSPACE/suite_EasiPlayer
export EAP_RESULT=$WORKSPACE/out/result
export EAP_OUTPUT=$WORKSPACE/out/output
export EAP_SERVEUR_TMP=$WORKSPACE/out/server
export EAP_INPUT_TMP=$WORKSPACE/out/input_tmp
export EAP_OUTPUT_TMP=$WORKSPACE/out/output_tmp
export EAP_TEST_SAVE_TMP=$WORKSPACE/out/save_tmp
export EAP_LOG_TMP=$WORKSPACE/out/log.tmp
'''

SQUISHRUNNER = r'''#!/usr/bin/env python3
import os, re, sys
from pathlib import Path
a = sys.argv[1:]
suite = a[a.index("--testsuite") + 1]
cases = [a[i + 1] for i, x in enumerate(a) if x == "--testcase"]
gens = [a[i + 1] for i, x in enumerate(a) if x == "--reportgen"]
log = os.environ.get("FAKE_LOG")
if log:
    open(log, "a").write("squishrunner " + " ".join(a) + "\n")
if not cases:
    cases = sorted(p.name for p in Path(suite).glob("tst_*"))
fails = set(filter(None, os.environ.get("FAKE_FAIL", "").split(",")))
def case(name):
    status = "FAIL" if name in fails else "PASS"
    src = (Path(suite) / name / "test.py").read_text().splitlines()
    line = next((i for i, l in enumerate(src, 1) if "test.compare" in l), 1)
    extra = "<objectName><![CDATA[:MainWindow.Run_QPushButton]]></objectName>" if status == "FAIL" else ""
    detail = "Values are not equal: expected 5000, got 5400" if status == "FAIL" else "ok"
    return (f'<test type="testcase"><prolog time="2026-11-20T10:00:00+01:00"><name><![CDATA[{name}]]></name></prolog>'
            f'<message time="2026-11-20T10:00:01+01:00" type="LOG"><text><![CDATA[Click on Run]]></text></message>'
            f'<verification><location><uri><![CDATA[x-testcase:/test.py]]></uri><lineNo><![CDATA[{line}]]></lineNo></location>'
            f'<scriptedVerificationResult time="2026-11-20T10:00:02+01:00" type="{status}"><text><![CDATA[Comparison]]></text><detail><![CDATA[{detail}]]></detail>{extra}'
            f'</scriptedVerificationResult></verification><epilog time="2026-11-20T10:00:05+01:00"/></test>')
for g in gens:
    fmt, path = g.split(",", 1)
    if fmt == "xml3":
        p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text('<?xml version="1.0" encoding="UTF-8"?><SquishReport version="3.4" xmlns="http://www.froglogic.com/resources/schemas/xml3">'
                     '<test type="testsuite"><prolog time="2026-11-20T10:00:00+01:00"><name><![CDATA[suite_EasiPlayer]]></name></prolog>'
                     + "".join(case(c) for c in cases) + '<epilog time="2026-11-20T10:30:00+01:00"/></test></SquishReport>')
    elif fmt == "html":
        Path(path).mkdir(parents=True, exist_ok=True)
        (Path(path) / "index.html").write_text("<html><body>report</body></html>")
sys.exit(0)
'''

SQUISHSERVER = "#!/bin/bash\nexit 0\n"

NAMES_PY = '''# -*- coding: utf-8 -*-
from objectmaphelper import *

mainWindow = {"type": "MainWindow", "visible": True}
mRunBt = {"container": mainWindow, "text": "Run", "type": "QPushButton", "visible": True}
mStopBt = {"container": mainWindow, "text": "Stop", "type": "QPushButton", "visible": True}
statusBar = {"container": mainWindow, "type": "QStatusBar", "objectName": "statusBar"}
'''

TESTS = {
    "tst_STD-EAP-CHECK_OPER-00001": '''# -*- coding: utf-8 -*-
# CHECK operation: the check must complete within its timeout, with and without Before_CHECK_Delay
import names

def main():
    startApplication("EasiPlayerWrapper")
    test.log("Load the CHECK procedure with a 5 ms delay")
    clickButton(waitForObject(names.mRunBt))
    test.compare(waitForObjectExists(names.statusBar).text, "Finished", "CHECK completes before CHECK_TimeOut")
    test.verify(True, "CHECK delay parameter is honoured")
''',
    "tst_STD-EAP-SEQUENCER-00002": '''# Sequencer: operations run in order and the Stop button interrupts the sequence
import names

def main():
    startApplication("EasiPlayerWrapper")
    clickButton(waitForObject(names.mRunBt))
    clickButton(waitForObject(names.mStopBt))
    test.compare(waitForObjectExists(names.statusBar).text, "Stopped", "Stop interrupts the sequence once")
''',
    "tst_STD-EAP-JAVA_SCRIPT_USE-00001": '''# Custom JavaScript files are loaded at startup in priority order
def main():
    startApplication("EasiPlayerWrapper")
    test.compare(1, 1, "Scripts are loaded without ReferenceError")
''',
    "tst_STD-EAP-AVATAR_CONVERSION-00001": '''# Avatar import of 1553 frames: ENABLE_RT / DISABLE_RT operations
def main():
    startApplication("EasiPlayerWrapper")
    test.compare(2, 2, "Avatar import resolves the 1553 interface of the sender")
''',
    "tst_STD-EAP-CHAR_CHECKS-00001": '''# CHAR variable checks against min/max limits
def main():
    startApplication("EasiPlayerWrapper")
    test.compare(255, 255, "CHAR upper limit accepted by the field validator")
''',
    "tst_STD-EAP-DOUBLE_CHECKS-00001": '''# DOUBLE variable checks with the field validator
def main():
    startApplication("EasiPlayerWrapper")
    test.compare(1.5, 1.5, "DOUBLE value within range")
''',
    "tst_STD-EAP-BATCH_MODE-00001": '''# Batch mode runs a procedure without the interactive GUI
def main():
    startApplication("EasiPlayerWrapperWithoutDBus")
    test.compare(0, 0, "Batch run exit code")
''',
    "tst_STD-EAP-PLUGIN_API-00001": '''# Plugin API over D-Bus
def main():
    startApplication("EasiPlayerDBusWrapper")
    test.compare("ok", "ok", "Plugin answers on D-Bus")
''',
}


def make_squish_dir(root: Path) -> Path:
    d = root / "EasiPlayerSquishTests"
    if d.exists():
        return d
    (d / "fake_squish" / "bin").mkdir(parents=True)
    shutil.copy(FIX / "Squish_run.sh", d / "Squish_run.sh")
    (d / "Squish_run.sh").chmod(0o755)
    (d / "Environment.sh").write_text(ENVIRONMENT_SH)
    (d / "server.ini").write_text("[server]\nworkspace=#WORKSPACE#\n")
    for name, body in (("squishrunner", SQUISHRUNNER), ("squishserver", SQUISHSERVER)):
        p = d / "fake_squish" / "bin" / name
        p.write_text(body)
        p.chmod(p.stat().st_mode | stat.S_IXUSR)
    suite = d / "suite_EasiPlayer"
    (suite / "shared" / "scripts").mkdir(parents=True)
    (suite / "shared" / "scripts" / "names.py").write_text(NAMES_PY)
    for name, src in TESTS.items():
        (suite / name).mkdir()
        (suite / name / "test.py").write_text(src)
    return d
