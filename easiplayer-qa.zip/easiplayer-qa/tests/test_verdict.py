from __future__ import annotations

import json

from qaagent.config import Settings
from qaagent.models import TestCaseResult
from qaagent.verdict import classify, decide, expected_tests, load_baseline, save_baseline


def t(name, status, suite="suite_a"):
    return TestCaseResult(suite=suite, name=name, status=status)


def run(first, final=None, baseline=None, missing=(), cfg=None, reruns=None):
    cfg = cfg or Settings()
    f1 = {x.key: x for x in first}
    f2 = {x.key: x for x in (final or first)}
    cl = classify(f1, f2, reruns or {}, baseline, cfg)
    return cl, decide(cl, list(missing), len(f2), baseline is not None, cfg)


def outcomes(cl):
    return {c.key.split("/")[-1]: c.outcome for c in cl}


def test_all_green_is_passed():
    cl, (st, why) = run([t("a", "pass"), t("b", "pass")], baseline={"tests": {"suite_a/a": "pass"}})
    assert st == "passed" and set(outcomes(cl).values()) == {"pass"}


def test_a_new_failure_blocks_even_with_a_baseline():
    cl, (st, why) = run([t("a", "pass"), t("b", "fail")], baseline={"tests": {"suite_a/a": "pass", "suite_a/b": "pass"}})
    assert st == "failed" and outcomes(cl)["b"] == "new_failure" and "1 nouvel" in why


def test_failures_already_in_the_baseline_do_not_block():
    cl, (st, why) = run([t("a", "pass"), t("b", "fail")], baseline={"tests": {"suite_a/a": "pass", "suite_a/b": "fail"}})
    assert st == "passed" and outcomes(cl)["b"] == "known_failure" and "échec(s) connu(s)" in why


def test_without_a_baseline_every_failure_counts_and_says_so():
    cl, (st, why) = run([t("a", "fail")])
    assert st == "failed" and "aucune référence" in why


def test_flaky_passes_with_a_warning_unless_configured_otherwise():
    first, final = [t("a", "fail")], [t("a", "pass")]
    cl, (st, why) = run(first, final, baseline={"tests": {"suite_a/a": "pass"}}, reruns={"suite_a/a": 2})
    assert st == "passed" and outcomes(cl)["a"] == "flaky" and cl[0].runs == 2
    cl, (st, why) = run(first, final, baseline={"tests": {"suite_a/a": "pass"}}, cfg=Settings(flaky_is_failure=True))
    assert st == "failed" and "instable" in why


def test_fixed_test_is_reported():
    cl, _ = run([t("a", "pass")], baseline={"tests": {"suite_a/a": "fail"}})
    assert outcomes(cl)["a"] == "fixed"


def test_missing_tests_make_the_run_incomplete_not_passed():
    cl, (st, why) = run([t("a", "pass")], missing=["suite_a/b", "suite_a/c"])
    assert st == "incomplete" and "suite_a/b" in why
    assert run([t("a", "pass")], missing=["suite_a/b"], cfg=Settings(fail_on_missing=False))[1][0] == "passed"


def test_nothing_parsed_is_an_error_never_a_success():
    assert decide([], [], 0, True, Settings())[0] == "error"


def test_error_status_counts_as_failure():
    assert run([t("a", "error")])[1][0] == "failed"


def test_expected_tests_from_suites_dir_or_baseline(tmp_path):
    for p in ("suite_a/tst_x", "suite_a/tst_y", "suite_b/tst_z", "suite_b/helpers"):
        (tmp_path / p).mkdir(parents=True)
    assert expected_tests(Settings(suites_dir=tmp_path), None) == {"suite_a/tst_x", "suite_a/tst_y", "suite_b/tst_z"}
    assert expected_tests(Settings(), {"tests": {"suite_a/a": "pass"}}) == {"suite_a/a"} and expected_tests(Settings(), None) == set()


def test_baseline_roundtrip(tmp_path):
    cfg = Settings(baseline_dir=tmp_path)
    assert load_baseline(cfg) is None
    save_baseline(cfg, [t("a", "pass"), t("b", "fail")], note="main@abc123")
    b = load_baseline(cfg)
    assert b["tests"] == {"suite_a/a": "pass", "suite_a/b": "fail"} and b["note"] == "main@abc123"
