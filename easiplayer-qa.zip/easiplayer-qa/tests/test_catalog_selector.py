"""Compréhension des tests : catalogue (ce que chaque test vérifie) et sélection des BONS tests, sur un faux dossier Squish bâti avec le vrai Squish_run.sh."""
from __future__ import annotations

from airbus_world import make_squish_dir
from qaagent.catalog import build_catalog, parse_names, split_words
from qaagent.models import ChangeContext
from qaagent.selector import select_tests


def suite(tmp_path):
    return make_squish_dir(tmp_path) / "suite_EasiPlayer"


def test_catalog_reads_what_each_test_checks(tmp_path):
    cat = build_catalog(suite(tmp_path))
    assert len(cat.cards) == 8 and not cat.warnings
    c = cat.cards["tst_STD-EAP-CHECK_OPER-00001"]
    assert (c.zone, c.number, c.language) == ("CHECK_OPER", 1, "python")
    assert [v.message for v in c.verifications if v.method == "compare"] == ["CHECK completes before CHECK_TimeOut"]
    assert any("Before_CHECK_Delay" in n for n in c.notes)                                     # le commentaire d'intention est lu
    assert [o.describe() for o in c.objects] == ["mRunBt: QPushButton 'Run'", "statusBar: QStatusBar objectName=statusBar"]
    assert "startApplication" in c.actions and "clickButton" in c.actions
    assert "CHECK completes" in c.summary()


def test_names_py_object_map_is_parsed(tmp_path):
    m = parse_names(suite(tmp_path) / "shared" / "scripts" / "names.py")
    assert m["mRunBt"].type == "QPushButton" and m["mRunBt"].text == "Run" and m["statusBar"].object_name == "statusBar"


def test_shared_scripts_and_data_files_belong_to_the_test(tmp_path):
    s = suite(tmp_path)
    (s / "shared" / "scripts" / "common.py").write_text('def check_done():\n    test.compare(1, 1, "common: run is done")\n')
    (s / "tst_STD-EAP-SEQUENCER-00002" / "test.py").write_text(
        'import names\nsource(findFile("scripts", "common.py"))\ndef main():\n    startApplication("W")\n    f = findFile("testdata", "seq_three_steps.xtp")\n    check_done()\n')
    c = build_catalog(s).cards["tst_STD-EAP-SEQUENCER-00002"]
    assert c.shared_scripts == ["common.py"] and c.data_files == ["seq_three_steps.xtp"]
    assert any(v.message == "[common.py] common: run is done" for v in c.verifications)


def test_unreadable_test_is_reported_not_fatal(tmp_path):
    s = suite(tmp_path)
    (s / "tst_STD-EAP-BATCH_MODE-00001" / "test.py").write_text("def main(:\n")
    cat = build_catalog(s)
    assert "tst_STD-EAP-BATCH_MODE-00001" in cat.cards and any("illisible" in w for w in cat.warnings)


def test_split_words():
    assert split_words("TestCheckValue Before_CHECK_Delay") == ["check", "value", "before", "check", "delay"]


def sel(tmp_path, **kw):
    return select_tests(ChangeContext(**kw), build_catalog(suite(tmp_path)))


def test_changes_to_the_checks_pick_the_sequencer_and_check_tests(tmp_path):
    r = sel(tmp_path, files=["EasiPlayer/src/EasiPlayer/model/std/TestCheck2Value.cpp"], symbols=["TestCheck2Value::runTest"],
            plan_text="Take the current time after beforeDelay so the CHECK delay is honoured", ticket_text="Delay parameter not working, CHECK takes more time")
    names = [t.name for t in r.tests]
    assert names[:2] == ["tst_STD-EAP-CHECK_OPER-00001", "tst_STD-EAP-SEQUENCER-00002"] or set(names[:2]) == {"tst_STD-EAP-CHECK_OPER-00001", "tst_STD-EAP-SEQUENCER-00002"}
    top = r.tests[0]
    assert any("domain rule" in x for x in top.reasons) and top.tests_what                      # raison + ce que le test vérifie
    assert "tst_STD-EAP-AVATAR_CONVERSION-00001" not in names and "tst_STD-EAP-BATCH_MODE-00001" not in names


def test_script_engine_and_avatar_and_types_map_to_their_zones(tmp_path):
    assert [t.name for t in sel(tmp_path, files=["EasiPlayer/src/EasiPlayer/custom/ScriptEngine.cpp"]).tests][0] == "tst_STD-EAP-JAVA_SCRIPT_USE-00001"
    assert [t.name for t in sel(tmp_path, files=["EasiPlayer/src/EasiPlayer/avatar/splitted/A2xtpFindMethods.cpp"]).tests][0] == "tst_STD-EAP-AVATAR_CONVERSION-00001"
    types = {t.name for t in sel(tmp_path, files=["EasiPlayer/src/EasiPlayer/model/interface/Information.cpp"]).tests}
    assert {"tst_STD-EAP-CHAR_CHECKS-00001", "tst_STD-EAP-DOUBLE_CHECKS-00001"} <= types       # toutes les zones *_CHECKS


def test_strategist_suggestions_are_validated_against_the_suite(tmp_path):
    r = sel(tmp_path, files=["EasiPlayer/src/x/Unrelated.cpp"], suggested_tests=["EasiPlayerSquishTests/suite_EasiPlayer/tst_STD-EAP-BATCH_MODE-00001", "tst_STD-EAP-DOES_NOT_EXIST-00001"])
    assert [t.name for t in r.tests] == ["tst_STD-EAP-BATCH_MODE-00001"] and r.tests[0].reasons == ["suggested by the Strategist's plan"]
    assert r.unknown_suggestions == ["tst_STD-EAP-DOES_NOT_EXIST-00001"]                        # jamais ignorée en silence


def test_no_link_means_no_selection_not_a_random_test(tmp_path):
    r = sel(tmp_path, files=["EasiPlayer/src/zzz/Qwertyuiop.cpp"], plan_text="refactor logging")
    assert r.tests == [] and "Aucun test" in r.note
    assert select_tests(ChangeContext(files=["x.cpp"]), build_catalog(tmp_path / "nope")).note.startswith("Catalogue de tests vide")


def test_selection_reports_the_group_of_the_real_script(tmp_path):
    r = sel(tmp_path, files=["EasiPlayer/src/EasiPlayer/model/interface/Information.cpp"])
    assert any("group2" in t.groups for t in r.tests if t.name.endswith("CHAR_CHECKS-00001"))
