# EasiPlayer QA — validation Squish (non-régression comportementale)

Lance la suite GUI Squish sur le build réussi du Compilateur et rend un **verdict de non-régression** fondé sur les **rapports**, avec les logs
et les preuves (script:ligne, objet GUI, image en échec). Aucun LLM : la décision doit être reproductible.

## Les trois pièges que cet agent évite (d'après la documentation officielle de Squish)

1. **`squishrunner` renvoie 0 même quand des tests échouent** (sauf `--exitCodeOnFail`). Le code de sortie de `Squish_run.sh` ne décide donc **jamais** : seul le contenu du rapport compte.
2. **« Pas de résultat » n'est pas « pas d'échec »** : aucun rapport, rapport tronqué (run tué), timeout, script introuvable => `error`, jamais `passed`. Un test qui ne vérifie rien est une erreur.
3. **Résultats périmés** : un dossier réutilisé contient les résultats du run précédent. Seuls les fichiers écrits *pendant* ce run sont lus.

## Verdict

| Résultat d'un test | Signification | Bloque ? |
|---|---|---|
| **nouvel échec** | échoue (même après rejeu) et ne l'était pas dans la référence | **oui** → `failed` |
| échec connu | échouait déjà dans la référence (quarantaine) | non, signalé |
| **instable** | échoue puis passe au rejeu | non (avertissement) — `QA_FLAKY_IS_FAILURE=true` pour bloquer |
| corrigé | échouait dans la référence, passe maintenant | non |
| **manquant** | attendu (suites_dir/référence) mais absent du rapport (suite interrompue, `--abortOnFail`) | oui → `incomplete` |

Sans référence, tout échec compte comme nouveau (dit explicitement). **La référence n'est jamais mise à jour automatiquement** (sinon les régressions
deviendraient la norme) : `qaagent baseline <dossier_de_résultats>` ou `POST /baseline` (échecs acceptés seulement avec `accept_failures=true`).

## Pipeline (LangGraph)

```
gate (Compilateur = success) ─► prepare (installer le build testé) ─► targeted (échec rapide, facultatif) ─► full (Squish_run.sh -o all)
   ─► analyze (XML3 / JUnit) ─► rerun ⟲ (SEULS les tests en échec) ─► verdict (+ fichiers C++ suspects via l'Architecte, facultatif)
   cleanup (squishserver, AUT) TOUJOURS exécuté
```

- **Échec rapide** : si des tests ciblés (ex. `plan.validation.suggested_squish`) échouent, la suite de 6 h n'est pas lancée.
- **Run de plusieurs heures** : état dans `run.json` (pid, étape, progression) ; `POST /runs/<t>/cancel` tue le groupe de processus ; **si le service redémarre**, il reprend le suivi
  (processus vivant) ou analyse les résultats déjà écrits.

## Formats lus

| Format | Source | Statut |
|---|---|---|
| **XML3** (`--reportgen xml3.x,<dossier>` → `results.xml`) | structure de la doc officielle | testsuite/testcase, `PASS/FAIL/XPASS/XFAIL/FATAL/ERROR`, vérifications scriptées/capture/propriété/table, messages `LOG/WARNING/FATAL`, BDD aplati |
| **JUnit** (`--reportgen junit,<fichier>`) | standard | failure/error/skipped |
| texte (stdout) | heuristique | **progression seulement**, jamais pour le verdict |

## Mise en route

```bash
pip install -e ".[dev]" && cp .env.example .env
pytest                                                           # 46 tests (faux Squish ; fixtures modélisées sur la doc)
qaagent parse /chemin/RESULTS_FOLDER                             # 1re étape OBLIGATOIRE : tes vrais rapports sont-ils compris ?
qaagent baseline /chemin/RESULTS_FOLDER --note "main@abc123"     # référence = un run sur un build connu comme bon
qaagent run --build-report comp_runs/D0002312/build_report.json  # ou loop_report.json
qaagent serve --port 8840                                        # POST /runs · GET /runs/<t>[/report|/feedback] · POST /runs/<t>/cancel · POST /baseline
```

**Brancher TON script** : `QA_RUN_COMMAND=["./Squish_run.sh","-o","all"]` ; il reçoit `$RESULTS_FOLDER` (variable configurable) — s'il l'écrase en dur, utilise `QA_RESULTS_DIR_OVERRIDE`.
`QA_PREPARE_COMMAND` installe le build du Compilateur là où Squish lance l'AUT (`{build_dir:EasiPlayer}` est retrouvé dans le rapport du Compilateur) ;
`QA_CLEANUP_COMMAND` arrête squishserver/les AUT ; `QA_XVFB=true` pour un affichage virtuel. Commandes **uniquement** celles de ta config (pas de shell, rien de généré par un LLM).


## V2 « Testeur » : les BONS tests, et un échec expliqué au Développeur

| Brique | Ce qu'elle fait | Comment c'est fiable |
|---|---|---|
| **Catalogue** (`qaagent catalog`) | lit chaque `test.py`/`test.js` : commentaires d'intention, messages des `test.compare/verify`, objets GUI (`names.xxx` décrits par `names.py`), fichiers de données, scripts partagés | `ast` (Python) : rien n'est deviné ; un test illisible est signalé |
| **Sélection** (`qaagent select`) | d'après la modification (fichiers, symboles, diff, plan du Stratège, ticket) : suggestions du Stratège **validées contre la suite**, table fichiers→zones, recoupement de mots pondéré par leur rareté | chaque test choisi porte ses RAISONS ; suggestion inconnue = listée, jamais ignorée ; aucun lien net = **aucun test ciblé** (jamais un test au hasard) |
| **Lancement réel** | `Squish_run.sh -t "A --testcase B"` (plusieurs tests en un appel, comme tes groupes) sur une copie du script avec rapport **xml3** | testé avec **ton vrai script** (texte original) et de faux `squishrunner` |
| **Échec -> Développeur** | un test ciblé en échec est **rejoué une fois** (instable ≠ régression), puis un « brief » par test : ce qu'il vérifie, quelle vérification a échoué (ligne du `test.py`), objet GUI, derniers pas, **quelles parties de SA modification y sont liées** | `developer_feedback` : texte prêt pour le prompt du Développeur |

`scope: "targeted"` : seulement les tests choisis (verdict **partiel**, dit comme tel) ; `"full"` (défaut) : ciblés d'abord, échec rapide sans brûler 6 h, puis suite complète.

**À faire une fois sur la vraie machine** (je n'ai vu ni tes `test.py` ni un rapport réel) :
1. `qaagent preflight --squish-dir /data/easiplayer/EasiPlayerSquishTests` (variables, licence, copie xml3) ;
2. `qaagent catalog --suite-dir …/suite_EasiPlayer` : **vérifier que la description de chaque test est juste** ;
3. `qaagent select --suite-dir … --file src/EasiPlayer/model/std/TestCheck2Value.cpp` : les tests choisis sont-ils les bons ? (affiner `QA_DOMAIN_MAP`) ;
4. `qaagent probe --squish-dir … --test tst_STD-EAP-CHAR_CHECKS-00001` : le script produit-il un `qa_results.xml` lisible ? (suppose que `xml3` accepte un chemin de fichier OU de dossier ; les deux sont lus).

## Limites connues — à lire avant la première vraie utilisation

- **Je n'ai jamais vu ton `Squish_run.sh` ni un vrai `$RESULTS_FOLDER`**, et je ne peux pas exécuter Squish ici. Les fixtures XML3 sont **modélisées sur la documentation officielle** (l'exemple officiel est testé tel quel), pas produites par un vrai squishrunner :
  lance `qaagent parse` sur un vrai dossier d'abord. Un fichier XML de rapport illisible est signalé, jamais ignoré.
- Tags `<retry>` (`--retry`) : leur contenu exact n'est pas documenté finement ; un test avec des tentatives qui échouent puis réussissent est **compté en échec** (prudence) — préfère le rejeu de l'agent.
- Le rejeu/ciblage dépend de ce que **ton** script accepte après `-o` (noms de tests ?) : configure `QA_TARGETED_COMMAND`/`QA_RERUN_COMMAND` en conséquence ; sans eux, pas de rejeu (les instables seront des échecs).
- Les « fichiers C++ suspects » sont une recherche plein texte (nom du test, objets GUI, message) : un point de départ.
- Un échec Squish peut venir du test, de l'environnement ou de l'application : l'agent établit **qu'il y a régression**, pas sa cause.
