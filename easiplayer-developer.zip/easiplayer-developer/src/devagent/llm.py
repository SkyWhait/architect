"""Client LLM (vLLM / API OpenAI) : sortie JSON imposée par schéma, déterministe, retries, budget de contexte."""
from __future__ import annotations

import asyncio
import json
import logging
import re
from typing import TypeVar

import tiktoken
from openai import AsyncOpenAI
from pydantic import BaseModel, ValidationError

from .config import Settings

log = logging.getLogger("devagent.llm")
T = TypeVar("T", bound=BaseModel)

try:
    _ENC = tiktoken.get_encoding("cl100k_base")
except Exception:                                    # hors-ligne sans cache tiktoken
    _ENC = None


def count_tokens(text: str) -> int:
    """Estimation prudente (le tokenizer Qwen produit ~10-15 % de tokens en plus que cl100k)."""
    n = len(_ENC.encode(text, disallowed_special=())) if _ENC else len(text) // 3
    return int(n * 1.15) + 8


def truncate_tokens(text: str, max_tokens: int, marker: str = "\n[... truncated ...]") -> str:
    t = count_tokens(text)
    if t <= max_tokens:
        return text
    return text[: int(len(text) * (max_tokens / t) * 0.93)] + marker


class LLM:
    def __init__(self, cfg: Settings):
        self.cfg = cfg
        self.client = AsyncOpenAI(base_url=cfg.llm_base_url, api_key=cfg.llm_api_key, timeout=cfg.llm_timeout_s)
        self.usage = {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0}

    @property
    def input_budget(self) -> int:
        return int(self.cfg.llm_max_context * 0.90) - self.cfg.llm_max_output

    async def json(self, system: str, user: str, schema: type[T], retries: int = 3) -> T:
        system = f"{system}\nAnswer with JSON only. Code and anchors must be copied/written verbatim; free-text fields (summary, reason) in English."
        user = truncate_tokens(user, self.input_budget - count_tokens(system))
        last: Exception | None = None
        for attempt in range(retries):
            try:
                r = await self.client.chat.completions.create(
                    model=self.cfg.llm_model,
                    messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
                    temperature=self.cfg.llm_temperature, seed=self.cfg.llm_seed, max_tokens=self.cfg.llm_max_output,
                    response_format={"type": "json_schema", "json_schema": {
                        "name": schema.__name__, "schema": schema.model_json_schema(), "strict": True}},
                )
                self.usage["calls"] += 1
                if r.usage:
                    self.usage["prompt_tokens"] += r.usage.prompt_tokens
                    self.usage["completion_tokens"] += r.usage.completion_tokens
                if r.choices[0].finish_reason == "length":
                    raise ValueError("output truncated (finish_reason=length)")
                return schema.model_validate_json(_extract_json(r.choices[0].message.content or ""))
            except (ValidationError, ValueError, json.JSONDecodeError) as e:
                last = e
                log.warning("sortie invalide (essai %d/%d) : %s", attempt + 1, retries, str(e)[:200])
            except Exception as e:                   # réseau, 5xx, vLLM redémarré...
                last = e
                log.warning("erreur LLM (essai %d/%d) : %s", attempt + 1, retries, str(e)[:200])
                await asyncio.sleep(min(2 ** attempt * 3, 30))
        raise RuntimeError(f"LLM a échoué après {retries} essais : {last}")


def _extract_json(raw: str) -> str:
    raw = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.M).strip()
    a, b = raw.find("{"), raw.rfind("}")
    return raw[a:b + 1] if a != -1 and b != -1 else raw
