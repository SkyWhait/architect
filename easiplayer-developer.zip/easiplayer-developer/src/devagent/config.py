from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="DEV_", env_file=".env", extra="ignore")

    # --- code source -----------------------------------------------------------------
    world_root: Path = Path("/data")              # contient les dépôts git ; les chemins du plan y sont relatifs
    work_dir: Path = Path("./dev_runs")           # worktrees, rapports, diffs
    base_ref: str = "HEAD"                        # point de départ de la branche de l'agent
    branch_prefix: str = "agent/"
    commit: bool = True                           # commit sur la branche de l'agent (jamais de push, jamais sur la branche d'origine)
    git_user_name: str = "EasiPlayer Developer Agent"
    git_user_email: str = "devagent@localhost"

    # --- LLM -------------------------------------------------------------------------
    llm_base_url: str = "http://localhost:8000/v1"
    llm_api_key: str = "EMPTY"
    llm_model: str = "Qwen/Qwen2.5-Coder-32B-Instruct-AWQ"
    llm_max_context: int = 32768
    llm_max_output: int = 4000
    llm_temperature: float = 0.0
    llm_seed: int = 7
    llm_timeout_s: float = 900.0

    # --- discipline d'édition ---------------------------------------------------------
    max_edit_attempts: int = 3                    # essais par fichier (le retour de vérification est renvoyé au LLM)
    view_budget_tokens: int = 12000               # code du fichier montré au LLM
    scope_slack_lines: int = 10                   # marge autour des symboles/lignes du plan
    max_removed_lines: int = 60
    max_changed_lines: int = 200
    allow_remove: bool = False                    # supprimer un fichier exige une autorisation explicite
    approve_review: bool = False                  # accepter un plan 'needs_review' (relu par un humain)

    # --- conventions du projet -----------------------------------------------------------
    qt_min_version: str = "5.9"                   # cibles Debian : Qt 5.9 et Qt 5.15 -> aucune API introduite après 5.9
    column_limit: int = 120                       # .clang-format : ColumnLimit
    format_mode: str = "auto"                     # "auto" : clang-format sur les lignes modifiées si disponible ; "off"
    clang_format_bin: str = "clang-format"
    clang_format_file: str | None = None          # sinon le .clang-format du dépôt (racine EasiPlayer/)
    format_timeout_s: float = 30.0
    forbidden_dirs: list[str] = ["build_*", "install", "redist"]      # composants de chemin interdits (n'importe où dans le chemin)
    commit_default_category: str = "General"
    commit_separator: str = ""                    # historique réel : « [EAP-12605][General]Restore … » (pas d'espace) ; mettre " " pour en ajouter un

    # --- Architecte (facultatif : contexte « déclarations des types appelés ») -----------------
    architect_url: str | None = None              # ex. http://localhost:8800 ; absent => pas de faits d'API, l'agent fonctionne quand même
    architect_token: str | None = None
    architect_timeout_s: float = 20.0
    facts_budget_tokens: int = 2500
    facts_max_symbols: int = 6

    # --- compilation (optionnelle) -------------------------------------------------------
    build_command: list[str] | None = None
    build_timeout_s: int = 3600
    max_build_rounds: int = 2

    api_token: str | None = None


def get_settings() -> Settings:
    s = Settings()
    s.work_dir.mkdir(parents=True, exist_ok=True)
    return s
