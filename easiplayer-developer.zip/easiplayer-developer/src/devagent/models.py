"""Modèles : entrée (plan du Stratège, lecture tolérante), sorties LLM (schémas imposés), rapport."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


# ===================== entrée : plan du Stratège (sous-ensemble tolérant, `extra=ignore`) ==================
class _In(BaseModel):
    model_config = ConfigDict(extra="ignore")


class PlanFile(_In):
    path: str
    change_type: Literal["modify", "add", "remove"] = "modify"
    symbols: list[str] = []
    line_hint: str = ""
    rationale: str = ""
    logic_change: str = ""


class PlanStep(_In):
    order: int = 0
    title: str = ""
    description: str = ""
    files: list[str] = []
    verification: str = ""


class PlanRisk(_In):
    description: str = ""
    area: str = "other"
    severity: str = "medium"
    mitigation: str = ""


class PlanVerification(_In):
    squish_tests: list[str] = []
    build_targets: list[str] = []
    manual_checks: list[str] = []


class PlanBody(_In):
    classification: str = "bug"
    root_cause: str = ""
    confidence: str = "medium"
    files_to_modify: list[PlanFile] = []
    steps: list[PlanStep] = []
    risks: list[PlanRisk] = []
    verification: PlanVerification = PlanVerification()
    out_of_scope: list[str] = []
    assumptions: list[str] = []
    open_questions: list[str] = []


class PlanValidation(_In):
    auto_risks: list[PlanRisk] = []
    cross_process: dict[str, list[str]] = {}


class PlanInput(_In):
    """Document `plan.json` du Stratège (PlanDocument). Seuls les champs utiles à l'exécution sont lus."""
    schema_version: str = "1.0"
    ticket_id: str
    status: str
    status_reason: str = ""
    ticket: dict = {}
    plan: PlanBody | None = None
    validation: PlanValidation = PlanValidation()


# ===================== sorties LLM =========================================================================
class Edit(BaseModel):
    op: Literal["replace", "insert_after", "insert_before", "delete"]
    anchor: str = Field(description="Existing code copied VERBATIM from the numbered view (without the 'NNN|' prefixes): "
                                    "the text to replace/delete, or the line(s) after/before which to insert. Keep it as small as "
                                    "possible but unique (usually 1-4 lines).")
    near_line: int = Field(default=0, description="Line number from the view where the anchor is; used only to disambiguate repeated anchors.")
    new_text: str = Field(description="Replacement/inserted code, indented exactly like the surrounding code. Empty for delete.")
    reason: str = Field(description="One sentence: which part of the plan this implements.")


class EditSet(BaseModel):
    summary: str = Field(description="What changed in this file, in one or two sentences.")
    edits: list[Edit] = Field(description="Minimal, ordered edits. Empty only if cannot_apply is set.")
    cannot_apply: str = Field(default="", description="Non-empty ONLY if the plan cannot be applied to this file as described "
                                                      "(explain precisely what is missing). Then edits must be empty.")


class NewFile(BaseModel):
    summary: str
    content: str = Field(description="Complete content of the new file.")


# ===================== rapport ==============================================================================
class Issue(BaseModel):
    severity: Literal["error", "warning", "info"]
    code: str
    message: str
    path: str = ""
    line: int = 0


class FileResult(BaseModel):
    path: str
    change_type: str
    status: Literal["applied", "failed", "skipped", "refused"] = "failed"
    attempts: int = 0
    summary: str = ""
    edits: list[dict] = Field(default_factory=list)
    added: int = 0
    removed: int = 0
    issues: list[Issue] = Field(default_factory=list)


class BuildResult(BaseModel):
    ran: bool = False
    ok: bool | None = None
    command: list[str] = Field(default_factory=list)
    rounds: int = 0
    errors: list[str] = Field(default_factory=list)
    output_tail: str = ""


class FixDiagnostic(BaseModel):
    """Diagnostic du Compilateur (sous-ensemble tolérant de son schéma `Diagnostic`)."""
    model_config = ConfigDict(extra="ignore")
    path: str
    line: int = 0
    column: int = 0
    category: str = ""
    message: str
    severity: str = "error"
    hints: list[str] = []
    suggest_files: list[str] = []
    snippet: str = ""
    notes: list[str] = []


class FixRequest(BaseModel):
    diagnostics: list[FixDiagnostic]
    round: int = 1


class TestFixRequest(BaseModel):
    """La QA a lancé les tests Squish sur la modification : ils échouent. `feedback` = le retour de la QA (ce que chaque test vérifie, ce qui a échoué et où,
    quelles parties de la modification y sont liées) ; il est donné tel quel au LLM."""
    __test__ = False
    feedback: str
    round: int = 1


class FixResult(BaseModel):
    ticket_id: str
    status: Literal["fixed", "no_change", "rejected", "failed"]
    reason: str = ""
    round: int = 1
    files: list[dict] = Field(default_factory=list)                 # {path, status, summary, attempts, issues}
    commits: dict[str, str] = Field(default_factory=dict)
    issues: list[Issue] = Field(default_factory=list)


class BuildHints(BaseModel):
    """Ce que le Compilateur et la QA ont besoin de savoir sans relire le diff (tous les champs sont additifs et facultatifs)."""
    changed_files: list[str] = Field(default_factory=list)          # chemins « monde » (comme le plan)
    new_files: list[str] = Field(default_factory=list)
    needs_reconfigure: bool = False                                 # fichier ajouté/supprimé ou CMakeLists modifié : sources par GLOB => relancer `cmake` (un simple build ne le voit pas)
    build_targets: list[str] = Field(default_factory=list)          # cibles CMake citées par le plan
    squish_tests: list[str] = Field(default_factory=list)           # tests ciblés cités par le plan (heuristique du Stratège, pas une garantie)
    manual_checks: list[str] = Field(default_factory=list)


class DevReport(BaseModel):
    schema_version: str = "1.0"
    ticket_id: str
    status: Literal["applied", "needs_review", "failed", "rejected"]
    status_reason: str = ""
    branches: dict[str, str] = Field(default_factory=dict)          # dépôt -> branche
    worktrees: dict[str, str] = Field(default_factory=dict)         # dépôt -> chemin absolu
    commits: dict[str, str] = Field(default_factory=dict)           # dépôt -> sha
    bases: dict[str, str] = Field(default_factory=dict)             # dépôt -> sha de départ (pour recalculer le diff total)
    files: list[FileResult] = Field(default_factory=list)
    build: BuildResult = Field(default_factory=BuildResult)
    diff: str = ""                                                  # diff unifié (appliqué, ou PROPOSÉ si non appliqué)
    diff_applied: bool = False
    warnings: list[Issue] = Field(default_factory=list)
    next_steps: list[str] = Field(default_factory=list)
    build_hints: BuildHints = Field(default_factory=BuildHints)
    commit_subject: str = ""                                        # sujet proposé au format [EAP-12605][General]Titre (la référence EAP peut être EAP-TODO)
    feedback_for_strategist: str = ""                               # faits à joindre à une nouvelle demande de plan quand le plan ne s'applique pas au code
    meta: dict = Field(default_factory=dict)
