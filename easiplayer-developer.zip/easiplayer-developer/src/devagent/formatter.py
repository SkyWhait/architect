"""Formatage des SEULES lignes modifiées avec le `.clang-format` du projet (Microsoft, Allman, 4 espaces, 120 colonnes, `=` alignés).

Le LLM garde la main sur le code ; clang-format ne touche que les lignes qu'il vient d'écrire (`--lines`), jamais le reste du fichier
(le code ancien n'est pas forcément formaté, et reformater un fichier de plusieurs milliers de lignes noierait la revue).

Si clang-format est absent, si aucun `.clang-format` n'est trouvé, ou s'il échoue : le texte est laissé tel quel (l'appelant en est informé).
Le résultat formaté est ensuite re-vérifié comme n'importe quelle autre modification (périmètre, syntaxe) par l'appelant.
"""
from __future__ import annotations

import difflib
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

from .config import Settings

CPP_EXT = {".h", ".hpp", ".hh", ".hxx", ".cpp", ".cc", ".cxx", ".c"}


@dataclass
class FormatResult:
    text: str
    status: str        # "formatted" | "unchanged" | "skipped_off" | "skipped_no_binary" | "skipped_no_config" | "skipped_not_cpp" | "failed"
    detail: str = ""


def changed_ranges(old: str, new: str) -> list[tuple[int, int]]:
    """Plages de lignes (1-based, inclusives) de `new` qui diffèrent de `old`."""
    out = []
    for t, _i1, _i2, j1, j2 in difflib.SequenceMatcher(None, old.split("\n"), new.split("\n"), autojunk=False).get_opcodes():
        if t in ("replace", "insert") and j2 > j1:
            out.append((j1 + 1, j2))
    return out


def find_style_file(start: Path, stop: Path) -> Path | None:
    """`.clang-format` le plus proche en remontant de `start` jusqu'à `stop` (racine du dépôt, incluse)."""
    stop = stop.resolve()
    cur = start.resolve()
    while True:
        cand = cur / ".clang-format"
        if cand.is_file():
            return cand
        if cur == stop or cur.parent == cur:
            return None
        cur = cur.parent


def binary(cfg: Settings) -> str | None:
    return shutil.which(cfg.clang_format_bin)


def format_changed_lines(cfg: Settings, file_path: Path, repo_root: Path, old: str, new: str) -> FormatResult:
    """Formate les lignes de `new` qui diffèrent de `old`. `file_path` = chemin du fichier DANS le worktree (pour retrouver le `.clang-format`)."""
    if cfg.format_mode == "off":
        return FormatResult(new, "skipped_off")
    if file_path.suffix.lower() not in CPP_EXT:
        return FormatResult(new, "skipped_not_cpp")
    exe = binary(cfg)
    if exe is None:
        return FormatResult(new, "skipped_no_binary", f"`{cfg.clang_format_bin}` introuvable dans le PATH")
    override = Path(cfg.clang_format_file) if cfg.clang_format_file else None
    if override is not None and not override.is_file():
        return FormatResult(new, "failed", f"DEV_CLANG_FORMAT_FILE introuvable : {override}")
    if override is None and find_style_file(file_path.parent, repo_root) is None:
        return FormatResult(new, "skipped_no_config", "aucun .clang-format dans le dépôt (et pas de DEV_CLANG_FORMAT_FILE)")
    ranges = changed_ranges(old, new)
    if not ranges:
        return FormatResult(new, "unchanged")
    style_arg = f"--style=file:{override}" if override else "--style=file"             # `file:<chemin>` exige clang-format >= 14 ; `file` marche partout
    cmd = [exe, style_arg, f"--assume-filename={file_path}", *[f"--lines={a}:{b}" for a, b in ranges]]
    try:
        r = subprocess.run(cmd, input=new.encode("utf-8", "surrogateescape"), capture_output=True, timeout=cfg.format_timeout_s)
    except (OSError, subprocess.TimeoutExpired) as e:
        return FormatResult(new, "failed", f"{type(e).__name__}: {e}")
    if r.returncode != 0:
        return FormatResult(new, "failed", r.stderr.decode("utf-8", "replace").strip()[:300])
    out = r.stdout.decode("utf-8", "surrogateescape")
    # garde-fou : l'appelant re-vérifie le texte formaté (périmètre, syntaxe) exactement comme la sortie brute du LLM
    return FormatResult(out, "formatted" if out != new else "unchanged")
