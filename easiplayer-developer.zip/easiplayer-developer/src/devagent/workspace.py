"""Isolation et sécurité du disque : worktrees git, chemins confinés, encodage/EOL préservés, écriture atomique.

Garanties :
 * l'arbre de travail et la branche de l'utilisateur ne sont JAMAIS modifiés (tout se passe dans un worktree dédié) ;
 * un chemin du plan ne peut pas sortir du dépôt (.., absolu, lien symbolique sortant, dossier .git) ;
 * aucun fichier secret n'est lisible/écrivible ; pas de push ; les hooks git sont désactivés pour les commits.
"""
from __future__ import annotations

import fnmatch
import os
import re
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from .config import Settings

SECRET_NAMES = {".env", ".netrc", ".npmrc", "id_rsa", "id_ed25519", "credentials", "credentials.json", "secrets.json"}
SECRET_EXT = {".pem", ".key", ".p12", ".pfx", ".jks", ".kdbx"}
GENERATED = re.compile(r"(^|/)(moc_|ui_|qrc_)[^/]*$")


class WorkspaceError(RuntimeError):
    pass


def git(repo: Path, *args: str, check: bool = True, hooks: bool = False) -> str:
    cmd = ["git", "-C", str(repo)]
    if not hooks:
        cmd += ["-c", "core.hooksPath=/dev/null"]
    r = subprocess.run(cmd + list(args), capture_output=True, env={**os.environ, "GIT_TERMINAL_PROMPT": "0"})
    if check and r.returncode != 0:                                  # sortie lue en octets : le code legacy (latin-1) ne doit pas faire planter git
        raise WorkspaceError(f"git {' '.join(args[:3])} a échoué : {r.stderr.decode('utf-8', 'replace').strip()[:400]}")
    return r.stdout.decode("utf-8", errors="replace")


def safe_name(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]", "_", s).strip("._")[:64] or "unknown"


@dataclass
class Target:
    repo: str            # nom du dépôt (premier composant du chemin du plan)
    rel: str             # chemin dans le dépôt (POSIX)
    plan_path: str       # chemin tel qu'écrit dans le plan


class Workspace:
    def __init__(self, cfg: Settings, ticket_id: str):
        self.cfg, self.ticket = cfg, safe_name(ticket_id)
        self.root = (cfg.work_dir / self.ticket).resolve()
        self.worktrees: dict[str, Path] = {}
        self.branches: dict[str, str] = {}
        self.bases: dict[str, str] = {}

    # ---------------------------------------------------------------- chemins
    def parse(self, plan_path: str) -> Target:
        p = PurePosixPath(plan_path.replace("\\", "/"))
        parts = p.parts
        if p.is_absolute() or ".." in parts or len(parts) < 2 or parts[0] in {".git", "."}:
            raise WorkspaceError(f"chemin du plan invalide ou hors dépôt : {plan_path!r}")
        if ".git" in parts:
            raise WorkspaceError(f"accès à .git interdit : {plan_path!r}")
        name = parts[-1]
        if name in SECRET_NAMES or name.startswith(".env.") or p.suffix.lower() in SECRET_EXT:
            raise WorkspaceError(f"fichier sensible interdit : {plan_path!r}")
        for comp in parts[:-1]:
            if any(fnmatch.fnmatch(comp, pat) for pat in self.cfg.forbidden_dirs):
                raise WorkspaceError(f"zone interdite à l'agent ({comp}/ : build_*, install, redist) : {plan_path!r}")
        if GENERATED.search(plan_path):
            raise WorkspaceError(f"fichier généré (moc_/ui_/qrc_) : modifier sa source, pas lui : {plan_path!r}")
        return Target(parts[0], "/".join(parts[1:]), plan_path)

    def read_at_base(self, plan_path: str) -> str | None:
        """Contenu d'un fichier du dépôt à `base_ref` (lecture seule, sans créer de worktree) ; None s'il n'existe pas."""
        t = self.parse(plan_path)
        src = (self.cfg.world_root / t.repo).resolve()
        if not src.is_dir():
            return None
        base = git(src, "rev-parse", "--verify", f"{self.cfg.base_ref}^{{commit}}", check=False).strip()
        if not base:
            return None
        r = subprocess.run(["git", "-C", str(src), "-c", "core.hooksPath=/dev/null", "show", f"{base}:{t.rel}"], capture_output=True,
                           env={**os.environ, "GIT_TERMINAL_PROMPT": "0"})
        return r.stdout.decode("utf-8", "replace") if r.returncode == 0 else None

    def ensure_worktree(self, repo: str) -> Path:
        if repo in self.worktrees:
            return self.worktrees[repo]
        src = (self.cfg.world_root / repo).resolve()
        if not src.is_dir():
            raise WorkspaceError(f"dépôt introuvable : {src}")
        top = git(src, "rev-parse", "--show-toplevel").strip()
        if Path(top).resolve() != src:
            raise WorkspaceError(f"{src} n'est pas la racine d'un dépôt git (racine détectée : {top})")
        base = git(src, "rev-parse", "--verify", f"{self.cfg.base_ref}^{{commit}}").strip()
        wt = self.root / "worktrees" / repo
        if wt.exists():
            raise WorkspaceError(f"worktree déjà présent : {wt} (lancer `devagent clean {self.ticket}`)")
        wt.parent.mkdir(parents=True, exist_ok=True)
        branch = f"{self.cfg.branch_prefix}{self.ticket}"
        if git(src, "branch", "--list", branch).strip():
            branch += f"-{time.strftime('%Y%m%d%H%M%S')}"
        git(src, "worktree", "add", "-q", "-b", branch, str(wt), base)
        self.worktrees[repo], self.branches[repo], self.bases[repo] = wt, branch, base
        return wt

    def abs_path(self, t: Target, must_exist: bool | None = None) -> Path:
        wt = self.ensure_worktree(t.repo)
        p = (wt / t.rel)
        real = p.resolve()
        try:
            real.relative_to(wt.resolve())
        except ValueError:
            raise WorkspaceError(f"le chemin sort du dépôt (lien symbolique ?) : {t.plan_path}")
        if must_exist is True and not real.is_file():
            raise WorkspaceError(f"fichier introuvable dans {t.repo}@{self.cfg.base_ref} : {t.rel}")
        if must_exist is False and real.exists():
            raise WorkspaceError(f"le fichier existe déjà : {t.plan_path}")
        return real

    # ---------------------------------------------------------------- lecture / écriture
    @staticmethod
    def read_raw(path: Path) -> str:
        return path.read_bytes().decode("utf-8", errors="surrogateescape")     # round-trip fidèle des fichiers latin-1

    @staticmethod
    def write_atomic(path: Path, text: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + ".devagent.tmp")
        tmp.write_bytes(text.encode("utf-8", errors="surrogateescape"))
        if path.exists():
            shutil.copymode(path, tmp)
        os.replace(tmp, path)

    # ---------------------------------------------------------------- git
    def stage(self, repo: str, rels: list[str]) -> None:
        if rels:
            git(self.worktrees[repo], "add", "--", *rels)

    def remove(self, t: Target) -> None:
        """Suppression d'un fichier suivi (le plan l'exige et l'humain l'a autorisé) : `git rm` dans le worktree."""
        git(self.worktrees[t.repo], "rm", "-q", "--", t.rel)

    def diff(self, prefix_repo: bool = True) -> str:
        out = []
        for repo, wt in self.worktrees.items():
            out.append(git(wt, "diff", "--cached", "--no-color", "--no-ext-diff", f"--src-prefix=a/{repo}/", f"--dst-prefix=b/{repo}/"))
        return "".join(out)

    def diff_from_base(self) -> str:
        out = []
        for repo, wt in self.worktrees.items():
            if repo in self.bases:
                out.append(git(wt, "diff", "--no-color", "--no-ext-diff", f"--src-prefix=a/{repo}/", f"--dst-prefix=b/{repo}/", self.bases[repo], "HEAD"))
        return "".join(out)

    def attach(self, worktrees: dict[str, str], branches: dict[str, str], bases: dict[str, str]) -> None:
        """Reprend des worktrees déjà créés par une exécution précédente (boucle de correction)."""
        for repo, p in worktrees.items():
            path = Path(p).resolve()
            try:
                path.relative_to(self.root.resolve())
            except ValueError:
                raise WorkspaceError(f"worktree hors de l'espace de travail de l'agent : {p}")
            if not path.is_dir():
                raise WorkspaceError(f"worktree introuvable : {p}")
            self.worktrees[repo] = path
        self.branches, self.bases = dict(branches), dict(bases)

    def commit(self, message: str) -> dict[str, str]:
        shas = {}
        for repo, wt in self.worktrees.items():
            if not git(wt, "diff", "--cached", "--name-only").strip():
                continue
            git(wt, "-c", f"user.name={self.cfg.git_user_name}", "-c", f"user.email={self.cfg.git_user_email}",
                "commit", "-q", "--no-verify", "-m", message)
            shas[repo] = git(wt, "rev-parse", "HEAD").strip()
        return shas

    def unexpected_changes(self, allowed: dict[str, set[str]]) -> list[str]:
        """Fichiers modifiés/créés dans les worktrees (par la compilation, p.ex.) qui ne font pas partie du plan."""
        bad = []
        for repo, wt in self.worktrees.items():
            for line in git(wt, "status", "--porcelain", "--untracked-files=all").splitlines():
                rel = line[3:].strip().strip('"')
                if rel and rel not in allowed.get(repo, set()):
                    bad.append(f"{repo}/{rel}")
        return bad

    def revert(self) -> None:
        for wt in self.worktrees.values():
            git(wt, "reset", "-q", "--hard", "HEAD")
            git(wt, "clean", "-fdq")

    def reset(self) -> None:
        """Repart de zéro pour ce ticket (nouvelle tentative demandée explicitement) : worktrees, branche `agent/<ticket>` et anciens rapports supprimés."""
        rp = self.root / "dev_report.json"
        if rp.exists():                                  # le précédent run a pu créer une branche suffixée (agent/<ticket>-AAAAMMJJ…) : on la retrouve dans son rapport
            try:
                import json
                self.branches.update(json.loads(rp.read_text()).get("branches", {}))
            except (OSError, ValueError):
                pass
        self.cleanup(drop_branch=True)
        if self.root.exists():
            for name in ("dev_report.json", "dev_report.md", "changes.diff", "proposed.diff", "plan.json"):
                (self.root / name).unlink(missing_ok=True)

    def cleanup(self, drop_branch: bool = False) -> None:
        for repo in list(self.worktrees) or [p.name for p in (self.root / "worktrees").glob("*")]:
            src = (self.cfg.world_root / repo).resolve()
            wt = self.root / "worktrees" / repo
            if wt.exists():
                git(src, "worktree", "remove", "--force", str(wt), check=False)
            if drop_branch:
                git(src, "branch", "-D", self.branches.get(repo, f"{self.cfg.branch_prefix}{self.ticket}"), check=False)
