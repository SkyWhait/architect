"""Moteur d'édition chirurgicale : ancrage exact (ou tolérant à l'indentation), unicité exigée, style du fichier préservé.

Le LLM ne réécrit JAMAIS un fichier : il désigne un extrait existant (`anchor`) et dit quoi en faire. Tout ce qui n'est pas
désigné reste octet pour octet identique (EOL, encodage, indentation, dernière ligne).
"""
from __future__ import annotations

import bisect
import difflib
import re
from dataclasses import dataclass

from .models import Edit, Issue


# ======================================================================= style du fichier
@dataclass
class Style:
    eol: str = "\n"
    use_tabs: bool = False
    width: int = 4


def split_raw(raw: str) -> tuple[str, Style]:
    crlf = raw.count("\r\n")
    eol = "\r\n" if crlf > raw.count("\n") - crlf else "\n"
    text = raw.replace("\r\n", "\n")
    tab_lines = space_lines = 0
    indents: list[int] = []
    for ln in text.split("\n"):
        if ln.startswith("\t"):
            tab_lines += 1
        elif ln.startswith("  "):
            space_lines += 1
            indents.append(len(ln) - len(ln.lstrip(" ")))
    width = 4
    if indents:
        width = max((4, 2, 8, 3), key=lambda w: (sum(1 for i in indents if i % w == 0), -(4, 2, 8, 3).index(w)))
    return text, Style(eol=eol, use_tabs=tab_lines > space_lines, width=width)


def join_raw(text: str, style: Style) -> str:
    return text.replace("\n", style.eol) if style.eol != "\n" else text


def to_style(snippet: str, style: Style) -> str:
    """Indentation du snippet convertie au style du fichier (tabs/espaces), espaces de fin supprimés."""
    out = []
    for ln in snippet.split("\n"):
        m = re.match(r"^([ \t]+)(\S.*)$", ln)
        if m:
            cols = sum(style.width if c == "\t" else 1 for c in m.group(1))
            lead = ("\t" * (cols // style.width) + " " * (cols % style.width)) if style.use_tabs else " " * cols
            ln = lead + m.group(2)
        out.append(ln.rstrip())
    return "\n".join(out)


# ======================================================================= utilitaires
def _rebase(new: str, indent: str) -> str:
    """Le LLM a omis l'indentation (1re ligne sans retrait) : toutes ses lignes sont relatives, on les recale sur `indent`."""
    lines = new.split("\n")
    first = next((ln for ln in lines if ln.strip()), "")
    if not indent or _lead(first) or first.lstrip().startswith("#"):
        return new
    return "\n".join((indent + ln) if ln.strip() else ln for ln in lines)


_NUM = re.compile(r"^\s*\d+\| ?")


def strip_numbering(s: str) -> str:
    """Si le LLM a recopié les préfixes 'NNN| ' de la vue numérotée, on les retire (toutes les lignes non vides doivent en avoir)."""
    lines = s.split("\n")
    body = [ln for ln in lines if ln.strip()]
    if body and all(_NUM.match(ln) for ln in body):
        return "\n".join(_NUM.sub("", ln) for ln in lines)
    return s


def _lead(ln: str) -> str:
    return ln[: len(ln) - len(ln.lstrip(" \t"))]


@dataclass
class Placed:
    start: int
    end: int
    text: str
    edit: Edit
    via: str


class _Text:
    def __init__(self, text: str):
        self.text = text
        self.starts = [0]
        for m in re.finditer("\n", text):
            self.starts.append(m.end())

    def line(self, pos: int) -> int:                  # 1-based
        return bisect.bisect_right(self.starts, pos)

    def line_start(self, pos: int) -> int:
        return self.starts[self.line(pos) - 1]

    def line_end(self, pos: int) -> int:              # offset du '\n' (ou fin de texte)
        i = self.text.find("\n", pos)
        return len(self.text) if i == -1 else i


def _find_all(text: str, needle: str) -> list[int]:
    out, i = [], text.find(needle)
    while i != -1:
        out.append(i)
        i = text.find(needle, i + 1)
    return out


def _tolerant(tx: _Text, anchor: str) -> list[tuple[int, int, str, str]]:
    """Recherche par lignes ignorant l'indentation/les espaces de fin -> [(start, end, indent_fichier, indent_llm)]."""
    a = [ln for ln in anchor.split("\n")]
    while a and not a[-1].strip():
        a.pop()
    if not a:
        return []
    lines = tx.text.split("\n")
    key = [x.strip() for x in a]
    res = []
    for i in range(len(lines) - len(a) + 1):
        if all(lines[i + k].strip() == key[k] for k in range(len(a))):
            start = tx.starts[i]
            end = tx.starts[i + len(a) - 1] + len(lines[i + len(a) - 1])
            res.append((start, end, _lead(lines[i]), _lead(a[0])))
    return res


def _hints(text: str, anchor: str) -> str:
    first = next((ln.strip() for ln in anchor.split("\n") if ln.strip()), "")
    lines = text.split("\n")
    cands = difflib.get_close_matches(first, [ln.strip() for ln in lines], n=3, cutoff=0.55)
    out = []
    for c in cands:
        out.append(f"{next(i for i, ln in enumerate(lines, 1) if ln.strip() == c)}: {c[:100]}")
    return "; ".join(out)


# ======================================================================= localisation d'une édition
def locate(tx: _Text, e: Edit, style: Style, path: str) -> Placed | Issue:
    anchor = strip_numbering(e.anchor).strip("\n")
    new = strip_numbering(e.new_text).strip("\n")
    if not anchor.strip():
        return Issue(severity="error", code="empty_anchor", message="Edit without anchor: copy an existing code excerpt.", path=path)
    if e.op in ("replace", "insert_after", "insert_before") and not new.strip():
        return Issue(severity="error", code="empty_new_text", message=f"{e.op} requires new_text.", path=path)

    text, via = tx.text, "exact"
    hits = [(i, i + len(anchor), "", "") for i in _find_all(text, anchor)]
    if not hits:
        hits, via = _tolerant(tx, anchor), "tolerant"
    if not hits:
        h = _hints(text, anchor)
        return Issue(severity="error", code="anchor_not_found", path=path,
                     message="Anchor not found (copy it verbatim from the view). Anchor starts with: "
                             f"{anchor.splitlines()[0][:100]!r}." + (f" Closest lines in the file -> {h}" if h else ""))
    if len(hits) > 1:
        lns = [tx.line(h[0]) for h in hits]
        if e.near_line:
            best = sorted(hits, key=lambda h: abs(tx.line(h[0]) - e.near_line))
            if abs(tx.line(best[0][0]) - e.near_line) + 1 < abs(tx.line(best[1][0]) - e.near_line):
                hits = [best[0]]
        if len(hits) > 1:
            return Issue(severity="error", code="anchor_ambiguous", path=path,
                         message=f"Anchor matches {len(lns)} places (lines {lns[:6]}). Include more surrounding lines or set near_line.")
    start, end, f_ind, l_ind = hits[0]
    if via == "tolerant" and f_ind != l_ind:                   # recale l'indentation du LLM sur celle du fichier
        new = "\n".join((f_ind + ln[len(l_ind):]) if ln.startswith(l_ind) and l_ind != f_ind else ln for ln in new.split("\n"))
    # ancrage « lignes entières » : l'extrait n'est précédé/suivi que d'espaces sur ses lignes
    ls, le = tx.line_start(start), tx.line_end(max(end - 1, start))
    prefix, suffix = text[ls:start], text[end:le]
    whole = not prefix.strip() and not suffix.strip()
    if whole:
        start, end = ls, le
    if e.op == "replace":
        if whole and via == "exact":
            new = _rebase(new, prefix)
        return Placed(start, end, to_style(new, style), e, via)
    if e.op == "delete":
        if whole:                                              # supprime aussi le saut de ligne
            end = min(end + 1, len(text)) if end < len(text) else end
            if end == len(text) and start > 0:
                start -= 1
        return Placed(start, end, "", e, via)
    # insertions : toujours par lignes entières
    ai = _lead(text[tx.line_start(start): tx.line_end(start)])
    body = _rebase(new, ai).split("\n")
    ins = to_style("\n".join(body), style) + "\n"
    if e.op == "insert_after":
        pos = tx.line_end(max(end - 1, start))
        pos = pos + 1 if pos < len(text) else pos
        if pos == len(text) and not text.endswith("\n"):
            ins = "\n" + ins.rstrip("\n")
        return Placed(pos, pos, ins, e, via)
    pos = tx.line_start(start)
    return Placed(pos, pos, ins, e, via)


def apply_edits(text: str, edits: list[Edit], style: Style, path: str) -> tuple[str | None, list[Issue], list[Placed]]:
    """Toutes les ancres sont localisées sur le texte ORIGINAL, puis appliquées de bas en haut : aucune édition ne décale les autres."""
    tx = _Text(text)
    placed: list[Placed] = []
    issues: list[Issue] = []
    for i, e in enumerate(edits, 1):
        r = locate(tx, e, style, path)
        if isinstance(r, Issue):
            r.message = f"[edit {i}] {r.message}"
            issues.append(r)
        else:
            placed.append(r)
    placed.sort(key=lambda p: (p.start, p.end))
    for a, b in zip(placed, placed[1:]):
        if b.start < a.end:
            issues.append(Issue(severity="error", code="overlapping_edits", path=path,
                                message=f"Two edits overlap around line {tx.line(b.start)}: merge them into a single edit."))
    if issues:
        return None, issues, placed
    out = text
    for p in sorted(placed, key=lambda p: p.start, reverse=True):
        out = out[: p.start] + p.text + out[p.end:]
    return out, [], placed
