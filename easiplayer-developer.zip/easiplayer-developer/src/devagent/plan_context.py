"""Le rapport du Stratège, résumé pour les prompts de correction du build."""
from __future__ import annotations

from .models import PlanInput


def plan_context(plan: PlanInput | None, path: str, limit: int = 2200) -> str:
    """Ce que le Stratège a décidé, pour que la correction du build respecte l'intention du plan : problème, cause racine, ce qui est prévu pour CE fichier,
    ce qui est prévu ailleurs (une ligne par fichier) et les risques. Tronqué : le contexte du LLM est limité."""
    if plan is None:
        return "(plan not available)"
    b = plan.plan
    mine = next((f for f in b.files_to_modify if f.path == path), None)
    out = [f"Ticket {plan.ticket_id}: {plan.ticket.get('title', '')}", f"Root cause: {b.root_cause}"]
    if mine is not None:
        out += [f"This file ({path}): symbols {', '.join(mine.symbols) or '-'}", f"  why: {mine.rationale}", f"  planned change: {mine.logic_change}"]
    out += [f"Elsewhere: {f.path} — {f.logic_change[:140]}" for f in b.files_to_modify if f.path != path][:6]
    out += [f"Risk: {r.description[:140]}" for r in b.risks[:3]]
    return "\n".join(out)[:limit]
