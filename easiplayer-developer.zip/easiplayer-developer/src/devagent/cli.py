from __future__ import annotations

import argparse
import asyncio
import json
import logging
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser(prog="devagent")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a_ = sub.add_parser("apply", help="appliquer un plan du Stratège (plan.json)")
    a_.add_argument("--plan", type=Path, required=True)
    a_.add_argument("--world", type=Path, help="dossier contenant les dépôts git (défaut : DEV_WORLD_ROOT)")
    a_.add_argument("--approve", action="store_true", help="accepter un plan 'needs_review' après relecture humaine")
    a_.add_argument("--allow-remove", action="store_true")
    a_.add_argument("--no-commit", action="store_true")
    a_.add_argument("--eap-ref", help="référence du ticket de développement pour le commit (ex. EAP-12610) ; sinon le marqueur EAP-TODO est utilisé")
    a_.add_argument("--restart", action="store_true", help="repartir de zéro pour ce ticket (supprime ancien worktree, branche et rapports)")
    s = sub.add_parser("serve"); s.add_argument("--host", default="0.0.0.0"); s.add_argument("--port", type=int, default=8820)
    c = sub.add_parser("clean", help="supprimer les worktrees d'un ticket"); c.add_argument("ticket"); c.add_argument("--drop-branch", action="store_true")
    d = sub.add_parser("doctor", help="contrôle de pré-vol (dépôts, clang-format, LLM json_schema, Architecte) sans rien modifier")
    d.add_argument("--no-llm", action="store_true")
    sub.add_parser("schema", help="JSON Schema du rapport (contrat pour les agents suivants)")
    a = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")

    if a.cmd == "schema":
        from .models import DevReport
        print(json.dumps(DevReport.model_json_schema(), indent=2)); return
    if a.cmd == "serve":
        import uvicorn
        uvicorn.run("devagent.api:create_app", factory=True, host=a.host, port=a.port); return
    from .config import get_settings
    cfg = get_settings()
    if a.cmd == "doctor":
        from .doctor import main_doctor
        raise SystemExit(main_doctor(cfg, not a.no_llm))
    if a.cmd == "clean":
        from .workspace import Workspace
        Workspace(cfg, a.ticket).cleanup(drop_branch=a.drop_branch); print("nettoyé"); return
    from .agent import DevAgent
    from .llm import LLM
    from .models import PlanInput
    if a.world:
        cfg.world_root = a.world
    cfg.approve_review, cfg.allow_remove = a.approve, a.allow_remove
    cfg.commit = cfg.commit and not a.no_commit
    plan = PlanInput.model_validate_json(a.plan.read_text())
    from .architect import make_architect

    async def go():
        arch = make_architect(cfg)
        try:
            return await DevAgent(cfg, LLM(cfg), arch).apply(plan, eap_ref=a.eap_ref, restart=a.restart)
        finally:
            if arch is not None:
                await arch.aclose()
    rep = asyncio.run(go())
    print(f"[{rep.status}] {rep.status_reason}\n-> {cfg.work_dir / rep.ticket_id / 'dev_report.md'}")


if __name__ == "__main__":
    main()
