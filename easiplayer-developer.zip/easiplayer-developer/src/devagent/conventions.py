"""Conventions réelles d'EasiPlayer, vérifiées sur les SEULES lignes ajoutées (le code ancien n'est jamais jugé) :

  * C++11 strict (``CMAKE_CXX_STANDARD 11``, extensions OFF) : rien de C++14/17 ;
  * compatibilité Qt 5.9 *et* 5.15 (cibles Debian) : pas d'API Qt introduite après ``qt_min_version`` ;
  * ``connect()`` à l'ancienne (``SIGNAL()/SLOT()``), jamais la syntaxe par pointeurs de membres ni les lambdas ;
  * ``NULL`` / ``nullptr`` : on suit l'usage du fichier ; accolades Allman ; 120 colonnes.

Les contrôles « dur » (C++ trop récent, API Qt trop récente, connect moderne) sont des ERREURS renvoyées au LLM ; les contrôles de
goût (NULL, accolades, longueur de ligne) sont des AVERTISSEMENTS (``clang-format`` les corrige déjà quand il est disponible).

La table des API Qt est écrite d'après la documentation Qt (« Since Qt x.y ») : elle n'a PAS été confrontée à des en-têtes Qt 5.9 ici.
"""
from __future__ import annotations

import difflib
import functools
import re

from .models import Issue

# ======================================================================= utilitaires
_BLANKER = re.compile(r"//[^\n]*|/\*.*?\*/|\"(?:\\.|[^\"\\\n])*\"|'(?:\\.|[^'\\\n])*'", re.S)


def blank_code(text: str) -> str:
    """Efface commentaires et littéraux en conservant longueur ET numéros de ligne (les regex ne lisent plus que du code)."""
    return _BLANKER.sub(lambda m: re.sub(r"[^\n]", " ", m.group(0)), text)


@functools.lru_cache(maxsize=16)
def _added(old: str, new: str) -> tuple[tuple[int, str, str], ...]:
    raw, blank = new.split("\n"), blank_code(new).split("\n")
    out: list[tuple[int, str, str]] = []
    for t, _i1, _i2, j1, j2 in difflib.SequenceMatcher(None, old.split("\n"), raw, autojunk=False).get_opcodes():
        if t in ("replace", "insert"):
            out += [(n + 1, raw[n], blank[n]) for n in range(j1, j2)]
    return tuple(out)


def added_lines(old: str, new: str) -> list[tuple[int, str, str]]:
    """[(n° de ligne dans `new`, ligne brute, ligne sans commentaires/littéraux)] des lignes ajoutées ou remplacées."""
    return list(_added(old, new))


def _issue(sev: str, code: str, path: str, line: int, msg: str) -> Issue:
    return Issue(severity=sev, code=code, path=path, line=line, message=msg)  # type: ignore[arg-type]


# ======================================================================= C++11 strict
_TRAITS_T = "decay_t|enable_if_t|conditional_t|remove_reference_t|remove_const_t|remove_cv_t|add_const_t|result_of_t|underlying_type_t|common_type_t|make_unsigned_t|make_signed_t|remove_pointer_t"
_CXX11: list[tuple[re.Pattern, str]] = [
    (re.compile(r"\bstd::make_unique\b"), "std::make_unique is C++14: use `std::unique_ptr<T>(new T(...))` or a Qt smart pointer"),
    (re.compile(r"\[[^\]\[]*\]\s*\([^)]*\bauto\b[^)]*\)"), "generic lambda (`auto` parameter) is C++14: spell the parameter type"),
    (re.compile(r"\[[^\]\[]*\b\w+\s*=[^=\]][^\]]*\]\s*\("), "lambda init-capture is C++14: declare the variable before the lambda and capture it"),
    (re.compile(r"\bif\s+constexpr\b"), "`if constexpr` is C++17"),
    (re.compile(r"\bauto\s*(?:const\s*)?&{0,2}\s*\[\s*\w+\s*(?:,\s*\w+\s*)+\]"), "structured bindings are C++17"),
    (re.compile(r"\bdecltype\s*\(\s*auto\s*\)"), "`decltype(auto)` is C++14"),
    (re.compile(r"^\s*(?:(?:static|inline|virtual|friend)\s+)*auto\s+[\w:~]+\s*\([^;{}]*\)\s*(?:const\s*)?(?:noexcept\s*)?(?:\{|$)(?!.*->)"),
     "function return-type deduction (`auto f()` without `-> T`) is C++14"),
    (re.compile(rf"\bstd::(?:optional|variant|any|string_view|byte|shared_mutex|shared_timed_mutex|scoped_lock|invoke|apply|clamp|gcd|lcm|exchange|"
                rf"make_reverse_iterator|in_place|nullopt|visit|as_const|{_TRAITS_T})\b"), "this std:: facility is C++14/17"),
    (re.compile(r"\bstd::(?:size|data|empty)\s*\("), "std::size/data/empty (free functions) are C++17"),
    (re.compile(r"\bstd::\w+_v\b"), "`std::..._v` variable templates are C++17"),
    (re.compile(r"\bstd::filesystem\b|#\s*include\s*<(?:optional|variant|any|string_view|filesystem|shared_mutex)>"), "this header is C++17"),
    (re.compile(r"\[\[\s*(?:nodiscard|maybe_unused|fallthrough|deprecated)\s*\]\]"), "this attribute is C++14/17 (`[[noreturn]]` is the only one allowed)"),
    (re.compile(r"\b0[bB][01]+\b"), "binary literals are C++14"),
    (re.compile(r"(?<![\w'])\d{1,3}(?:'\d{3})+\b"), "digit separators are C++14"),
    (re.compile(r"\binline\s+(?:constexpr|static\s+constexpr)\s+\w+[^(;]*=[^;]*;|\bconstexpr\s+auto\b[^;(]*\{"), "inline variables / relaxed constexpr are C++17"),
]


def cxx11_check(path: str, old: str, new: str) -> list[Issue]:
    out: list[Issue] = []
    seen: set[str] = set()
    for n, _raw, code in added_lines(old, new):
        for rx, msg in _CXX11:
            if rx.search(code):
                if msg not in seen:
                    seen.add(msg)
                    out.append(_issue("error", "cxx11_violation", path, n, f"C++11 only (CMAKE_CXX_STANDARD 11, extensions OFF): {msg}."))
    return out


# ======================================================================= API Qt plus récentes que la cible
# (motif, version d'introduction, remplacement conseillé) — d'après la doc Qt « Since Qt x.y »
_QT_NEWER: list[tuple[re.Pattern, str, str]] = [
    (re.compile(r"\bQt::endl\b"), "5.14", "use `endl` (global, Qt 5.9-compatible) or '\\n'"),
    (re.compile(r"\bQt::(?:SkipEmptyParts|KeepEmptyParts)\b"), "5.14", "use QString::SkipEmptyParts / QString::KeepEmptyParts"),
    (re.compile(r"\bQThread::create\b"), "5.10", "subclass QThread or use QtConcurrent::run"),
    (re.compile(r"\bQRandomGenerator\b"), "5.10", "use qrand()/qsrand()"),
    (re.compile(r"\bQStringView\b"), "5.10", "use `const QString &`"),
    (re.compile(r"\bqsizetype\b"), "5.10", "use int / qint64"),
    (re.compile(r"\bq[Ss]copeGuard\b|\bQScopeGuard\b"), "5.12", "use a small RAII class"),
    (re.compile(r"\bcallOnTimeout\b"), "5.12", "use connect(timer, SIGNAL(timeout()), ...)"),
    (re.compile(r"\bQCbor\w+"), "5.12", "not available before 5.12"),
    (re.compile(r"\bswapItemsAt\b"), "5.13", "use swap(i, j)"),
    (re.compile(r"\b(?:startOfDay|endOfDay)\b"), "5.14", "build the QDateTime explicitly"),
    (re.compile(r"\bQProcess::startCommand\b|\bstartCommand\s*\("), "5.15", "use QProcess::start(program, arguments)"),
]


def _vt(v: str) -> tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", v)[:3])


def qt_version_check(path: str, old: str, new: str, qt_min: str) -> list[Issue]:
    out: list[Issue] = []
    seen: set[str] = set()
    for n, _raw, code in added_lines(old, new):
        for rx, since, hint in _QT_NEWER:
            m = rx.search(code)
            if m and _vt(since) > _vt(qt_min) and m.group(0) not in seen:
                seen.add(m.group(0))
                out.append(_issue("error", "qt_api_too_new", path, n,
                                  f"`{m.group(0)}` exists only since Qt {since}; the project must build with Qt {qt_min}: {hint}."))
    return out


# ======================================================================= connect() à l'ancienne
_CONNECT = re.compile(r"\b(?:QObject::)?connect\s*\(")
_PTR_MEMBER = re.compile(r"&\s*[A-Za-z_]\w*(?:::\w+)+")
_LAMBDA = re.compile(r"\[[^\]\[]*\]\s*(?:\([^)]*\)\s*)?(?:mutable\s*)?(?:->\s*[\w:<>*& ]+)?\s*\{")


def connect_style_check(path: str, old: str, new: str) -> list[Issue]:
    blank = blank_code(new).split("\n")
    out: list[Issue] = []
    for n, _raw, code in added_lines(old, new):
        if not _CONNECT.search(code):
            continue
        stmt, i = code, n
        while ";" not in stmt and i < len(blank) and i - n < 6:           # instruction sur plusieurs lignes
            stmt += " " + blank[i]
            i += 1
        stmt = stmt.split(";")[0]
        if "SIGNAL(" in stmt and "SLOT(" in stmt:
            continue
        if _PTR_MEMBER.search(stmt) or _LAMBDA.search(stmt) or "SIGNAL(" not in stmt:
            out.append(_issue("error", "connect_modern_syntax", path, n,
                              "This project uses string-based connections only: write `connect(sender, SIGNAL(sig(args)), receiver, SLOT(slot(args)));` "
                              "(no pointer-to-member syntax, no lambda)."))
    return out


# ======================================================================= goût : NULL, accolades, colonnes
def null_style_check(path: str, old: str, new: str) -> list[Issue]:
    base = blank_code(old)
    n_null, n_nullptr = len(re.findall(r"\bNULL\b", base)), len(re.findall(r"\bnullptr\b", base))
    out: list[Issue] = []
    for n, _raw, code in added_lines(old, new):
        if n_null >= 3 and n_nullptr == 0 and re.search(r"\bnullptr\b", code):
            out.append(_issue("warning", "nullptr_vs_NULL", path, n, "This file uses NULL (never nullptr): follow the file's habit."))
            break
        if n_nullptr >= 3 and n_null == 0 and re.search(r"\bNULL\b", code):
            out.append(_issue("warning", "NULL_vs_nullptr", path, n, "This file uses nullptr (never NULL): follow the file's habit."))
            break
    return out


_BRACE_SAME_LINE = re.compile(r"\S.*(?:\)|\belse|\btry|\bdo|\bconst|\bclass\s+\w+|\bstruct\s+\w+|\bnamespace\s+\w+)\s*\{\s*$")
_BRACE_OK = re.compile(r"\[[^\]\[]*\]\s*(?:\([^)]*\)\s*)?(?:->\s*[\w:<>*& ]+)?\s*\{\s*$|=\s*\{\s*$|\(\s*\{\s*$|,\s*\{\s*$|\{\s*\}")


def brace_style_check(path: str, old: str, new: str) -> list[Issue]:
    for n, _raw, code in added_lines(old, new):
        if code.rstrip().endswith("{") and _BRACE_SAME_LINE.search(code) and not _BRACE_OK.search(code):
            return [_issue("warning", "brace_not_allman", path, n, "Allman style expected: opening brace on its own line.")]
    return []


def line_length_check(path: str, old: str, new: str, limit: int = 120) -> list[Issue]:
    for n, raw, _code in added_lines(old, new):
        if len(raw.expandtabs(4)) > limit:
            return [_issue("warning", "line_too_long", path, n, f"Line longer than {limit} columns (.clang-format ColumnLimit).")]
    return []


def conventions_check(path: str, old: str, new: str, qt_min: str = "5.9", column_limit: int = 120) -> list[Issue]:
    return (cxx11_check(path, old, new) + qt_version_check(path, old, new, qt_min) + connect_style_check(path, old, new)
            + null_style_check(path, old, new) + brace_style_check(path, old, new) + line_length_check(path, old, new, column_limit))


# ======================================================================= message de commit : [EAP-12605][General]Titre
KNOWN_CATEGORIES = ("General", "Sequencer", "Avatar import", "NH90", "NH90_AAP")
_EAP_REF = re.compile(r"^EAP-\d{1,8}$")
EAP_PLACEHOLDER = "EAP-TODO"


def normalize_category(raw: str, default: str = "General") -> tuple[str, bool]:
    """(catégorie du commit, True si repli sur la valeur par défaut). Seules les catégories réellement utilisées dans l'historique sont acceptées."""
    key = re.sub(r"\s+", " ", (raw or "").strip()).lower()
    for c in KNOWN_CATEGORIES:
        if c.lower() == key:
            return c, False
    return default, True


def clean_title(title: str, limit: int = 100) -> str:
    t = re.sub(r"^(?:\s*\[[^\]]*\])+\s*", "", title or "").strip()               # « [EAP 6.1.0] » en tête : étiquette de version, pas du titre
    t = re.sub(r"\s+", " ", t)
    return (t[: limit - 1].rstrip() + "…") if len(t) > limit else t


def commit_prefix(eap_ref: str | None, category: str) -> tuple[str, bool]:
    """`[EAP-12610][Sequencer]` — (préfixe, True si la référence EAP est un marqueur à remplacer). Sans référence fournie, on n'en invente PAS."""
    ref = (eap_ref or "").strip().upper()
    ok = bool(_EAP_REF.match(ref))
    return f"[{ref if ok else EAP_PLACEHOLDER}][{category}]", not ok
