"""Agent Développeur (LangGraph) : applique un plan approuvé, fichier par fichier, dans un worktree git isolé.

    prepare ─► edit ⟲ (un fichier à la fois ; chaque essai est vérifié, le retour est renvoyé au LLM)
                 └─► apply ─► [build ⟲ fix] ─► finalize (diff, commit sur la branche de l'agent, rapport)

Transactionnel : RIEN n'est écrit sur disque tant que tous les fichiers du plan ne sont pas acceptés. Un seul échec
(ancre introuvable, hors périmètre, syntaxe, plan inapplicable...) => aucun fichier modifié, diff PROPOSÉ à relire.
Le LLM n'a ni shell ni accès disque : il émet des éditions typées, appliquées et contrôlées par le code.
"""
from __future__ import annotations

import difflib
import hashlib
import json
import logging
import os
import time
from pathlib import Path
from typing import TypedDict

from langgraph.graph import END, START, StateGraph

from . import __version__
from . import prompts as P
from .architect import ArchitectLike, build_facts
from .build import run_build
from .config import Settings
from .conventions import clean_title, commit_prefix, conventions_check, normalize_category
from .cpp_checks import (allowed_regions, deletion_guard, diff_stats, language_of, public_api_check, scope_check, soft_checks,
                         syntax_check)
from .editing import Style, apply_edits, join_raw, split_raw, to_style
from .formatter import format_changed_lines
from .llm import LLM, count_tokens
from .plan_context import plan_context
from .models import BuildHints, BuildResult, DevReport, EditSet, FileResult, Issue, NewFile, PlanFile, PlanInput
from .view import build_view, numbered
from .workspace import Target, Workspace, WorkspaceError

log = logging.getLogger("devagent")
_RANK = {".h": 0, ".hpp": 0, ".hh": 0, ".hxx": 0, ".cpp": 1, ".cc": 1, ".cxx": 1, ".c": 1}


class State(TypedDict, total=False):
    idx: int
    stop: bool
    build_ok: bool


def udiff(old: str, new: str, path: str, n: int = 3) -> str:
    return "\n".join(difflib.unified_diff(old.split("\n"), new.split("\n"), f"a/{path}", f"b/{path}", lineterm="", n=n))


class Run:
    def __init__(self, cfg: Settings, llm: LLM, plan: PlanInput, arch: ArchitectLike | None = None, eap_ref: str | None = None):
        self.cfg, self.llm, self.plan, self.arch, self.eap_ref = cfg, llm, plan, arch, eap_ref
        self.commit_subject, self.commit_prefix = "", ""
        self.facts_used: list[str] = []
        self.format_stats: dict[str, int] = {}
        self.removals: list[str] = []
        self.ws = Workspace(cfg, plan.ticket_id)
        self.files: list[PlanFile] = []
        self.targets: dict[str, Target] = {}
        self.orig: dict[str, tuple[str, Style]] = {}
        self.pending: dict[str, str] = {}
        self.styles: dict[str, Style] = {}
        self.results: dict[str, FileResult] = {}
        self.applied: list[str] = []
        self.warnings: list[Issue] = []
        self.build = BuildResult()
        self.reject: str | None = None
        self.status, self.reason = "applied", ""
        self.diff, self.diff_applied = "", False
        self.commits: dict[str, str] = {}
        self.written = False
        self._build_errors: list[dict] = []
        self.t0 = time.time()
        body = plan.plan
        self.strict_api = bool(plan.validation.cross_process) or any(r.area in {"dbus", "script_api"} for r in plan.validation.auto_risks)
        self.body = body

    # ------------------------------------------------------------------ contexte pour les prompts
    def _steps_for(self, path: str) -> str:
        st = [s for s in self.body.steps if path in s.files] or self.body.steps
        return "\n".join(f"{s.order}. {s.title}: {s.description}" for s in sorted(st, key=lambda s: s.order)[:6]) or "-"

    def _risks(self) -> str:
        rs = [*self.body.risks, *self.plan.validation.auto_risks]
        return "\n".join(f"- [{r.area}/{r.severity}] {r.description} -> {r.mitigation}" for r in rs[:8]) or "-"

    def _applied(self) -> str:
        txt = "\n".join(self.applied)
        return txt[:6000] if txt else "(none yet)"

    def _sibling(self, pf: PlanFile) -> str | None:
        stem = Path(pf.path).with_suffix("")
        for ext in (".h", ".hpp", ".hh") if Path(pf.path).suffix in {".cpp", ".cc", ".cxx", ".c"} else (".cpp", ".cc", ".cxx"):
            cand = str(stem) + ext
            if cand in self.pending:
                return self.pending[cand]
            if cand in self.orig:
                return self.orig[cand][0]
            try:
                t = self.ws.parse(cand)
                p = self.ws.abs_path(t)
                if p.is_file():
                    return split_raw(self.ws.read_raw(p))[0]
            except WorkspaceError:
                continue
        return None

    async def _facts(self, pf: PlanFile, text: str) -> str:
        if self.arch is None:
            return "(none)"
        try:
            f = await build_facts(self.cfg, self.ws, self.arch, pf, text, [s.description for s in self.body.steps if pf.path in s.files])
        except Exception as e:                                           # noqa: BLE001 — le contexte est un plus : jamais bloquant
            log.warning("faits d'API indisponibles pour %s : %s", pf.path, e)
            self.warn(Issue(severity="warning", code="architect_error", path=pf.path, message=f"API facts skipped: {type(e).__name__}: {str(e)[:160]}"))
            return "(none)"
        for i in f.issues:
            self.warn(i)
        self.facts_used += [u for u in f.used if u not in self.facts_used]
        return f.text

    # ------------------------------------------------------------------ vérification d'un fichier modifié
    def verify(self, pf: PlanFile, old: str, new: str, regions: list[tuple[int, int]]) -> list[Issue]:
        issues = scope_check(pf.path, old, new, regions)
        issues += deletion_guard(self.cfg, pf.path, old, new)
        issues += syntax_check(pf.path, old, new)
        issues += public_api_check(pf.path, old, new, self.strict_api)
        issues += soft_checks(pf.path, old, new, self._sibling(pf))
        if language_of(pf.path) == "cpp":
            issues += conventions_check(pf.path, old, new, self.cfg.qt_min_version, self.cfg.column_limit)
        return issues

    def set_commit_subject(self) -> None:
        """`[EAP-12605][General]Titre` — la référence EAP n'est PAS déductible du ticket Mantis : fournie par l'appelant, sinon marqueur `EAP-TODO`."""
        cat, fell_back = normalize_category(str(self.plan.ticket.get("category", "")), self.cfg.commit_default_category)
        prefix, todo = commit_prefix(self.eap_ref, cat)
        title = clean_title(str(self.plan.ticket.get("title", ""))) or f"Fix for {self.plan.ticket_id}"
        self.commit_prefix = prefix
        self.commit_subject = f"{prefix}{self.cfg.commit_separator}{title}"
        if todo:
            self.warn(Issue(severity="warning", code="commit_ref_missing", message=f"No EAP reference was given: the commit subject starts with {prefix}. "
                                                                                    "Reword it before merging (git commit --amend)."))
        if fell_back:
            self.warn(Issue(severity="info", code="commit_category_fallback", message=f"Mantis category {self.plan.ticket.get('category', '')!r} is not one of the "
                                                                                       f"commit categories in use; {cat!r} was used."))

    def warn(self, issue: Issue) -> None:
        if not any(w.code == issue.code and w.message == issue.message for w in self.warnings):
            self.warnings.append(issue)

    def format_then_verify(self, pf: PlanFile, old: str, new: str, regions: list[tuple[int, int]]) -> tuple[str, list[Issue]]:
        """clang-format sur les seules lignes modifiées, puis MÊMES vérifications que pour la sortie brute du LLM. Si le texte formaté
        ne passe plus (périmètre, syntaxe...), on garde la sortie brute (et on le dit) : le formatage ne peut jamais faire échouer une édition."""
        t = self.targets[pf.path]
        fr = format_changed_lines(self.cfg, self.ws.abs_path(t), self.ws.worktrees[t.repo], old, new)
        self.format_stats[fr.status] = self.format_stats.get(fr.status, 0) + 1
        extra: list[Issue] = []
        if fr.status == "formatted":
            vf = self.verify(pf, old, fr.text, regions)
            if not any(i.severity == "error" for i in vf):
                return fr.text, vf
            extra.append(Issue(severity="warning", code="format_skipped", path=pf.path,
                               message="clang-format output failed verification (" + ", ".join(sorted({i.code for i in vf if i.severity == 'error'})) + "): raw edit kept."))
        elif fr.status in {"skipped_no_binary", "skipped_no_config", "failed"}:
            extra.append(Issue(severity="warning", code="format_" + fr.status, path=pf.path, message=f"clang-format not applied: {fr.detail}"))
        return new, self.verify(pf, old, new, regions) + extra

    @staticmethod
    def _fmt(issues: list[Issue]) -> str:
        return "\n".join(f"- [{i.code}] {i.message}" + (f" (line {i.line})" if i.line else "") for i in issues if i.severity == "error")

    # ------------------------------------------------------------------ un fichier existant
    async def edit_one(self, pf: PlanFile) -> FileResult:
        res = FileResult(path=pf.path, change_type=pf.change_type)
        if pf.change_type == "add":
            return await self.new_file(pf, res)
        if pf.change_type == "remove":                                   # aucune édition LLM : le plan (approuvé, --allow-remove) supprime le fichier entier
            res.status, res.summary, res.attempts = "applied", "File removed as planned (git rm).", 0
            self.removals.append(pf.path)
            return res
        text, style = self.orig[pf.path]
        regions = allowed_regions(text, pf, self.cfg.scope_slack_lines)
        view = build_view(text, regions, self.cfg.view_budget_tokens, count_tokens)
        facts_text = await self._facts(pf, text)
        feedback = ""
        for attempt in range(1, self.cfg.max_edit_attempts + 1):
            res.attempts = attempt
            user = P.EDIT.format(ticket_id=self.plan.ticket_id, title=self.plan.ticket.get("title", ""), root_cause=self.body.root_cause,
                                 path=pf.path, change_type=pf.change_type, symbols=", ".join(pf.symbols) or "-", line_hint=pf.line_hint or "-",
                                 rationale=pf.rationale, logic=pf.logic_change, steps=self._steps_for(pf.path), risks=self._risks(),
                                 out_of_scope="\n".join(f"- {x}" for x in self.body.out_of_scope) or "-", applied=self._applied(),
                                 facts=facts_text, view=view, feedback=feedback)
            es = await self.llm.json(P.SYSTEM, user, EditSet)
            res.summary = es.summary
            if es.cannot_apply.strip():
                res.status = "skipped"
                res.issues = [Issue(severity="error", code="cannot_apply", path=pf.path, message=es.cannot_apply.strip())]
                return res
            issues: list[Issue] = []
            new: str | None = None
            if not es.edits:
                issues.append(Issue(severity="error", code="no_edits", path=pf.path, message="No edits and no cannot_apply: implement the plan or explain why you cannot."))
            else:
                new, iss, placed = apply_edits(text, es.edits, style, pf.path)
                issues += iss
                if new is not None:
                    new, vissues = self.format_then_verify(pf, text, new, regions)
                    issues += vissues
            if not any(i.severity == "error" for i in issues):
                st = diff_stats(text, new)
                res.status, res.added, res.removed = "applied", st.added, st.removed
                res.edits = [{"op": p.edit.op, "reason": p.edit.reason, "match": p.via} for p in placed]
                res.issues = [i for i in issues if i.severity != "error"]
                self.pending[pf.path] = new
                self.styles[pf.path] = style
                self.applied.append("\n".join(udiff(text, new, pf.path, 2).split("\n")[:120]))
                return res
            res.issues = issues
            res.edits = [{"op": e.op, "anchor": e.anchor[:300], "new_text": e.new_text[:600], "reason": e.reason, "rejected": True} for e in es.edits]
            feedback = P.FEEDBACK.format(issues=self._fmt(issues), previous=json.dumps([e.model_dump() for e in es.edits], ensure_ascii=False)[:3500])
            log.info("%s essai %d rejeté : %s", pf.path, attempt, [i.code for i in issues if i.severity == "error"])
        res.status = "failed"
        return res

    # ------------------------------------------------------------------ nouveau fichier
    async def new_file(self, pf: PlanFile, res: FileResult) -> FileResult:
        d = Path(pf.path).parent.as_posix()
        sib, style = "(none)", Style()
        try:
            t = self.ws.parse(pf.path)
            folder = self.ws.abs_path(t).parent
            cand = sorted(p for p in folder.glob(f"*{Path(pf.path).suffix}") if p.is_file())[:1]
            if cand:
                raw = self.ws.read_raw(cand[0])
                sib_text, style = split_raw(raw)
                sib = numbered(sib_text.split("\n")[:80], 1, min(80, sib_text.count("\n") + 1))
        except WorkspaceError:
            pass
        feedback = ""
        for attempt in range(1, self.cfg.max_edit_attempts + 1):
            res.attempts = attempt
            user = P.NEWFILE.format(path=pf.path, ticket_id=self.plan.ticket_id, title=self.plan.ticket.get("title", ""),
                                    root_cause=self.body.root_cause, rationale=pf.rationale, logic=pf.logic_change,
                                    steps=self._steps_for(pf.path), risks=self._risks(), sibling=sib, applied=self._applied(), feedback=feedback)
            nf = await self.llm.json(P.SYSTEM, user, NewFile)
            content = to_style(nf.content.replace("\r\n", "\n"), style).rstrip("\n") + "\n"
            issues = []
            if language_of(pf.path) == "cpp":
                t = self.targets[pf.path]
                fr = format_changed_lines(self.cfg, self.ws.abs_path(t), self.ws.worktrees[t.repo], "", content)
                self.format_stats[fr.status] = self.format_stats.get(fr.status, 0) + 1
                if fr.status == "formatted" and not any(i.severity == "error" for i in syntax_check(pf.path, "", fr.text)):
                    content = fr.text
                issues += conventions_check(pf.path, "", content, self.cfg.qt_min_version, self.cfg.column_limit)
            if any(i.severity == "error" for i in syntax_check(pf.path, "", content)):
                issues.append(Issue(severity="error", code="syntax_error", path=pf.path, message="The new file has syntax errors."))
            if content.count("\n") > 600:
                issues.append(Issue(severity="error", code="diff_too_large", path=pf.path, message="New file too long (>600 lines)."))
            issues += soft_checks(pf.path, "", content, None)
            if not any(i.severity == "error" for i in issues):
                res.status, res.summary, res.added, res.attempts = "applied", nf.summary, content.count("\n"), attempt
                res.issues = issues
                self.pending[pf.path], self.styles[pf.path] = content, style
                self.applied.append(udiff("", content, pf.path, 2)[:3000])
                return res
            res.issues = issues
            feedback = P.FEEDBACK.format(issues=self._fmt(issues), previous=content[:2500])
        res.status = "failed"
        return res

    # ------------------------------------------------------------------ correction de compilation
    async def fix_build(self, errors: list[dict]) -> int:
        by_file: dict[str, list[dict]] = {}
        for e in errors:
            if e["path"] in self.pending:
                by_file.setdefault(e["path"], []).append(e)
        fixed = 0
        for path, errs in by_file.items():
            pf = next(f for f in self.files if f.path == path)
            old = self.pending[path]
            style = self.styles[path]
            regions = allowed_regions(old, pf, self.cfg.scope_slack_lines) + [(max(1, e["line"] - 12), e["line"] + 12) for e in errs]
            view = build_view(old, regions, self.cfg.view_budget_tokens, count_tokens)
            feedback = ""
            for attempt in range(2):
                user = P.BUILDFIX.format(plan=plan_context(self.plan, path), path=path, errors="\n".join(f"- line {e['line']}: {e['msg']}" for e in errs[:12]), view=view, applied="(none)", feedback=feedback)
                es = await self.llm.json(P.SYSTEM, user, EditSet)
                if es.cannot_apply.strip() or not es.edits:
                    break
                new, issues, _ = apply_edits(old, es.edits, style, path)
                if new is not None:
                    issues += syntax_check(path, old, new) + deletion_guard(self.cfg, path, old, new)
                if new is not None and not any(i.severity == "error" for i in issues):
                    self.pending[path] = new
                    self.ws.write_atomic(self.ws.abs_path(self.targets[path]), join_raw(new, style))
                    self.applied.append(udiff(old, new, path, 2)[:2000])
                    self.results[path].edits.append({"op": "build_fix", "reason": es.summary, "match": "exact"})
                    fixed += 1
                    break
                feedback = P.FEEDBACK.format(issues=self._fmt(issues), previous=json.dumps([e.model_dump() for e in es.edits])[:2500])
        return fixed


# =========================================================================================== graphe
class DevAgent:
    def __init__(self, cfg: Settings, llm: LLM, architect: ArchitectLike | None = None):
        self.cfg, self.llm, self.architect = cfg, llm, architect

    async def apply(self, plan: PlanInput, *, eap_ref: str | None = None, restart: bool = False) -> DevReport:
        """`eap_ref` : référence du ticket de développement (EAP-12610), qui NE se déduit PAS du ticket Mantis. `restart` : repartir de zéro pour ce ticket
        (supprime l'ancien worktree/la branche/les rapports) — la nouvelle tentative d'un orchestrateur après un échec de la QA, par exemple."""
        run = Run(self.cfg, self.llm, plan, self.architect, eap_ref)
        try:
            if restart:
                run.ws.reset()
            await self._graph(run).ainvoke({"idx": 0, "stop": False}, {"recursion_limit": 120})
        except Exception as e:                                           # noqa: BLE001 — jamais de disque à moitié modifié
            log.exception("échec inattendu pour %s", plan.ticket_id)
            self._safe_revert(run)
            run.status, run.reason = "failed", f"{type(e).__name__}: {e}"
            run.diff, run.diff_applied = run.diff or self._proposed(run), False
            self._safe_cleanup(run)
        return self._report(run)

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _safe_revert(run: Run) -> None:
        try:
            if run.ws.worktrees:
                run.ws.revert()
        except Exception:                                                # noqa: BLE001
            log.exception("revert impossible")

    @staticmethod
    def _safe_cleanup(run: Run) -> None:
        try:
            run.ws.cleanup(drop_branch=True)
        except Exception:                                                # noqa: BLE001
            log.exception("cleanup impossible")

    @staticmethod
    def _proposed(run: Run) -> str:
        return "\n".join(udiff(run.orig[p][0] if p in run.orig else "", new, p) for p, new in run.pending.items())

    def _graph(self, run: Run):
        cfg = self.cfg

        async def n_prepare(s: State) -> State:
            p, body = run.plan, run.plan.plan
            major = p.schema_version.split(".")[0]
            if major != "1":
                run.reject = f"schema_version {p.schema_version} non supportée (attendu 1.x)"
            elif p.status == "needs_review" and not cfg.approve_review:
                run.reject = "le plan est 'needs_review' : relis-le puis relance avec l'approbation explicite (--approve)"
            elif p.status not in {"ready", "needs_review"}:
                run.reject = f"plan non exécutable (status={p.status}) : {p.status_reason}"
            elif body is None or not body.files_to_modify:
                run.reject = "le plan ne contient aucun fichier à modifier"
            elif any(f.change_type == "remove" for f in body.files_to_modify) and not cfg.allow_remove:
                run.reject = "le plan supprime un fichier : relancer avec l'autorisation explicite (--allow-remove)"
            if run.reject:
                return {"stop": True}
            paths = [f.path for f in body.files_to_modify]
            if len(set(paths)) != len(paths):
                run.reject = "le plan liste plusieurs fois le même fichier"
                return {"stop": True}
            try:
                for f in body.files_to_modify:
                    run.targets[f.path] = run.ws.parse(f.path)
                run.files = sorted(body.files_to_modify, key=lambda f: _RANK.get(Path(f.path).suffix.lower(), 2))
                for f in run.files:
                    abs_p = run.ws.abs_path(run.targets[f.path], must_exist=(f.change_type != "add"))
                    if f.change_type == "add":
                        run.ws.abs_path(run.targets[f.path], must_exist=False)
                    else:
                        raw = run.ws.read_raw(abs_p)
                        if "\x00" in raw[:4096]:
                            raise WorkspaceError(f"fichier binaire : {f.path}")
                        run.orig[f.path] = split_raw(raw)
            except WorkspaceError as e:
                run.reject = str(e)
                DevAgent._safe_cleanup(run)
                return {"stop": True}
            return {"stop": False}

        def after_prepare(s: State) -> str:
            return "finalize" if s.get("stop") else "edit"

        async def n_edit(s: State) -> State:
            pf = run.files[s["idx"]]
            run.results[pf.path] = await run.edit_one(pf)
            return {"idx": s["idx"] + 1}

        def after_edit(s: State) -> str:
            return "edit" if s["idx"] < len(run.files) else "apply"

        async def n_apply(s: State) -> State:
            bad = [r for r in run.results.values() if r.status != "applied"]
            if bad:
                run.status = "needs_review"
                run.reason = "; ".join(f"{r.path}: " + next((f"[{i.code}] {i.message}" for i in r.issues if i.severity == "error"), r.status) for r in bad)[:900]
                return {"stop": True}
            added = [f.path for f in run.files if f.change_type == "add"]
            if added or any(f.path.endswith(("CMakeLists.txt", ".cmake")) for f in run.files):
                run.warnings.append(Issue(severity="warning", code="reconfigure_needed", message=(
                    "A file is added or a CMake file changed. EasiPlayer collects sources with GLOB and runs moc only on headers with Q_OBJECT, "
                    "so CMake must be CONFIGURED AGAIN before building: a plain `cmake --build` will not see the new file.")))
            by_repo: dict[str, list[str]] = {}
            for path, text in run.pending.items():
                t = run.targets[path]
                run.ws.write_atomic(run.ws.abs_path(t), join_raw(text, run.styles[path]))
                by_repo.setdefault(t.repo, []).append(t.rel)
            for repo, rels in by_repo.items():
                run.ws.stage(repo, rels)
            for path in run.removals:
                run.ws.remove(run.targets[path])
            run.written = True
            return {"stop": False}

        def after_apply(s: State) -> str:
            return "finalize" if s.get("stop") else ("build" if cfg.build_command else "finalize")

        async def n_build(s: State) -> State:
            rounds = run.build.rounds
            res, errs = run_build(cfg, run.ws)
            res.rounds = rounds
            run.build = res
            run._build_errors = errs
            return {"build_ok": bool(res.ok)}

        def after_build(s: State) -> str:
            if s.get("build_ok") or run.build.rounds >= cfg.max_build_rounds:
                return "finalize"
            return "fix"

        async def n_fix(s: State) -> State:
            fixed = await run.fix_build(run._build_errors)
            run.build.rounds += 1
            if fixed == 0:
                run.build.rounds = cfg.max_build_rounds                  # rien à tenter de plus
            else:
                by_repo: dict[str, list[str]] = {}
                for path in run.pending:
                    by_repo.setdefault(run.targets[path].repo, []).append(run.targets[path].rel)
                for repo, rels in by_repo.items():
                    run.ws.stage(repo, rels)
            return {}

        async def n_finalize(s: State) -> State:
            ws = run.ws
            if run.reject:
                run.status, run.reason = "rejected", run.reject
            elif run.status == "needs_review":                              # échec d'édition : rien n'a été écrit
                run.diff, run.diff_applied = DevAgent._proposed(run), False
                DevAgent._safe_cleanup(run)
            elif run.build.ran and not run.build.ok:
                run.diff, run.diff_applied = ws.diff(), False
                DevAgent._safe_revert(run)
                run.status, run.reason = "needs_review", "La compilation échoue encore après les corrections automatiques : modifications annulées, diff proposé."
                DevAgent._safe_cleanup(run)
            else:
                allowed: dict[str, set[str]] = {}
                for p in [*run.pending, *run.removals]:
                    allowed.setdefault(run.targets[p].repo, set()).add(run.targets[p].rel)
                stray = ws.unexpected_changes(allowed)
                if stray:
                    run.warnings.append(Issue(severity="warning", code="unexpected_changes", message="Files changed outside the plan (not committed): " + ", ".join(stray[:8])))
                run.diff, run.diff_applied = ws.diff(), True
                run.set_commit_subject()
                if cfg.commit:
                    msg = (f"{run.commit_subject}\n\nMantis: {run.plan.ticket_id}\nRoot cause: {run.body.root_cause}\n\n"
                           "Applied automatically by the Developer agent from the Strategist plan; review before merging.")
                    run.commits = ws.commit(msg)
                run.status = "applied"
                if not run.build.ran:
                    run.warnings.append(Issue(severity="info", code="build_not_verified", message="No build command configured: compilation was NOT verified (syntax was checked with tree-sitter only)."))
            return {}

        g = StateGraph(State)
        for name, fn in [("prepare", n_prepare), ("edit", n_edit), ("apply", n_apply), ("build", n_build), ("fix", n_fix), ("finalize", n_finalize)]:
            g.add_node(name, fn)
        g.add_edge(START, "prepare")
        g.add_conditional_edges("prepare", after_prepare, {"finalize": "finalize", "edit": "edit"})
        g.add_conditional_edges("edit", after_edit, {"edit": "edit", "apply": "apply"})
        g.add_conditional_edges("apply", after_apply, {"finalize": "finalize", "build": "build"})
        g.add_conditional_edges("build", after_build, {"finalize": "finalize", "fix": "fix"})
        g.add_edge("fix", "build")
        g.add_edge("finalize", END)
        return g.compile()

    # ------------------------------------------------------------------ retour pour le Stratège (en anglais : il sera relu par un LLM)
    @staticmethod
    def _feedback(run: Run) -> str:
        """Faits observés quand le plan ne s'applique pas : à joindre à une NOUVELLE demande de plan. Aucun contrat n'existe côté Stratège pour ce retour
        (son API prend un ticket) : c'est du texte, pas un champ typé."""
        if run.reject or not run.results:
            return ""
        lines = []
        for f in run.files:
            r = run.results.get(f.path)
            if r is None or r.status == "applied":
                continue
            errs = [i for i in r.issues if i.severity == "error"]
            why = "; ".join(f"[{i.code}] {i.message}" for i in errs[:3]) or r.status
            lines.append(f"- {f.path} (symbols: {', '.join(f.symbols) or '-'}; plan line hint: {f.line_hint or '-'}): {'CANNOT APPLY' if r.status == 'skipped' else 'edits rejected ' + str(r.attempts) + ' time(s)'} — {why}")
        if not lines:
            return ""
        return ("The Developer could not apply the plan to the current code (nothing was written). Observed facts:\n" + "\n".join(lines)
                + "\nPlease re-plan taking these facts into account: check the named symbols and line ranges against the code, and keep the change inside them.")

    # ------------------------------------------------------------------ rapport
    def _report(self, run: Run) -> DevReport:
        ws = run.ws
        files = [run.results[f.path] for f in run.files if f.path in run.results]
        rep = DevReport(
            ticket_id=run.plan.ticket_id, status=run.status if run.status in {"applied", "needs_review", "failed", "rejected"} else "failed",
            status_reason=run.reason, branches=dict(ws.branches) if run.status == "applied" else {},
            worktrees={r: str(p) for r, p in ws.worktrees.items()} if run.status == "applied" else {},
            bases=dict(ws.bases) if run.status == "applied" else {},
            commits=run.commits, files=files, build=run.build, diff=run.diff, diff_applied=run.diff_applied, warnings=run.warnings,
            commit_subject=run.commit_subject,
            meta={"agent_version": __version__, "model": self.cfg.llm_model, "seconds": round(time.time() - run.t0, 1), "llm": dict(self.llm.usage),
                  "base_ref": self.cfg.base_ref, "eap_ref": run.eap_ref or "", "commit_prefix": run.commit_prefix,
                  "plan_sha256": hashlib.sha256(run.plan.model_dump_json().encode()).hexdigest(), "format": dict(run.format_stats),
                  "architect_facts": list(run.facts_used), "qt_min_version": self.cfg.qt_min_version})
        if rep.status == "applied":
            body = run.body.verification
            rep.build_hints = BuildHints(
                changed_files=[f.path for f in run.files if run.results.get(f.path) and run.results[f.path].status == "applied"],
                new_files=[f.path for f in run.files if f.change_type == "add"],
                needs_reconfigure=any(w.code == "reconfigure_needed" for w in run.warnings) or bool(run.removals),
                build_targets=list(body.build_targets), squish_tests=list(body.squish_tests), manual_checks=list(body.manual_checks))
        else:
            rep.feedback_for_strategist = self._feedback(run)
        if rep.status == "applied":
            rep.next_steps = [f"Relire le diff ({ws.root / 'changes.diff'}) puis le worktree de chaque dépôt : {', '.join(rep.worktrees.values())}",
                              "Compiler et lancer les tests Squish ciblés du plan (étape suivante de la chaîne)",
                              "Fusionner la branche de l'agent seulement après validation : " + ", ".join(f"{r}:{b}" for r, b in rep.branches.items())]
            if run.commit_prefix.startswith("[EAP-TODO]"):
                rep.next_steps.append(f"Remplacer EAP-TODO par la vraie référence dans le message de commit : {run.commit_subject}")
            if rep.build_hints.needs_reconfigure:
                rep.next_steps.append("Reconfigurer CMake avant de compiler (fichier ajouté/supprimé ou CMakeLists modifié ; sources par GLOB)")
        elif rep.status == "needs_review":
            rep.next_steps = ["Aucun fichier modifié. Lire le diff proposé (proposed.diff) et les problèmes par fichier ; corriger le plan (Stratège) ou appliquer à la main."]
        d = ws.root
        d.mkdir(parents=True, exist_ok=True)
        (d / "plan.json").write_text(run.plan.model_dump_json(indent=2))          # le rapport du Stratège, tel que reçu : relu à chaque tour de correction
        (d / "dev_report.json").write_text(rep.model_dump_json(indent=2))
        if rep.diff:
            (d / ("changes.diff" if rep.diff_applied else "proposed.diff")).write_text(rep.diff + ("\n" if not rep.diff.endswith("\n") else ""))
        (d / "dev_report.md").write_text(to_markdown(rep))
        return rep


def to_markdown(r: DevReport) -> str:
    badge = {"applied": "APPLIQUÉ", "needs_review": "À RELIRE (rien n'a été modifié)", "failed": "ÉCHEC", "rejected": "REFUSÉ"}[r.status]
    o = [f"# Rapport du Développeur — {r.ticket_id}", "", f"**Statut** : {badge}" + (f" — {r.status_reason}" if r.status_reason else ""), ""]
    if r.branches:
        o += ["## Branches / worktrees", *[f"- `{k}` : branche `{v}` — worktree `{r.worktrees.get(k, '')}`" + (f" — commit `{r.commits[k][:10]}`" if k in r.commits else "") for k, v in r.branches.items()], ""]
    o += ["## Fichiers"]
    for f in r.files:
        o += [f"### `{f.path}` — {f.status} ({f.attempts} essai(s), +{f.added}/-{f.removed})", f.summary or ""]
        o += [f"- {'❌' if i.severity == 'error' else '⚠️'} `{i.code}` {i.message}" for i in f.issues]
    if r.build.ran:
        o += ["", f"## Compilation : {'OK' if r.build.ok else 'ÉCHEC'} ({r.build.rounds} correction(s))", *[f"- {e}" for e in r.build.errors[:10]]]
    if r.warnings:
        o += ["", "## Avertissements", *[f"- `{w.code}` {w.message}" for w in r.warnings]]
    o += ["", "## Diff " + ("appliqué" if r.diff_applied else "proposé (NON appliqué)"), "```diff", r.diff.rstrip(), "```", ""]
    if r.next_steps:
        o += ["## Suite", *[f"- {s}" for s in r.next_steps], ""]
    return "\n".join(o)
