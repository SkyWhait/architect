"""Compilation optionnelle (commande fournie par l'opérateur dans la config, jamais par le LLM ; pas de shell implicite)."""
from __future__ import annotations

import re
import subprocess
from pathlib import Path

from .config import Settings
from .models import BuildResult
from .workspace import Workspace

_ERR = re.compile(r"^(?P<file>/?[^\s:][^:\n]*?):(?P<line>\d+):(?:(?P<col>\d+):)?\s*(?:fatal error|error):\s*(?P<msg>.*)$", re.M)
_PH = re.compile(r"\{worktree:([\w.-]+)\}|\{build_dir\}")


def expand(cfg: Settings, ws: Workspace) -> list[str]:
    build_dir = ws.root / "build"
    build_dir.mkdir(parents=True, exist_ok=True)

    def sub(m: re.Match) -> str:
        if m.group(1):
            return str(ws.ensure_worktree(m.group(1)))
        return str(build_dir)

    return [_PH.sub(sub, a) for a in (cfg.build_command or [])]


def to_plan_path(ws: Workspace, raw: str) -> str:
    p = Path(raw)
    for repo, wt in ws.worktrees.items():
        try:
            return f"{repo}/{p.resolve().relative_to(wt.resolve()).as_posix()}"
        except ValueError:
            continue
    return raw


def run_build(cfg: Settings, ws: Workspace) -> tuple[BuildResult, list[dict]]:
    cmd = expand(cfg, ws)
    res = BuildResult(ran=True, command=cmd)
    try:
        r = subprocess.run(cmd, cwd=ws.root, capture_output=True, text=True, timeout=cfg.build_timeout_s)
        out, res.ok = (r.stdout or "") + "\n" + (r.stderr or ""), r.returncode == 0
    except subprocess.TimeoutExpired as e:
        out, res.ok = f"build timeout after {cfg.build_timeout_s}s\n{(e.stdout or b'')[-2000:]!r}", False
    except OSError as e:
        out, res.ok = f"cannot run build command: {e}", False
    res.output_tail = out[-3000:]
    errors = [{"path": to_plan_path(ws, m.group("file")), "line": int(m.group("line")), "msg": m.group("msg").strip()} for m in _ERR.finditer(out)]
    res.errors = [f"{e['path']}:{e['line']}: {e['msg']}" for e in errors[:30]]
    return res, errors
