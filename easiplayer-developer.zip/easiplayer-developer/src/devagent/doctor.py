"""`devagent doctor` : contrôle de pré-vol, SANS rien modifier. À lancer sur la vraie machine avant le premier essai (ce que les tests ne peuvent pas savoir :
dépôts réels, clang-format, serveur vLLM, Architecte, commande de build)."""
from __future__ import annotations

import asyncio
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

from .architect import ArchitectUnavailable, HttpArchitect
from .config import Settings
from .formatter import binary, find_style_file
from .workspace import git

REPOS = ("EasiPlayer", "EasiPlayerPlugin", "EasiPlayerDbusDaemon")


@dataclass
class Check:
    name: str
    status: str          # ok | warn | fail | skip
    detail: str = ""


def _repos(cfg: Settings) -> list[Check]:
    out = []
    for r in REPOS:
        p = cfg.world_root / r
        if not p.is_dir():
            out.append(Check(f"dépôt {r}", "warn" if r != "EasiPlayer" else "fail", f"{p} introuvable"))
            continue
        try:
            top = Path(git(p, "rev-parse", "--show-toplevel").strip()).resolve()
            base = git(p, "rev-parse", "--verify", f"{cfg.base_ref}^{{commit}}").strip()[:10]
            dirty = git(p, "status", "--porcelain").strip()
            ok = top == p.resolve()
            out.append(Check(f"dépôt {r}", "ok" if ok else "fail",
                             f"{cfg.base_ref}={base}" + ("" if ok else f" ; {p} n'est pas la racine git ({top})")
                             + (" ; modifications non commitées (NON incluses dans le worktree de l'agent)" if dirty else "")))
        except Exception as e:                               # noqa: BLE001
            out.append(Check(f"dépôt {r}", "fail", str(e)[:200]))
    return out


def _format(cfg: Settings) -> Check:
    exe = binary(cfg)
    if cfg.format_mode == "off":
        return Check("clang-format", "skip", "DEV_FORMAT_MODE=off")
    if exe is None:
        return Check("clang-format", "warn", f"`{cfg.clang_format_bin}` absent du PATH : les lignes ne seront pas reformatées (seulement signalées)")
    ver = subprocess.run([exe, "--version"], capture_output=True, text=True).stdout.strip()
    style = Path(cfg.clang_format_file) if cfg.clang_format_file else find_style_file(cfg.world_root / "EasiPlayer", cfg.world_root / "EasiPlayer")
    if style is None or not Path(style).is_file():
        return Check("clang-format", "warn", f"{ver} ; aucun .clang-format dans EasiPlayer/ (ni DEV_CLANG_FORMAT_FILE)")
    return Check("clang-format", "ok", f"{ver} ; style : {style}")


async def _llm(cfg: Settings) -> Check:
    """Vérifie que le serveur accepte la sortie JSON imposée par schéma (response_format json_schema) : c'est ce qui garantit des éditions typées."""
    from openai import AsyncOpenAI
    from pydantic import BaseModel

    class Ping(BaseModel):
        ok: bool

    try:
        c = AsyncOpenAI(base_url=cfg.llm_base_url, api_key=cfg.llm_api_key, timeout=60)
        r = await c.chat.completions.create(model=cfg.llm_model, messages=[{"role": "user", "content": 'Reply with {"ok": true}'}], max_tokens=20,
                                            temperature=0, response_format={"type": "json_schema", "json_schema": {"name": "Ping", "schema": Ping.model_json_schema(), "strict": True}})
        Ping.model_validate_json(r.choices[0].message.content or "")
        return Check("LLM (json_schema)", "ok", f"{cfg.llm_model} @ {cfg.llm_base_url}")
    except Exception as e:                                   # noqa: BLE001
        return Check("LLM (json_schema)", "fail", f"{type(e).__name__}: {str(e)[:200]}")


async def _architect(cfg: Settings) -> Check:
    if not cfg.architect_url:
        return Check("Architecte", "skip", "DEV_ARCHITECT_URL non défini : pas de « déclarations des types appelés » dans les prompts")
    a = HttpArchitect(cfg.architect_url, cfg.architect_token, cfg.architect_timeout_s, retries=0)
    try:
        st = await a.index_status()
        n = (st.get("stats") or {}).get("symbols")
        return Check("Architecte", "ok" if n else "warn", f"{cfg.architect_url} ; symboles indexés : {n}")
    except ArchitectUnavailable as e:
        return Check("Architecte", "warn", f"injoignable ({str(e)[:120]}) : l'agent fonctionnera sans ce contexte")
    finally:
        await a.aclose()


def _build(cfg: Settings) -> Check:
    if not cfg.build_command:
        return Check("compilation interne", "skip", "DEV_BUILD_COMMAND absent : normal dans la chaîne, le Compilateur compile et rappelle POST /changes/<id>/fix")
    exe = shutil.which(cfg.build_command[0])
    return Check("compilation interne", "ok" if exe else "fail", " ".join(cfg.build_command)[:200])


async def run_doctor(cfg: Settings, check_llm: bool = True) -> list[Check]:
    checks = [*_repos(cfg), _format(cfg), _build(cfg), await _architect(cfg)]
    checks.append(await _llm(cfg) if check_llm else Check("LLM (json_schema)", "skip", "--no-llm"))
    checks.append(Check("zones interdites", "ok", ", ".join(cfg.forbidden_dirs) + " + moc_*/ui_*/qrc_*"))
    checks.append(Check("conventions", "ok", f"C++11 ; Qt >= {cfg.qt_min_version} ; connect() SIGNAL/SLOT ; {cfg.column_limit} colonnes"))
    return checks


def render(checks: list[Check]) -> str:
    sym = {"ok": "✅", "warn": "⚠️ ", "fail": "❌", "skip": "⏭️ "}
    return "\n".join(f"{sym[c.status]} {c.name} — {c.detail}" for c in checks)


def main_doctor(cfg: Settings, check_llm: bool = True) -> int:
    checks = asyncio.run(run_doctor(cfg, check_llm))
    print(render(checks))
    return 1 if any(c.status == "fail" for c in checks) else 0
