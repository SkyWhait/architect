"""API HTTP : n8n (ou le futur orchestrateur) soumet un plan du Stratège, suit le statut, récupère le diff et le rapport."""
from __future__ import annotations

import asyncio
import json
import os
import time
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel

from . import __version__
from .agent import DevAgent
from .architect import make_architect
from .audit import audit
from .config import Settings, get_settings
from .llm import LLM
from .fix import apply_fix, apply_test_fix
from .models import FixRequest, FixResult, TestFixRequest, PlanInput
from .workspace import Workspace, safe_name


class ApplyRequest(BaseModel):
    plan: PlanInput                      # le `plan.json` du Stratège tel quel
    approve_review: bool = False         # accepter un plan 'needs_review' relu par un humain
    allow_remove: bool = False
    eap_ref: str | None = None           # ticket de développement (EAP-12610) pour le message de commit ; NON déductible du ticket Mantis
    restart: bool = False                # nouvelle tentative : supprime l'ancien worktree/la branche/les rapports de ce ticket avant d'appliquer
    base_ref: str | None = None          # point de départ (défaut : DEV_BASE_REF), p.ex. la branche d'une tentative précédente pour empiler un 2e plan


def create_app(llm_factory=None, settings: Settings | None = None, architect_factory=None) -> FastAPI:
    base = settings or get_settings()
    base.work_dir.mkdir(parents=True, exist_ok=True)
    jobs: dict[str, dict] = {}
    gate = asyncio.Semaphore(1)                                        # un seul GPU, un seul worktree à la fois

    def auth(authorization: str | None = Header(default=None)) -> None:
        token = base.api_token or os.environ.get("DEV_API_TOKEN")
        if token and authorization != f"Bearer {token}":
            raise HTTPException(401, "unauthorized")

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        yield
        for j in jobs.values():
            if j.get("task") and not j["task"].done():
                j["task"].cancel()

    app = FastAPI(title="EasiPlayer Developer", version=__version__, lifespan=lifespan, dependencies=[Depends(auth)])

    async def run(tid: str, req: ApplyRequest) -> None:
        async with gate:
            jobs[tid]["state"] = "running"
            cfg = base.model_copy(update={"approve_review": req.approve_review, "allow_remove": req.allow_remove,
                                          **({"base_ref": req.base_ref} if req.base_ref else {})})
            arch = architect_factory() if architect_factory else make_architect(cfg)
            audit(base.work_dir, "apply_start", tid, plan_status=req.plan.status, approved=req.approve_review, restart=req.restart, eap_ref=req.eap_ref or "")
            try:
                rep = await DevAgent(cfg, llm_factory() if llm_factory else LLM(cfg), arch).apply(req.plan, eap_ref=req.eap_ref, restart=req.restart)
            finally:
                if arch is not None:
                    await arch.aclose()
            jobs[tid].update(state="done", status=rep.status, reason=rep.status_reason)
            audit(base.work_dir, "apply_done", tid, status=rep.status, commits=rep.commits, plan_sha256=rep.meta.get("plan_sha256", ""), model=rep.meta.get("model", ""))

    @app.post("/changes", status_code=202)
    async def submit(req: ApplyRequest):
        tid = safe_name(req.plan.ticket_id)
        if jobs.get(tid, {}).get("state") in ("queued", "running"):
            raise HTTPException(409, f"une application est déjà en cours pour {tid}")
        jobs[tid] = {"state": "queued", "started": time.time()}
        jobs[tid]["task"] = asyncio.create_task(run(tid, req))
        return {"ticket_id": tid, "state": "queued"}

    def report_path(tid: str):
        return base.work_dir / safe_name(tid) / "dev_report.json"

    @app.get("/changes/{tid}")
    async def status(tid: str, full: bool = False):
        tid = safe_name(tid)
        j = jobs.get(tid)
        if j and j["state"] != "done":
            return {"ticket_id": tid, "state": j["state"], "elapsed_s": round(time.time() - j["started"])}
        if not report_path(tid).exists():
            raise HTTPException(404, "inconnu")
        rep = json.loads(report_path(tid).read_text())
        out = {"ticket_id": tid, "state": "done", "status": rep["status"], "reason": rep["status_reason"], "branches": rep["branches"],
               "commits": rep["commits"], "worktrees": rep["worktrees"]}
        return {**out, "report": rep} if full else out

    @app.post("/changes/{tid}/fix", response_model=FixResult)
    async def fix(tid: str, req: FixRequest):
        """Correction d'un worktree déjà appliqué à partir des diagnostics du Compilateur. Synchrone : renvoie quand le tour est terminé."""
        tid = safe_name(tid)
        if jobs.get(tid, {}).get("state") in ("queued", "running"):
            raise HTTPException(409, "une application est déjà en cours pour ce ticket")
        async with gate:
            jobs[tid] = {"state": "running", "started": time.time()}
            try:
                res = await apply_fix(base, llm_factory() if llm_factory else LLM(base), tid, req)
                audit(base.work_dir, "fix", tid, round=req.round, status=res.status, commits=res.commits)
                return res
            finally:
                jobs[tid]["state"] = "done"

    @app.post("/changes/{tid}/fix_tests", response_model=FixResult)
    async def fix_tests(tid: str, req: TestFixRequest):
        """La QA signale des tests Squish en échec avec la modification : le Développeur la corrige (plan du Stratège + retour de la QA sous les yeux). Synchrone."""
        tid = safe_name(tid)
        if jobs.get(tid, {}).get("state") in ("queued", "running"):
            raise HTTPException(409, "une application est déjà en cours pour ce ticket")
        async with gate:
            jobs[tid] = {"state": "running", "started": time.time()}
            try:
                res = await apply_test_fix(base, llm_factory() if llm_factory else LLM(base), tid, req)
                audit(base.work_dir, "fix_tests", tid, round=req.round, status=res.status, commits=res.commits)
                return res
            finally:
                jobs[tid]["state"] = "done"

    @app.get("/changes/{tid}/diff", response_class=PlainTextResponse)
    async def diff(tid: str):
        d = base.work_dir / safe_name(tid)
        for name in ("changes.diff", "proposed.diff"):
            if (d / name).exists():
                return (d / name).read_text()
        raise HTTPException(404, "aucun diff")

    @app.get("/changes/{tid}/report", response_class=PlainTextResponse)
    async def report(tid: str):
        p = base.work_dir / safe_name(tid) / "dev_report.md"
        if not p.exists():
            raise HTTPException(404, "pas de rapport")
        return p.read_text()

    @app.delete("/changes/{tid}")
    async def clean(tid: str, drop_branch: bool = False):
        if jobs.get(safe_name(tid), {}).get("state") in ("queued", "running"):
            raise HTTPException(409, "en cours")
        Workspace(base, tid).cleanup(drop_branch=drop_branch)
        audit(base.work_dir, "clean", safe_name(tid), drop_branch=drop_branch)
        return {"cleaned": safe_name(tid), "branch_dropped": drop_branch}

    @app.get("/health")
    async def health():
        return {"ok": True, "agent": "developer", "version": __version__}

    return app
