"""Journal d'audit (JSON lines) : une ligne par action de l'agent, pour la traçabilité exigée de la chaîne (qui a demandé quoi, avec quel plan, résultat).

Ne contient ni code source ni secret : identifiants, empreinte du plan, statut, modèle. Écriture en ajout seulement.
"""
from __future__ import annotations

import json
import time
from pathlib import Path


def audit(work_dir: Path, action: str, ticket: str, **fields) -> None:
    try:
        work_dir.mkdir(parents=True, exist_ok=True)
        rec = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "action": action, "ticket": ticket, **fields}
        with (work_dir / "audit.jsonl").open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except OSError:
        pass                                             # l'audit ne doit jamais empêcher le travail ; l'échec se voit à l'absence de ligne
