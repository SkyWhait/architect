"""Vue numérotée d'un fichier pour le LLM : fichier entier s'il tient, sinon fenêtres autour des zones du plan + bloc d'includes."""
from __future__ import annotations

from typing import Callable


def numbered(lines: list[str], a: int, b: int) -> str:
    return "\n".join(f"{n:>5}| {lines[n - 1]}" for n in range(a, b + 1))


def build_view(text: str, regions: list[tuple[int, int]], budget: int, count_tokens: Callable[[str], int],
               context: int = 12, max_head: int = 80) -> str:
    lines = text.split("\n")
    n = len(lines)
    full = numbered(lines, 1, n)
    if count_tokens(full) <= budget:
        return full
    last_inc = max((i for i, ln in enumerate(lines[:max_head], 1) if ln.lstrip().startswith(("#include", "#pragma", "#ifndef", "#define"))), default=0)
    windows = [(max(1, a - context), min(n, b + context)) for a, b in regions]
    head = (1, max(last_inc, min(n, 40)))
    chosen: list[tuple[int, int]] = []
    used = 0
    for w in windows + [head] if windows else [(1, min(n, 150))]:
        t = count_tokens(numbered(lines, *w))
        if used + t <= budget:
            chosen.append(w); used += t
        elif not chosen:                                    # une seule grosse zone : on la tronque plutôt que de ne rien montrer
            chosen.append((w[0], w[0] + max(40, int((w[1] - w[0]) * budget / t))))
            break
    merged: list[list[int]] = []
    for a, b in sorted(chosen):
        if merged and a <= merged[-1][1] + 1:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    out, prev = [], 0
    for a, b in merged:
        if a > prev + 1:
            out.append(f"      ... [lines {prev + 1}-{a - 1} not shown] ...")
        out.append(numbered(lines, a, b)); prev = b
    if prev < n:
        out.append(f"      ... [lines {prev + 1}-{n} not shown] ...")
    return "\n".join(out)
