"""Correction ciblée d'un worktree DÉJÀ appliqué, à partir des diagnostics du Compilateur (boucle courte de débogage).

Mêmes garde-fous que l'application initiale : le LLM n'émet que des éditions typées, vérifiées (syntaxe, suppression, périmètre autour des
lignes en erreur) ; seuls les fichiers du plan (rapport du Développeur) sont modifiables ; chaque tour est un commit sur la branche de l'agent.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

from . import prompts as P
from .agent import to_markdown, udiff
from .config import Settings
from .conventions import conventions_check
from .cpp_checks import allowed_regions, deletion_guard, language_of, public_api_check, scope_check, syntax_check
from .formatter import changed_ranges, format_changed_lines
from .editing import apply_edits, join_raw, split_raw
from .llm import LLM, count_tokens
from .models import DevReport, EditSet, FixDiagnostic, FixRequest, FixResult, Issue, PlanInput, TestFixRequest
from .plan_context import plan_context
from .view import build_view
from .workspace import Workspace, WorkspaceError, git

log = logging.getLogger("devagent.fix")


def _describe(d: FixDiagnostic, own: bool) -> str:
    head = f"- line {d.line}:{d.column} [{d.category}] {d.message}" if own else f"- (error in {d.path}:{d.line} — may require a change HERE) [{d.category}] {d.message}"
    lines = [head, *[f"    hint: {h}" for h in d.hints[:3]], *[f"    compiler note: {n}" for n in d.notes[:2]]]
    return "\n".join(lines)


async def apply_fix(cfg: Settings, llm: LLM, ticket_id: str, req: FixRequest) -> FixResult:
    res = FixResult(ticket_id=ticket_id, status="no_change", round=req.round)
    ws = Workspace(cfg, ticket_id)
    rpath = ws.root / "dev_report.json"
    if not rpath.exists():
        return res.model_copy(update={"status": "rejected", "reason": f"aucun rapport du Développeur pour {ticket_id} (rien n'a été appliqué)"})
    report = DevReport.model_validate_json(rpath.read_text())
    if report.status != "applied":
        return res.model_copy(update={"status": "rejected", "reason": f"le dernier run n'est pas 'applied' (status={report.status})"})
    try:
        ws.attach(report.worktrees, report.branches, report.bases)
    except WorkspaceError as e:
        return res.model_copy(update={"status": "rejected", "reason": str(e)})

    plan_in: PlanInput | None = None
    if (ws.root / "plan.json").exists():
        try:
            plan_in = PlanInput.model_validate_json((ws.root / "plan.json").read_text())
        except ValueError:
            plan_in = None
    allowed = {f.path for f in report.files if f.status == "applied"}
    own: dict[str, list[FixDiagnostic]] = {}
    related: dict[str, list[FixDiagnostic]] = {}
    for d in req.diagnostics:
        if d.severity != "error":
            continue
        if d.path in allowed:
            own.setdefault(d.path, []).append(d)
        else:
            res.issues.append(Issue(severity="warning", code="out_of_plan", path=d.path, message="Diagnostic outside the plan's files: not editable by this agent."))
        for sf in d.suggest_files:
            if sf in allowed and sf != d.path:
                related.setdefault(sf, []).append(d)
    order = sorted(set(own) | set(related), key=lambda p: (0 if p.endswith((".h", ".hpp", ".hh")) else 1, p))      # en-têtes d'abord
    if not order:
        return res.model_copy(update={"status": "rejected", "reason": "aucun diagnostic dans les fichiers du plan : rien à corriger par cet agent",
                                      "issues": res.issues})

    applied_notes: list[str] = []
    changed: dict[str, list[str]] = {}
    for path in order:
        fr = {"path": path, "status": "failed", "summary": "", "attempts": 0, "issues": []}
        res.files.append(fr)
        try:
            t = ws.parse(path)
            abs_p = ws.abs_path(t, must_exist=True)
            old, style = split_raw(ws.read_raw(abs_p))
        except WorkspaceError as e:
            fr["issues"].append(str(e))
            continue
        mine, rel = own.get(path, []), related.get(path, [])
        regions = [(max(1, d.line - cfg.scope_slack_lines), d.line + cfg.scope_slack_lines) for d in mine if d.line]
        view = build_view(old, regions or [(1, min(80, old.count("\n") + 1))], cfg.view_budget_tokens, count_tokens)
        errors_txt = "\n".join([*[_describe(d, True) for d in mine[:10]], *[_describe(d, False) for d in rel[:6]]])
        feedback = ""
        for attempt in range(1, 3):
            fr["attempts"] = attempt
            user = P.BUILDFIX.format(path=path, plan=plan_context(plan_in, path), errors=errors_txt, view=view, applied="\n".join(applied_notes)[:3500] or "(none)", feedback=feedback)
            es = await llm.json(P.SYSTEM, user, EditSet)
            fr["summary"] = es.summary
            if es.cannot_apply.strip():
                fr["issues"].append(f"cannot_apply: {es.cannot_apply.strip()}")
                break
            new, issues, _ = apply_edits(old, es.edits, style, path) if es.edits else (None, [Issue(severity="error", code="no_edits", path=path, message="No edits.")], [])
            if new is not None:
                fmt = format_changed_lines(cfg, abs_p, ws.worktrees[t.repo], old, new)
                cand = fmt.text if fmt.status == "formatted" else new

                def checks(txt: str) -> list[Issue]:
                    out = syntax_check(path, old, txt) + deletion_guard(cfg, path, old, txt) + public_api_check(path, old, txt, False)
                    if language_of(path) == "cpp":
                        out += conventions_check(path, old, txt, cfg.qt_min_version, cfg.column_limit)
                    if mine and not rel and regions:                   # périmètre = fenêtres autour des lignes en erreur (sauf si le fichier doit aussi servir à un autre)
                        out += scope_check(path, old, txt, regions)
                    return out

                issues += checks(cand)
                if cand is not new and any(i.severity == "error" for i in issues):       # le formatage ne doit jamais faire échouer une correction
                    issues = checks(new)
                else:
                    new = cand
            errs = [i for i in issues if i.severity == "error"]
            if new is not None and not errs:
                ws.write_atomic(abs_p, join_raw(new, style))
                changed.setdefault(t.repo, []).append(t.rel)
                applied_notes.append(udiff(old, new, path, 2)[:1800])
                fr["status"] = "applied"
                fr["issues"] = [f"{i.code}: {i.message}" for i in issues if i.severity != "error"]
                break
            fr["issues"] = [f"{i.code}: {i.message}" for i in issues]
            feedback = P.FEEDBACK.format(issues="\n".join(f"- [{i.code}] {i.message}" for i in errs),
                                         previous=json.dumps([e.model_dump() for e in es.edits], ensure_ascii=False)[:2500])

    if not changed:
        return res.model_copy(update={"status": "no_change", "reason": "; ".join(f"{f['path']}: {f['issues'][0]}" for f in res.files if f["issues"])[:600] or "aucune correction proposée",
                                      "files": res.files, "issues": res.issues})
    for repo, rels in changed.items():
        ws.stage(repo, rels)
    if cfg.commit:
        prefix = report.meta.get("commit_prefix") or "[EAP-TODO][General]"          # même préfixe que le commit initial
        res.commits = ws.commit(f"{prefix}{cfg.commit_separator}Fix build errors (round {req.round})\n\nMantis: {ticket_id}\nAutomatic correction from compiler diagnostics.")
    # --- rapport du Développeur mis à jour : la suite de la chaîne lit toujours dev_report.json
    for f in report.files:
        for fr in res.files:
            if fr["path"] == f.path and fr["status"] == "applied":
                f.edits.append({"op": "build_fix", "reason": f"compiler round {req.round}: {fr['summary']}", "match": "exact"})
    report.commits = {**report.commits, **res.commits}
    report.diff, report.diff_applied = ws.diff_from_base() or report.diff, True
    report.meta["fix_rounds"] = report.meta.get("fix_rounds", 0) + 1
    rpath.write_text(report.model_dump_json(indent=2))
    (ws.root / "changes.diff").write_text(report.diff if report.diff.endswith("\n") else report.diff + "\n")
    (ws.root / "dev_report.md").write_text(to_markdown(report))
    bad = [f for f in res.files if f["status"] != "applied"]
    res.status = "fixed"
    res.reason = f"{len(res.files) - len(bad)} fichier(s) corrigé(s)" + (f", {len(bad)} non corrigé(s)" if bad else "")
    return res


async def apply_test_fix(cfg: Settings, llm: LLM, ticket_id: str, req: TestFixRequest) -> FixResult:
    """Boucle QA -> Développeur : les tests Squish échouent avec notre modification. Chaque fichier DÉJÀ modifié par le plan est réexaminé avec le plan du Stratège, le retour
    de la QA et le diff de notre changement ; les éditions restent dans les zones que nous avons modifiées (ou que le plan visait), avec les mêmes vérifications que partout."""
    res = FixResult(ticket_id=ticket_id, status="no_change", round=req.round)
    ws = Workspace(cfg, ticket_id)
    rpath = ws.root / "dev_report.json"
    if not rpath.exists():
        return res.model_copy(update={"status": "rejected", "reason": f"aucun rapport du Développeur pour {ticket_id} (rien n'a été appliqué)"})
    report = DevReport.model_validate_json(rpath.read_text())
    if report.status != "applied":
        return res.model_copy(update={"status": "rejected", "reason": f"le dernier run n'est pas 'applied' (status={report.status})"})
    try:
        ws.attach(report.worktrees, report.branches, report.bases)
    except WorkspaceError as e:
        return res.model_copy(update={"status": "rejected", "reason": str(e)})
    plan_in: PlanInput | None = None
    if (ws.root / "plan.json").exists():
        try:
            plan_in = PlanInput.model_validate_json((ws.root / "plan.json").read_text())
        except ValueError:
            plan_in = None
    plan_files = {f.path: f for f in plan_in.plan.files_to_modify} if plan_in else {}
    order = sorted((f.path for f in report.files if f.status == "applied"), key=lambda p: (0 if p.endswith((".h", ".hpp", ".hh")) else 1, p))
    if not order:
        return res.model_copy(update={"status": "rejected", "reason": "aucun fichier modifié par le plan : rien à corriger"})

    applied_notes: list[str] = []
    changed: dict[str, list[str]] = {}
    for path in order:
        fr = {"path": path, "status": "failed", "summary": "", "attempts": 0, "issues": []}
        res.files.append(fr)
        try:
            t = ws.parse(path)
            abs_p = ws.abs_path(t, must_exist=True)
            old, style = split_raw(ws.read_raw(abs_p))
        except WorkspaceError as e:
            fr["issues"].append(str(e))
            continue
        start = git(ws.worktrees[t.repo], "show", f"{ws.bases[t.repo]}:{t.rel}", check=False).replace("\r\n", "\n")
        diff = udiff(start, old.replace("\r\n", "\n"), path, 3)[:3500] or "(no change in this file)"
        hunks = [(max(1, a - cfg.scope_slack_lines), b + cfg.scope_slack_lines) for a, b in changed_ranges(start.replace("\r\n", "\n"), old)]
        planned = allowed_regions(old, plan_files[path], cfg.scope_slack_lines) if path in plan_files else []
        regions = sorted(set(hunks + planned))
        view = build_view(old, regions or [(1, min(80, old.count("\n") + 1))], cfg.view_budget_tokens, count_tokens)
        feedback = ""
        for attempt in range(1, 3):
            fr["attempts"] = attempt
            user = P.TESTFIX.format(path=path, plan=plan_context(plan_in, path), qa=req.feedback[:6000], diff=diff, view=view,
                                    applied="\n".join(applied_notes)[:3500] or "(none)", feedback=feedback)
            es = await llm.json(P.SYSTEM, user, EditSet)
            fr["summary"] = es.summary
            if es.cannot_apply.strip():
                fr["issues"].append(f"cannot_apply: {es.cannot_apply.strip()}")
                break
            new, issues, _ = apply_edits(old, es.edits, style, path) if es.edits else (None, [Issue(severity="error", code="no_edits", path=path, message="No edits.")], [])
            if new is not None:
                fmt = format_changed_lines(cfg, abs_p, ws.worktrees[t.repo], old, new)
                cand = fmt.text if fmt.status == "formatted" else new

                def checks(txt: str) -> list[Issue]:
                    out = syntax_check(path, old, txt) + deletion_guard(cfg, path, old, txt) + public_api_check(path, old, txt, False)
                    if language_of(path) == "cpp":
                        out += conventions_check(path, old, txt, cfg.qt_min_version, cfg.column_limit)
                    if regions:
                        out += scope_check(path, old, txt, regions)
                    return out

                issues += checks(cand)
                if cand is not new and any(i.severity == "error" for i in issues):
                    issues = checks(new)
                else:
                    new = cand
            errs = [i for i in issues if i.severity == "error"]
            if new is not None and not errs:
                ws.write_atomic(abs_p, join_raw(new, style))
                changed.setdefault(t.repo, []).append(t.rel)
                applied_notes.append(udiff(old, new, path, 2)[:1800])
                fr["status"] = "applied"
                fr["issues"] = [f"{i.code}: {i.message}" for i in issues if i.severity != "error"]
                break
            fr["issues"] = [f"{i.code}: {i.message}" for i in issues]
            feedback = P.FEEDBACK.format(issues="\n".join(f"- [{i.code}] {i.message}" for i in errs),
                                         previous=json.dumps([e.model_dump() for e in es.edits], ensure_ascii=False)[:2500])

    if not changed:
        why = "; ".join(f"{f['path']}: {f['issues'][0]}" for f in res.files if f["issues"])[:700] or "aucune correction proposée"
        return res.model_copy(update={"status": "no_change", "reason": why, "files": res.files})
    for repo, rels in changed.items():
        ws.stage(repo, rels)
    if cfg.commit:
        prefix = report.meta.get("commit_prefix") or "[EAP-TODO][General]"
        res.commits = ws.commit(f"{prefix}{cfg.commit_separator}Fix test failure (round {req.round})\n\nMantis: {ticket_id}\nAutomatic correction from Squish test failures.")
    for f in report.files:
        for fr in res.files:
            if fr["path"] == f.path and fr["status"] == "applied":
                f.edits.append({"op": "test_fix", "reason": f"squish round {req.round}: {fr['summary']}", "match": "exact"})
    report.commits = {**report.commits, **res.commits}
    report.diff, report.diff_applied = ws.diff_from_base() or report.diff, True
    report.meta["test_fix_rounds"] = report.meta.get("test_fix_rounds", 0) + 1
    rpath.write_text(report.model_dump_json(indent=2))
    (ws.root / "changes.diff").write_text(report.diff if report.diff.endswith("\n") else report.diff + "\n")
    (ws.root / "dev_report.md").write_text(to_markdown(report))
    bad = [f for f in res.files if f["status"] != "applied"]
    res.status = "fixed"
    res.reason = f"{len(res.files) - len(bad)} fichier(s) corrigé(s)" + (f", {len(bad)} sans correction" if bad else "")
    return res
