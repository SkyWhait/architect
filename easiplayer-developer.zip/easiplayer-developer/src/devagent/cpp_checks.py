"""Vérifications déterministes d'un fichier C++/Qt modifié (aucun LLM) : périmètre, suppression, syntaxe, API publique Qt.

Ce sont elles qui rendent l'édition « chirurgicale » : un correctif qui sort de la zone prévue par le plan, supprime
trop de code, casse la syntaxe ou renomme un slot exposé aux scripts est RENVOYÉ au LLM, jamais écrit.
"""
from __future__ import annotations

import difflib
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import PurePosixPath

import tree_sitter_cpp as _tscpp
from tree_sitter import Language, Node, Parser

from .config import Settings
from .models import Issue, PlanFile

_LANG = Language(_tscpp.language())
_PARSER = Parser(_LANG)


# ======================================================================= langages : seul le C++ passe par tree-sitter
_CPP_EXT = {".h", ".hpp", ".hh", ".hxx", ".cpp", ".cc", ".cxx", ".c"}
_XML_EXT = {".ui", ".xml", ".qrc", ".ts"}


def language_of(path: str) -> str:
    p = PurePosixPath(path.replace("\\", "/"))
    ext = p.suffix.lower()
    if ext in _CPP_EXT:
        return "cpp"
    if ext in _XML_EXT:
        return "xml"
    if p.name == "CMakeLists.txt" or ext == ".cmake":
        return "cmake"
    if ext == ".js":
        return "js"
    return "other"


# ======================================================================= tree-sitter
_BLANK = lambda m: re.sub(r"[^\n]", " ", m.group(0))        # noqa: E731 — efface en gardant longueur et lignes
_QT_MACROS = re.compile(
    r"\b(?:emit|Q_EMIT|Q_OBJECT|Q_GADGET|Q_INVOKABLE|Q_SLOT|Q_SIGNAL)\b"
    r"|\b(?:Q_PROPERTY|Q_CLASSINFO|Q_ENUMS?|Q_FLAGS|Q_DECLARE_\w+|Q_DISABLE_COPY|Q_INTERFACES)\s*\([^()]*(?:\([^()]*\)[^()]*)*\)"
    r"|(?<=\bpublic )\b(?:slots|Q_SLOTS)\b|(?<=\bprotected )\b(?:slots|Q_SLOTS)\b|(?<=\bprivate )\b(?:slots|Q_SLOTS)\b")


def qt_neutralize(text: str) -> str:
    """tree-sitter ne connaît pas les macros Qt (emit, slots, signals, Q_OBJECT...) : on les neutralise SANS décaler lignes ni colonnes."""
    text = _QT_MACROS.sub(_BLANK, text)
    text = re.sub(r"\bsignals(?=\s*:)", "public ", text)
    text = re.sub(r"\bQ_SIGNALS(?=\s*:)", "public   ", text)
    text = re.sub(r"(?m)^(\s*)(?:slots|Q_SLOTS)(\s*:)", lambda m: m.group(1) + "public" + m.group(2), text)
    return text


def _text(n: Node, src: bytes) -> str:
    return src[n.start_byte:n.end_byte].decode("utf-8", "replace")


def parse_errors(text: str) -> int:
    root = _PARSER.parse(qt_neutralize(text).encode("utf-8", "replace")).root_node
    count, stack = 0, [root]
    while stack:
        n = stack.pop()
        if n.type == "ERROR" or n.is_missing:
            count += 1
        stack.extend(n.children)
    return count


def _func_name(decl: Node | None, src: bytes) -> str | None:
    while decl is not None and decl.type in {"pointer_declarator", "reference_declarator", "parenthesized_declarator"}:
        decl = decl.child_by_field_name("declarator") or (decl.children[-1] if decl.children else None)
    if decl is None or decl.type != "function_declarator":
        return None
    inner = decl.child_by_field_name("declarator")
    return _text(inner, src).strip() if inner is not None else None


def definitions(text: str) -> list[tuple[str, int, int]]:
    """[(nom qualifié, ligne début, ligne fin)] des fonctions (y compris inline dans une classe) et des classes."""
    src = qt_neutralize(text).encode("utf-8", "replace")
    out: list[tuple[str, int, int]] = []

    def walk(n: Node, cls: list[str]) -> None:
        t = n.type
        if t in {"class_specifier", "struct_specifier"}:
            name, body = n.child_by_field_name("name"), n.child_by_field_name("body")
            if name is not None and body is not None:
                nm = _text(name, src)
                out.append((nm, n.start_point[0] + 1, n.end_point[0] + 1))
                for c in n.children:
                    walk(c, cls + [nm])
                return
        elif t == "function_definition":
            nm = _func_name(n.child_by_field_name("declarator"), src)
            if nm:
                q = f"{cls[-1]}::{nm}" if cls and "::" not in nm else nm
                out.append((q, n.start_point[0] + 1, n.end_point[0] + 1))
            return
        for c in n.children:
            walk(c, cls)

    walk(_PARSER.parse(src).root_node, [])
    return out


# ======================================================================= périmètre autorisé
def allowed_regions(text: str, change: PlanFile, slack: int) -> list[tuple[int, int]]:
    """Zones (lignes, 1-based inclusives) que le plan autorise à modifier : symboles nommés + line_hint, avec marge."""
    regions: list[tuple[int, int]] = []
    if language_of(change.path) != "cpp":              # .ui, CMake, JS... : pas de symboles C++ ; une occurrence textuelle du nom ouvre une zone
        lines = text.split("\n")
        for sym in change.symbols:
            key = sym.strip().rstrip("()")
            if key:
                regions += [(i, i) for i, ln in enumerate(lines, 1) if key in ln]
        m = re.fullmatch(r"\s*(\d+)\s*-\s*(\d+)\s*", change.line_hint or "")
        if m:
            regions.append((int(m.group(1)), int(m.group(2))))
        return [(max(1, a - slack), min(len(lines), b + slack)) for a, b in regions]
    defs = definitions(text)
    for sym in change.symbols:
        sym = sym.strip().rstrip("()")
        last = sym.split("::")[-1]
        for name, a, b in defs:
            if name == sym or name.endswith("::" + sym) or (name.split("::")[-1] == last and "::" not in sym):
                regions.append((a, b))
    m = re.fullmatch(r"\s*(\d+)\s*-\s*(\d+)\s*", change.line_hint or "")
    if m:
        regions.append((int(m.group(1)), int(m.group(2))))
    nlines = text.count("\n") + 1
    return [(max(1, a - slack), min(nlines, b + slack)) for a, b in regions]


_SAFE_ADD = re.compile(r"^\s*(#\s*(include|pragma|ifn?def|define|endif|if|else)\b.*|(class|struct)\s+\w+\s*;|using\s+namespace\s+[\w:]+\s*;|)$")


def _opcodes(old: str, new: str):
    a, b = old.split("\n"), new.split("\n")
    return a, b, [op for op in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes() if op[0] != "equal"]


@dataclass
class DiffStats:
    added: int
    removed: int
    hunks: int


def diff_stats(old: str, new: str) -> DiffStats:
    _, _, ops = _opcodes(old, new)
    return DiffStats(sum(j2 - j1 for t, i1, i2, j1, j2 in ops if t in ("replace", "insert")),
                     sum(i2 - i1 for t, i1, i2, j1, j2 in ops if t in ("replace", "delete")), len(ops))


def scope_check(path: str, old: str, new: str, regions: list[tuple[int, int]]) -> list[Issue]:
    if not regions:
        return [Issue(severity="warning", code="unscoped_change", path=path,
                      message="The plan gives no resolvable symbol/line range for this file: scope could not be verified.")]
    a, b, ops = _opcodes(old, new)
    issues = []
    for t, i1, i2, j1, j2 in ops:
        added = b[j1:j2]
        if t == "insert" and all(_SAFE_ADD.match(x) for x in added):
            continue                                               # #include / déclaration anticipée : toujours permis
        lo, hi = (i1, i1 + 1) if t == "insert" else (i1 + 1, i2)   # lignes de l'original touchées (insert : la ligne avant/après)
        if not any(r0 <= lo and hi <= r1 + 1 for r0, r1 in regions):
            issues.append(Issue(severity="error", code="edit_outside_scope", path=path, line=max(lo, 1),
                                message=f"Change around original line {lo} is outside the zones allowed by the plan "
                                        f"(lines {', '.join(f'{r0}-{r1}' for r0, r1 in regions[:5])}). Only touch the symbols/lines named in the plan."))
    return issues


# ======================================================================= suppression / taille / syntaxe
def deletion_guard(cfg: Settings, path: str, old: str, new: str) -> list[Issue]:
    st = diff_stats(old, new)
    out = []
    if st.removed > cfg.max_removed_lines or (st.removed >= 12 and st.removed > 3 * st.added + 3):
        out.append(Issue(severity="error", code="too_much_deleted", path=path,
                         message=f"{st.removed} lines removed for {st.added} added: a surgical fix must not delete unrelated code. "
                                 "Replace only the lines that must change."))
    if st.added + st.removed > cfg.max_changed_lines:
        out.append(Issue(severity="error", code="diff_too_large", path=path,
                         message=f"{st.added + st.removed} changed lines exceed the limit ({cfg.max_changed_lines}). Reduce the change."))
    return out


def _strip_code(text: str) -> str:
    return re.sub(r"//[^\n]*|/\*.*?\*/|\"(?:\\.|[^\"\\\n])*\"|'(?:\\.|[^'\\\n])*'", "", text, flags=re.S)


def _xml_ok(text: str) -> bool:
    try:
        ET.fromstring(text.encode("utf-8", "surrogateescape"))
        return True
    except ET.ParseError:
        return False


def _balance(text: str, pairs: tuple[tuple[str, str, str], ...]) -> dict[str, int]:
    return {nm: text.count(o) - text.count(c) for o, c, nm in pairs}


def syntax_check(path: str, old: str, new: str) -> list[Issue]:
    lang = language_of(path)
    if lang == "xml":                                  # .ui / .qrc / .ts : bien formé (si l'original l'était, ou s'il s'agit d'un nouveau fichier)
        if (not old.strip() or _xml_ok(old)) and not _xml_ok(new):
            return [Issue(severity="error", code="xml_not_well_formed", path=path,
                          message="The change makes this XML file (.ui/.qrc/.ts) not well-formed: check tags, quotes and escaping (&amp; &lt;).")]
        return []
    if lang in {"cmake", "js"}:                        # pas de grammaire ici : équilibre des parenthèses/accolades uniquement
        strip = (lambda t: re.sub(r"#[^\n]*", "", t)) if lang == "cmake" else _strip_code
        pairs = (("(", ")", "parentheses"),) if lang == "cmake" else (("{", "}", "braces"), ("(", ")", "parentheses"), ("[", "]", "brackets"))
        a, b = _balance(strip(old), pairs), _balance(strip(new), pairs)
        return [Issue(severity="error", code="unbalanced_" + nm, path=path, message=f"Unbalanced {nm} after the change.") for nm in b if b[nm] != a.get(nm, 0)]
    if lang != "cpp":
        return []
    out = []
    e0, e1 = parse_errors(old), parse_errors(new)
    if e1 > e0:
        out.append(Issue(severity="error", code="syntax_error", path=path,
                         message=f"The change introduces {e1 - e0} syntax error(s) (parser errors: {e0} -> {e1}). Check braces, semicolons, parentheses."))
    a, b = _strip_code(old), _strip_code(new)
    for o, c, nm in (("{", "}", "braces"), ("(", ")", "parentheses"), ("[", "]", "brackets")):
        if (b.count(o) - b.count(c)) != (a.count(o) - a.count(c)):
            out.append(Issue(severity="error", code="unbalanced_" + nm, path=path,
                             message=f"Unbalanced {nm} after the change (the original file was balanced the same way)."))
    return out


# ======================================================================= API Qt publique (slots, signaux, scripts)
_SECTION = re.compile(r"^(?:(public|protected|private)\s+)?(slots|Q_SLOTS|signals|Q_SIGNALS)\s*:")
_ACCESS = re.compile(r"^(public|protected|private)(?:\s+(slots|Q_SLOTS))?\s*:")
_MARK = re.compile(r"\bQ_INVOKABLE\b|\bQ_PROPERTY\b|\bQ_CLASSINFO\b|\bQ_ENUMS?\b|\bQ_FLAGS\b")


def qt_api_lines(text: str) -> set[int]:
    """Lignes (1-based) qui forment l'API publique : slots publics, signaux, Q_INVOKABLE, Q_PROPERTY, Q_CLASSINFO (D-Bus)."""
    api: set[int] = set()
    in_api = False
    for i, ln in enumerate(text.split("\n"), 1):
        s = ln.strip()
        m = _SECTION.match(s)
        if m:
            in_api = m.group(2) in {"signals", "Q_SIGNALS"} or m.group(1) in (None, "public")
            continue
        m = _ACCESS.match(s)
        if m:
            in_api = bool(m.group(2)) and m.group(1) == "public"
            continue
        if s.startswith("}"):
            in_api = False
        if in_api and s and not s.startswith(("//", "/*", "*")):
            api.add(i)
        if _MARK.search(s):
            api.add(i)
    return api


def public_api_check(path: str, old: str, new: str, strict: bool) -> list[Issue]:
    if language_of(path) != "cpp":
        return []
    api = qt_api_lines(old)
    if not api:
        return []
    a, _, ops = _opcodes(old, new)
    out = []
    for t, i1, i2, *_ in ops:
        if t in ("replace", "delete") and any((i1 + 1) <= ln <= i2 for ln in api):
            touched = [ln for ln in sorted(api) if i1 + 1 <= ln <= i2][:3]
            out.append(Issue(severity="error" if strict else "warning", code="public_api_touched", path=path, line=touched[0],
                             message="This change modifies/removes a public slot, signal, Q_INVOKABLE, Q_PROPERTY or D-Bus declaration "
                                     f"(original lines {touched}): scripts or the D-Bus peer may break. Add new members instead of changing existing ones."))
    return out


# ======================================================================= avertissements Qt/C++ (non bloquants)
QT_HEADERS = {"QMutex": "QMutex", "QMutexLocker": "QMutex", "QReadWriteLock": "QReadWriteLock", "QReadLocker": "QReadWriteLock",
              "QWriteLocker": "QReadWriteLock", "QTimer": "QTimer", "QThread": "QThread", "QPointer": "QPointer",
              "QElapsedTimer": "QElapsedTimer", "QDebug": "QDebug", "QScopedPointer": "QScopedPointer", "QSharedPointer": "QSharedPointer",
              "QAtomicInt": "QAtomicInt", "QMetaObject": "QMetaObject", "QCoreApplication": "QCoreApplication",
              "QWaitCondition": "QWaitCondition", "QTime": "QTime", "QDateTime": "QDateTime", "QFile": "QFile", "QDir": "QDir"}


def added_text(old: str, new: str) -> str:
    _, b, ops = _opcodes(old, new)
    return "\n".join("\n".join(b[j1:j2]) for t, i1, i2, j1, j2 in ops if t in ("replace", "insert"))


def soft_checks(path: str, old: str, new: str, sibling_header: str | None) -> list[Issue]:
    if language_of(path) != "cpp":
        return []
    out = []
    add = added_text(old, new)
    for ident in sorted(set(re.findall(r"\bQ[A-Z]\w+", add)) & set(QT_HEADERS)):
        hdr = QT_HEADERS[ident]
        if not re.search(rf"#\s*include\s*[<\"](?:Qt\w+/)?{hdr}[>\"]", new):
            out.append(Issue(severity="warning", code="possibly_missing_include", path=path,
                             message=f"{ident} is used by the change but #include <{hdr}> is not in this file (it may come transitively from a project header)."))
    old_defs = {n for n, *_ in definitions(old)}
    for name, a, b in definitions(new):
        if name not in old_defs and "::" in name and sibling_header is not None:
            member = name.split("::")[-1]
            if not re.search(rf"\b{re.escape(member)}\s*\(", sibling_header):
                out.append(Issue(severity="warning", code="definition_without_declaration", path=path, line=a,
                                 message=f"New definition {name} but no declaration of '{member}(' found in the sibling header: add it to the class."))
    return out
