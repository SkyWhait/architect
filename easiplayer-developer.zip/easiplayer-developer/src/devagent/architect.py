"""Connexion à l'Agent Architecte (routes /kb/*) — FACULTATIVE : sans lui, le Développeur fonctionne exactement comme avant.

Rôle : éviter les « API inventées » (première cause d'erreurs de compilation d'un LLM). Le plan cite des types (``GmtTime``, ``InfoData``…)
qui ne sont pas définis dans le fichier à modifier ; l'Architecte sait OÙ ils sont déclarés. Le Développeur lui demande seulement
l'emplacement (``/kb/symbol``), puis lit la déclaration dans le DÉPÔT GIT à ``DEV_BASE_REF`` (``git show``) : l'index de l'Architecte peut
dater d'un autre commit, le code du dépôt est la seule vérité. Une déclaration introuvable ou qui ne contient plus le nom est écartée.

Contrat utilisé (réponse JSON de l'Architecte) : ``GET /kb/symbol?name=X`` -> ``[{path, kind, name, bases, line_start, line_end}]`` ;
``path`` est relatif à la racine « monde », comme les chemins du plan.
"""
from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass, field
from pathlib import PurePosixPath
from typing import Protocol

import httpx

from .config import Settings
from .llm import count_tokens, truncate_tokens
from .models import Issue, PlanFile
from .view import numbered
from .workspace import Workspace, WorkspaceError

log = logging.getLogger("devagent.architect")


class ArchitectUnavailable(RuntimeError):
    pass


class ArchitectLike(Protocol):
    async def find_symbol(self, name: str) -> list[dict]: ...
    async def aclose(self) -> None: ...


class HttpArchitect:
    def __init__(self, base_url: str, token: str | None = None, timeout: float = 20.0, retries: int = 1,
                 transport: httpx.AsyncBaseTransport | None = None):
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        self._c = httpx.AsyncClient(base_url=base_url.rstrip("/"), headers=headers, timeout=timeout, transport=transport)
        self._retries = retries

    async def _get(self, url: str, **params):
        last: Exception | None = None
        for attempt in range(self._retries + 1):
            try:
                r = await self._c.get(url, params={k: v for k, v in params.items() if v not in (None, "")})
                if r.status_code == 404:
                    return None
                if r.status_code >= 500:
                    raise httpx.HTTPStatusError(str(r.status_code), request=r.request, response=r)
                r.raise_for_status()
                return r
            except (httpx.TransportError, httpx.HTTPStatusError) as e:
                last = e
                await asyncio.sleep(1.0 * (attempt + 1))
        raise ArchitectUnavailable(f"GET {url} : {last}")

    async def find_symbol(self, name: str) -> list[dict]:
        r = await self._get("/kb/symbol", name=name)
        return [] if r is None else r.json()

    async def index_status(self) -> dict:
        r = await self._get("/index/status")
        return {} if r is None else r.json()

    async def aclose(self) -> None:
        await self._c.aclose()


def make_architect(cfg: Settings) -> HttpArchitect | None:
    if not cfg.architect_url:
        return None
    return HttpArchitect(cfg.architect_url, cfg.architect_token, cfg.architect_timeout_s)


# ======================================================================= quels types chercher ?
_CAMEL = re.compile(r"\b[A-Z][a-z0-9]+(?:[A-Z][A-Za-z0-9]*)+\b")          # GmtTime, InfoData, TestCheckValue (au moins deux « mots »)
_QT = re.compile(r"^Q[A-Z]")


def candidate_types(pf: PlanFile, extra_texts: list[str], defined_in_file: set[str], limit: int) -> list[str]:
    """Types à localiser : classes des symboles du plan (pour un .cpp, la déclaration de sa classe est dans l'en-tête), puis types cités dans le texte
    du plan ; hors Qt et hors types déjà définis dans le fichier, par ordre d'apparition."""
    seen: list[str] = []

    def add(w: str) -> None:
        if w and not _QT.match(w) and w not in defined_in_file and w not in seen:
            seen.append(w)

    for s in pf.symbols:
        parts = s.strip().rstrip("()").split("::")
        if len(parts) > 1:
            add(parts[-2])
        elif parts[0][:1].isupper():
            add(parts[0])
    for t in [pf.logic_change, pf.rationale, *extra_texts]:
        for w in _CAMEL.findall(t or ""):
            add(w)
    return seen[:limit]


@dataclass
class Facts:
    text: str = "(none)"
    used: list[str] = field(default_factory=list)          # "GmtTime -> EasiPlayer/…/GmtTime.h:12-48"
    issues: list[Issue] = field(default_factory=list)


def _defined_names(text: str) -> set[str]:
    return set(re.findall(r"\b(?:class|struct|enum(?:\s+class)?|typedef\s+\w+|using)\s+([A-Za-z_]\w*)", text))


async def build_facts(cfg: Settings, ws: Workspace, arch: ArchitectLike | None, pf: PlanFile, file_text: str, extra_texts: list[str]) -> Facts:
    """Déclarations (lecture seule) des types du plan définis ailleurs, pour que le LLM n'invente ni méthode ni signature."""
    if arch is None or pf.change_type == "remove":
        return Facts()
    names = candidate_types(pf, extra_texts, _defined_names(file_text), cfg.facts_max_symbols)
    if not names:
        return Facts()
    facts = Facts()
    chunks: list[str] = []
    budget = cfg.facts_budget_tokens
    for name in names:
        try:
            rows = await arch.find_symbol(name)
        except ArchitectUnavailable as e:
            facts.issues.append(Issue(severity="warning", code="architect_unavailable", message=f"Architect unreachable: API facts skipped ({str(e)[:160]})"))
            break
        rows = [r for r in rows if r.get("kind") in {"class", "struct"} and str(r.get("name", "")).split("::")[-1] == name]
        rows.sort(key=lambda r: (not str(r.get("path", "")).lower().endswith((".h", ".hpp", ".hh", ".hxx")), str(r.get("path", ""))))   # en-tête d'abord
        if not rows:
            continue
        r = rows[0]
        try:
            src = ws.read_at_base(str(r["path"]))
            a, b = int(r.get("line_start") or 0), int(r.get("line_end") or 0)
        except (WorkspaceError, KeyError, ValueError, TypeError):
            continue
        if src is None or a < 1:
            facts.issues.append(Issue(severity="info", code="stale_index", message=f"Architect knows {name} at {r.get('path')}, but the file is not in {cfg.base_ref}: ignored."))
            continue
        lines = src.replace("\r\n", "\n").split("\n")
        b = min(max(b, a), len(lines), a + 70)                              # une déclaration de classe : 70 lignes au plus
        if not any(re.search(rf"\b{re.escape(name)}\b", ln) for ln in lines[a - 1:min(len(lines), a + 2)]):
            facts.issues.append(Issue(severity="info", code="stale_index", message=f"{name} is no longer declared at {r['path']}:{a} (index older than {cfg.base_ref}): ignored."))
            continue
        chunk = f"// {r['path']} lines {a}-{b}  (read-only; do not modify)\n{numbered(lines, a, b)}"
        t = count_tokens(chunk)
        if t > budget:
            if budget < 200:
                break
            chunk = truncate_tokens(chunk, budget)
            t = budget
        budget -= t
        chunks.append(chunk)
        facts.used.append(f"{name} -> {r['path']}:{a}-{b}")
    if chunks:
        facts.text = "\n\n".join(chunks)
    return facts
