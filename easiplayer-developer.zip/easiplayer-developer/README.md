# EasiPlayer Developer v0.2 — l'agent qui modifie le code

Applique un **plan approuvé du Stratège** (`plan.json`) en modifications C++/Qt5 **chirurgicales**, dans un **worktree git isolé**, et
rend un **diff** + un rapport. Il ne décide de rien : il exécute le plan, ou explique pourquoi il ne peut pas.

## Ce qui le rend sûr

| Garde-fou | Comment |
|---|---|
| **Jamais ton arbre de travail** | tout se passe dans un `git worktree` (branche `agent/<ticket>`, depuis `DEV_BASE_REF`). Tes fichiers, tes modifications non commitées et ta branche ne sont pas touchés. Pas de push. Hooks git désactivés. |
| **Tout ou rien** | rien n'est écrit tant que **tous** les fichiers du plan ne sont pas acceptés. Un échec => aucun fichier modifié, worktree et branche supprimés, diff *proposé* à relire. |
| **Pas de réécriture de fichier** | le LLM désigne un extrait existant (`anchor`) et dit quoi en faire (replace / insert_after / insert_before / delete). L'ancre doit être **unique** (tolérance à l'indentation, désambiguïsation par `near_line`). Le reste du fichier reste identique **octet pour octet** : fins de ligne CRLF, tabulations, latin-1, dernière ligne. |
| **Périmètre** | chaque modification doit tomber dans les symboles / `line_hint` du plan (tree-sitter). Seuls `#include` et déclarations anticipées sont permis ailleurs. |
| **Pas de suppression abusive** | limites de lignes supprimées / modifiées, ratio suppression/ajout. |
| **Syntaxe** | tree-sitter (macros Qt `emit`, `signals`, `slots`, `Q_OBJECT`… neutralisées) : le nombre d'erreurs ne doit pas augmenter ; équilibre `{ ( [` conservé. |
| **API publique Qt** | modifier/supprimer un slot public, signal, `Q_INVOKABLE`, `Q_PROPERTY`, `Q_CLASSINFO` est **refusé** quand le plan signale une exposition JavaScript ou D-Bus (ajouter est permis). |
| **Chemins** | `..`, absolu, `.git`, fichiers secrets (`.env`, `*.pem`…), fichiers générés (`moc_/ui_/qrc_`), liens symboliques sortants : refusés. Écriture seulement dans les fichiers **listés par le plan**. |
| **Entrée** | seul `status = ready` est exécuté ; `needs_review` exige `--approve` ; suppression de fichier exige `--allow-remove`. |
| **Pas de shell pour le LLM** | il n'émet que des éditions typées. La compilation optionnelle utilise **ta** commande de config. |

Chaque rejet est **renvoyé au LLM avec le motif précis** (ancre introuvable + lignes proches, hors périmètre, syntaxe, API touchée…),
3 essais par fichier. Si le plan ne correspond pas au code, le LLM répond `cannot_apply` et on s'arrête : **jamais d'improvisation**.

## Pipeline (LangGraph)

```
prepare ─► edit ⟲ (.h puis .cpp ; le .cpp voit le diff déjà fait sur le .h) ─► apply (écriture atomique + git add)
        ─► [build ⟲ fix (erreurs du compilateur renvoyées au LLM, 2 tours)] ─► finalize (diff, commit sur la branche agent, rapport)
```

## Nouveautés de la V2 (conventions réelles + connexion à la chaîne)

| Domaine | Ce qui change |
|---|---|
| **C++11 strict** | refus (erreur renvoyée au LLM) de `std::make_unique`, lambdas génériques / init-capture, `auto` sans `-> T`, `std::optional/string_view/…`, structured bindings, `if constexpr`, littéraux `0b`/`1'000`… sur les **seules lignes ajoutées**. La table est confrontée au **vrai g++ `-std=c++11 -pedantic-errors`** dans les tests. |
| **Qt 5.9 ET 5.15** | refus des API Qt introduites après `DEV_QT_MIN_VERSION` (5.9) : `Qt::endl`, `Qt::SkipEmptyParts`, `QRandomGenerator`, `QStringView`, `QThread::create`… Table écrite d'après la doc Qt (« Since »), **non confrontée à des en-têtes 5.9**. |
| **connect()** | seule la forme `SIGNAL()/SLOT()` est acceptée (pointeur de membre et lambda refusés). `NULL`/`nullptr`, accolades Allman, 120 colonnes : avertissements. |
| **clang-format** | le `.clang-format` du projet est appliqué aux **seules lignes modifiées** (`--lines`), puis re-vérifié ; s'il fait échouer une vérification, la sortie brute est gardée. Validé : le vrai `.clang-format` laisse inchangé un vrai extrait de `TestCheck2Value.cpp` (`=` alignés, Allman). |
| **Zones interdites** | `build_*`, `install`, `redist` (n'importe quel composant du chemin, configurable `DEV_FORBIDDEN_DIRS`) + `moc_*`, `ui_*`, `qrc_*`. |
| **Fichiers non C++** | `.ui`/`.qrc`/`.ts` : bien-formé XML exigé ; `CMakeLists.txt` : parenthèses équilibrées ; plus de passage de XML dans tree-sitter. |
| **Commit** | `[EAP-12610][Sequencer]Titre` (sans espace, comme l'historique ; `DEV_COMMIT_SEPARATOR=" "` pour en mettre un). Catégories : General, Sequencer, Avatar import, NH90, NH90_AAP (sinon General + avertissement). **La référence EAP n'est pas déductible du ticket Mantis** : fournie via `--eap-ref` / `eap_ref`, sinon marqueur `EAP-TODO` + avertissement. Le numéro Mantis est dans le corps (`Mantis: 1739`). |
| **Suppression de fichier** | `change_type: remove` fonctionne vraiment (`git rm` dans le worktree) avec `--allow-remove` ; en v0.1 le drapeau existait mais rien n'était supprimé. |
| **Sources par GLOB** | l'ancien avertissement « fichier non compilé » était faux pour ce projet ; remplacé par `reconfigure_needed` + `build_hints.needs_reconfigure` : il faut **reconfigurer CMake**, un simple build ne voit pas le nouveau fichier. |

### Politique git
Une branche **locale** par ticket (`DEV_BRANCH_PREFIX` + ticket, ex. `fix/1739`) partant de `DEV_BASE_REF` (mettre `development`), dans un worktree isolé. L'agent ne pousse jamais, ne fusionne jamais, ne touche pas à ta branche courante (testé avec un remote nu : rien n'y arrive). Tu fusionnes la branche du ticket dans `development` à la main, puis `development` dans `main` quand tu le décides.

### Le rapport du Stratège dans la boucle
Le `plan.json` est conservé tel que reçu (`<DEV_WORK_DIR>/<ticket>/plan.json`) et **chaque tour de correction du build le revoit** : problème, cause racine, ce qui est prévu pour le fichier en erreur, ce qui est prévu ailleurs, risques. (En v0.1 les tours de correction ne voyaient que les erreurs du compilateur.)

### Retour de la QA (tests Squish en échec)
`POST /changes/<ticket>/fix_tests {feedback, round}` : le Développeur réexamine chaque fichier déjà modifié avec **le plan du Stratège, le retour de la QA (ce que le test vérifie, ce qui a échoué, quelles parties de sa modification y sont liées) et le diff de sa propre modification**. Éditions limitées aux zones qu'il a modifiées ou que le plan visait, mêmes vérifications (syntaxe, C++11/Qt 5.9, périmètre, clang-format), un commit `[EAP-…][Cat]Fix test failure (round N)`, rapport mis à jour (le Compilateur le relit). S'il estime que le fichier n'est pas en cause il le dit (`cannot_apply`) ; si aucun fichier ne peut corriger : `no_change` + raisons, et l'orchestrateur redemande un plan.

### Connexions

- **Stratège → Développeur** : `plan.json` (PlanDocument 1.x) tel quel ; testé avec le **vrai modèle** du Stratège. `plan.verification` (cibles, tests Squish) est maintenant relu et recopié dans le rapport.
- **Architecte → Développeur** (facultatif, `DEV_ARCHITECT_URL`) : pour les types cités par le plan et définis ailleurs (`GmtTime`…), l'Architecte (`GET /kb/symbol`) dit **où**, le Développeur lit la déclaration **dans le dépôt git à `DEV_BASE_REF`** (jamais l'index, qui peut dater d'un autre commit) et l'ajoute au prompt (« n'utilise que ces membres, sinon `cannot_apply` »). Index périmé, Architecte injoignable ou chemin interdit : on continue sans, avec un avertissement. Testé contre le **vrai Architecte** en mémoire.
- **Développeur → Compilateur** : inchangé (`POST /changes/<ticket>/fix`) ; le rapport ajoute `build_hints` (`changed_files`, `new_files`, `needs_reconfigure`, `build_targets`) et le commit de correction reprend le préfixe `[EAP-…][Cat]`. Champs **additifs** ; `schema_version` reste `1.0` pour ne pas casser un lecteur strict que je n'ai pas pu voir (voir « Limites »).
- **Développeur → QA** : `build_hints.squish_tests` / `manual_checks` (tests ciblés cités par le Stratège — heuristique, pas une garantie).
- **Développeur → Stratège** (boucle QA/échec) : `feedback_for_strategist` = faits observés (fichier, symboles, « CANNOT APPLY », rejets) à joindre à une **nouvelle** demande de plan. Le Stratège n'a pas de champ typé pour ça : c'est du texte.
- **Orchestrateur** : `POST /changes` accepte `eap_ref`, `restart` (nouvelle tentative : supprime ancien worktree/branche/rapports), `base_ref` (empiler un 2e plan sur la branche d'une tentative précédente), et `approve_review` (validation humaine d'un plan `needs_review`). `audit.jsonl` (dans `DEV_WORK_DIR`) : une ligne par `apply_start`/`apply_done`/`fix`/`clean` — identifiants, empreinte du plan, statut, **jamais de code**. Zéro push, zéro merge.

## Utilisation

```bash
pip install -e ".[dev]" && cp .env.example .env     # DEV_WORLD_ROOT = dossier qui contient EasiPlayer/, EasiPlayerDbusDaemon/...
pytest                                              # 87 tests (dont g++ -std=c++11, clang-format, Architecte et Stratège réels si installés), sans GPU
devagent doctor                                      # pré-vol : dépôts, clang-format, LLM json_schema, Architecte (ne modifie rien)
devagent apply --plan plans/1739/plan.json --eap-ref EAP-12610   # plan du Stratège
devagent serve --port 8820                          # POST /changes, GET /changes/<id>[/diff|/report], DELETE /changes/<id>
devagent clean D0002312 --drop-branch               # supprime worktrees (et branche)
```

Les chemins du plan (`EasiPlayer/core/runner.cpp`) sont relatifs à `DEV_WORLD_ROOT` : le 1er composant est le dépôt git, le reste le chemin dedans.
Sorties dans `DEV_WORK_DIR/<ticket>/` : `dev_report.json` (schéma : `devagent schema`), `dev_report.md`, `changes.diff` (ou `proposed.diff`), `worktrees/`.

**Compilation (recommandée)** : sans `DEV_BUILD_COMMAND`, seule la syntaxe est vérifiée (avertissement `build_not_verified`). Avec :
`["bash","-lc","cmake -S {worktree:EasiPlayer} -B {build_dir} && cmake --build {build_dir} -j8"]`, les erreurs gcc/clang des fichiers du plan sont
renvoyées au LLM ; si ça ne compile toujours pas, **tout est annulé**. La première configuration CMake d'un nouveau worktree peut être longue.

## Boucle de correction avec le Compilateur

`POST /changes/<ticket>/fix` (ou `devagent`/`apply_fix`) reçoit les diagnostics du Compilateur et corrige le worktree **déjà appliqué** : mêmes
garde-fous (éditions typées, syntaxe, suppression, périmètre = lignes en erreur ±`DEV_SCOPE_SLACK_LINES`), seuls les fichiers du plan sont modifiables,
les en-têtes suggérés par le Compilateur sont traités d'abord, un **commit par tour** (`fix build (round N)`), `dev_report.json` et `changes.diff` mis à jour
(diff total depuis la base). Un fichier qui ne peut pas être corrigé n'est pas modifié ; si rien ne l'est, le résultat est `no_change` avec la raison.

## Contrat avec le Stratège

Entrée : le `plan.json` (`PlanDocument` v1.x) tel quel ; seuls les champs utiles sont lus (`extra=ignore`). Un exemple réel généré par le Stratège est dans
`tests/fixtures/sample_plan.json`. Sortie : `DevReport` (statuts `applied` · `needs_review` · `failed` · `rejected`), entrée prévue du Testeur.

## Limites connues

- Testé avec un **LLM scripté** sur un mini-projet Qt et de vrais dépôts git ; **jamais avec Qwen sur EasiPlayer**. La qualité des éditions dépendra du modèle ; les garde-fous garantissent qu'une mauvaise édition est refusée, pas qu'une édition acceptée corrige le bug.
- Sans compilation, une erreur de typage ou un symbole inexistant peut passer (tree-sitter ne fait que la syntaxe).
- Le worktree part de `DEV_BASE_REF` (HEAD par défaut) : les modifications non commitées de ton arbre ne sont pas incluses.
- Premier essai conseillé : sur une **copie** du dépôt, avec un ticket simple, en lisant `dev_report.md`.
- **Compilateur et QA non vus** : leurs archives n'ont pas été fournies pour cette session. Le contrat `POST /changes/<id>/fix {diagnostics}` est celui de la v0.1 (déjà aligné sur le `Diagnostic` du Compilateur), mais je n'ai **pas** vérifié que le Compilateur accepte les nouveaux champs du rapport (`build_hints`, `commit_subject`, `feedback_for_strategist`) : s'il valide `DevReport` avec `extra=forbid` ou compare `schema_version == "1.0"`, c'est le seul endroit à regarder.
- **Table des API Qt** : d'après la doc Qt, pas confrontée à des en-têtes Qt 5.9. Si un faux positif/négatif apparaît, la table est `_QT_NEWER` dans `conventions.py`.
- **Référence EAP** : jamais déduite. Sans `eap_ref`, le commit porte `[EAP-TODO]` (à remplacer avant fusion).
- **clang-format** : testé avec la version 23 ; la version installée chez toi peut formater autrement à la marge (seules les lignes modifiées sont concernées, et le résultat est re-vérifié).
- `eap_mercurial_tag_version()` apparaît dans le `CMakeLists.txt` racine : dans un worktree git, vérifier que la configuration CMake (rôle du Compilateur) s'y comporte comme dans `build_player`.
