"""Contrat Stratège -> Développeur avec le VRAI modèle `PlanDocument` du Stratège (ignoré si le paquet `stratege` n'est pas installé)."""
from __future__ import annotations

import pytest

from conftest import CPP, CPP_OK, H, HEADER_OK, FakeLLM
from devagent.agent import DevAgent
from devagent.models import PlanInput

st = pytest.importorskip("stratege.models")


def real_plan_document() -> "st.PlanDocument":
    fc = lambda path, syms, hint, logic: st.FileChange(path=path, change_type="modify", symbols=syms, line_hint=hint, rationale="Both entry points emit finished", logic_change=logic)
    plan = st.ActionPlan(
        classification="bug", root_cause="finished is emitted twice", confidence="high",
        files_to_modify=[fc("EasiPlayer/core/runner.cpp", ["Runner::abort", "Runner::start"], "10-24", "Add an m_aborted guard so finished is emitted exactly once per run."),
                         fc("EasiPlayer/core/runner.h", ["Runner"], "5-20", "Declare the private bool m_aborted initialised to false.")],
        read_only_files=[], steps=[st.Step(order=1, title="Guard", description="Add guard", files=["EasiPlayer/core/runner.cpp"], verification="build")],
        risks=[st.Risk(description="Script API", area="script_api", severity="medium", mitigation="keep slots")],
        verification=st.Verification(squish_tests=["EasiPlayerSquishTests/suite_runner/tst_case1"], build_targets=["easicore"], manual_checks=[]),
        out_of_scope=[], assumptions=[], open_questions=[])
    return st.PlanDocument(ticket_id="1739", generated_at="2026-11-20T10:00:00", status="ready", ticket=st.Ticket(id="1739", title="Stop button: finished reported twice", category="Sequencer"),
                           plan=plan, validation=st.ValidationReport(auto_risks=[st.Risk(description="exposed to scripts", area="script_api", severity="high", mitigation="no rename")],
                                                                      cross_process={"script_api": ["runner (Runner)"]}))


def test_every_field_the_developer_reads_exists_in_the_real_plan_schema():
    doc = real_plan_document()
    inp = PlanInput.model_validate_json(doc.model_dump_json())                          # le JSON réel du Stratège, tel quel
    assert inp.status == "ready" and inp.ticket["category"] == "Sequencer" and inp.plan.verification.build_targets == ["easicore"]
    assert [f.path for f in inp.plan.files_to_modify] == ["EasiPlayer/core/runner.cpp", "EasiPlayer/core/runner.h"]


def test_status_values_of_the_strategist_are_all_understood():
    from typing import get_args
    values = set(get_args(st.PlanDocument.model_fields["status"].annotation))
    assert values == {"ready", "needs_info", "needs_review", "failed"}                  # si le Stratège ajoute un statut, ce test le signale


async def test_a_real_strategist_plan_is_applied_end_to_end(cfg, world):
    doc = real_plan_document()
    rep = await DevAgent(cfg, FakeLLM({H: HEADER_OK, CPP: CPP_OK})).apply(PlanInput.model_validate_json(doc.model_dump_json()), eap_ref="EAP-12610")
    assert rep.status == "applied" and rep.commit_subject == "[EAP-12610][Sequencer]Stop button: finished reported twice"
    assert rep.build_hints.squish_tests == ["EasiPlayerSquishTests/suite_runner/tst_case1"]


async def test_needs_info_plan_is_not_executed(cfg, world):
    doc = real_plan_document().model_copy(update={"status": "needs_info", "status_reason": "missing steps"})
    rep = await DevAgent(cfg, FakeLLM({})).apply(PlanInput.model_validate_json(doc.model_dump_json()))
    assert rep.status == "rejected" and "needs_info" in rep.status_reason
