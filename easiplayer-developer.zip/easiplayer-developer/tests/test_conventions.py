"""Conventions réelles : la table « C++11 » est confrontée au VRAI g++ (-std=c++11 -pedantic-errors) ; le reste est testé sur des lignes ajoutées."""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path

import pytest

from devagent.config import Settings
from devagent.conventions import (clean_title, commit_prefix, conventions_check, cxx11_check, normalize_category, qt_version_check)
from devagent.cpp_checks import language_of, syntax_check
from devagent.models import PlanFile
from devagent.workspace import Workspace, WorkspaceError

HAS_GXX = shutil.which("g++") is not None

# (corps de fonction, refusé par le contrôle ?, en-têtes utiles, le compilateur le rejette-t-il en C++11 ?)
CASES = [
    ("auto p = std::make_unique<int>(3);", True, "#include <memory>", True),
    ("auto f = [](auto x) { return x; }; (void)f(1);", True, "", True),
    ("int y = 2; auto f = [z = y]() { return z; }; (void)f();", True, "", True),
    ("auto f = [](int x) { return x; }; (void)f(1);", False, "", False),
    ("int y = 2; auto f = [y]() { return y; }; (void)f();", False, "", False),
    ("int y = 2; auto f = [=]() { return y; }; (void)f();", False, "", False),
    ("int a[3] = {0}; a[1] = 2; (void)a;", False, "", False),
    ("int v = 0b101; (void)v;", True, "", True),
    ("int v = 1'000; (void)v;", True, "", True),
    ("std::unique_ptr<int> p(new int(3)); (void)p;", False, "#include <memory>", False),
    ("std::size_t n = 3; (void)n;", False, "#include <cstddef>", False),
    ("int *p = nullptr; (void)p;", False, "", False),
    ("for (int i : {1, 2, 3}) { (void)i; }", False, "#include <initializer_list>", False),
    ("std::pair<int,int> pr(1,2); auto [a, b] = pr; (void)a; (void)b;", True, "#include <utility>", True),
    ("int n = 1; auto q = std::exchange(n, 2); (void)q;", True, "#include <utility>", True),
    ("if constexpr (true) { }", True, "", True),
]


@pytest.mark.skipif(not HAS_GXX, reason="g++ absent")
@pytest.mark.parametrize("body,flagged,pre,rejected_by_gxx", CASES)
def test_cxx11_table_agrees_with_real_gxx(body, flagged, pre, rejected_by_gxx):
    code = f"{pre}\nvoid t() {{ {body} }}\n"
    with tempfile.TemporaryDirectory() as d:
        f = Path(d) / "t.cpp"
        f.write_text(code)
        r = subprocess.run(["g++", "-std=c++11", "-pedantic-errors", "-fsyntax-only", str(f)], capture_output=True, text=True)
    assert (r.returncode != 0) == rejected_by_gxx, r.stderr[:300]          # la table de test elle-même est vraie
    assert bool(cxx11_check("x.cpp", "", body + "\n")) == flagged


def test_cxx11_attributes_are_flagged_even_if_gxx_is_tolerant():
    assert cxx11_check("x.h", "", "[[nodiscard]] int f();\n") and not cxx11_check("x.h", "", "[[noreturn]] void g();\n")


def test_only_added_lines_are_judged():
    old = "auto p = std::make_unique<int>(3);\nint x = 0;\n"            # code ancien non conforme : jamais jugé
    assert cxx11_check("x.cpp", old, old.replace("int x = 0;", "int x = 1;")) == []
    assert cxx11_check("x.cpp", old, old + "auto q = std::make_unique<int>(4);\n")


def test_comments_and_strings_are_not_code():
    assert cxx11_check("x.cpp", "", '// std::make_unique is C++14\nQString s = "std::optional";\n') == []


def test_qt_api_newer_than_5_9_is_rejected_and_configurable():
    new = 'QStringList l = s.split(",", Qt::SkipEmptyParts);\nstream << Qt::endl;\n'
    iss = qt_version_check("x.cpp", "", new, "5.9")
    assert {i.code for i in iss} == {"qt_api_too_new"} and len(iss) == 2
    assert qt_version_check("x.cpp", "", new, "5.15") == []                 # cible 5.15 seule : permis
    assert qt_version_check("x.cpp", "", "QTimer::singleShot(0, this, SLOT(go()));\nqAsConst(l);\n", "5.9") == []


def test_connect_must_be_string_based():
    ok = 'connect(mRunBt, SIGNAL(clicked()), this, SLOT(run()));\n'
    assert conventions_check("x.cpp", "", ok) == []
    for bad in ['connect(mRunBt, &QPushButton::clicked, this, &View::run);\n',
                'connect(mRunBt, SIGNAL(clicked()), [this]() { run(); });\n',
                'QObject::connect(a,\n    &A::sig,\n    b,\n    &B::slot);\n']:
        assert any(i.code == "connect_modern_syntax" for i in conventions_check("x.cpp", "", bad)), bad
    multi = 'connect(mRunBt,\n        SIGNAL(clicked()),\n        this,\n        SLOT(run()));\n'
    assert not any(i.code == "connect_modern_syntax" for i in conventions_check("x.cpp", "", multi))


def test_taste_checks_are_warnings_only():
    old = "a = NULL;\nb = NULL;\nc = NULL;\n"
    iss = conventions_check("x.cpp", old, old + "d = nullptr;\n")
    assert [i.code for i in iss] == ["nullptr_vs_NULL"] and iss[0].severity == "warning"
    iss = conventions_check("x.cpp", "", "if (x) {\n    y();\n}\n")
    assert [(i.code, i.severity) for i in iss] == [("brace_not_allman", "warning")]
    assert conventions_check("x.cpp", "", "auto f = [x]() {\n    y();\n};\nint a[] = {\n    1,\n};\n") == []       # lambda et initialiseur : pas Allman, et c'est normal
    assert conventions_check("x.cpp", "", "int " + "x" * 130 + " = 1;\n")[0].code == "line_too_long"


def test_commit_subject_helpers_follow_the_real_history():
    assert commit_prefix("EAP-12605", "General") == ("[EAP-12605][General]", False)
    assert commit_prefix(None, "Sequencer") == ("[EAP-TODO][Sequencer]", True)             # jamais de référence inventée
    assert commit_prefix("12605", "General")[1] is True                                    # format invalide : marqueur, pas de supposition
    assert normalize_category("avatar import") == ("Avatar import", False) and normalize_category("Script JS") == ("General", True)
    assert clean_title("[EAP 6.1.0] Delay parameter in EasiPlayer not working") == "Delay parameter in EasiPlayer not working"


def test_forbidden_zones(tmp_path):
    ws = Workspace(Settings(world_root=tmp_path, work_dir=tmp_path / "w"), "T")
    for bad in ["build_player/CMakeCache.txt", "install/share/x.h", "EasiPlayer/redist/lib/a.h", "EasiPlayer/build_x/a.cpp",
                "EasiPlayer/src/moc_Runner.cpp", "EasiPlayer/src/ui_main.h", "EasiPlayer/src/qrc_res.cpp", "EasiPlayer/.env"]:
        with pytest.raises(WorkspaceError):
            ws.parse(bad)
    for good in ["EasiPlayer/src/EasiPlayer/view/main.ui", "EasiPlayer/src/EasiPlayer/model/std/TestCheckValue.cpp", "EasiPlayer/src/XtpSign/CMakeLists.txt"]:
        assert ws.parse(good).repo == "EasiPlayer"


def test_non_cpp_files_get_their_own_syntax_check():
    ui = '<?xml version="1.0"?>\n<ui>\n <widget name="w"><string>Run</string></widget>\n</ui>\n'
    assert language_of("a/b.ui") == "xml" and language_of("a/CMakeLists.txt") == "cmake" and language_of("a/x.cpp") == "cpp"
    assert syntax_check("a.ui", ui, ui.replace("Run", "Run &amp; Stop")) == []
    assert syntax_check("a.ui", ui, ui.replace("Run", "Run & Stop"))[0].code == "xml_not_well_formed"
    assert syntax_check("CMakeLists.txt", "add_executable(x a.cpp)\n", "add_executable(x a.cpp\n")[0].code == "unbalanced_parentheses"
    assert syntax_check("a.ui", "", ui) == [] and syntax_check("a.ui", "", "<ui>")[0].code == "xml_not_well_formed"     # nouveau fichier : bien formé exigé
