from __future__ import annotations

import sys
import time

from fastapi.testclient import TestClient

from conftest import CPP, CPP_OK, FIX, H, HEADER_OK, EditSet, FakeLLM, e, git_out
from devagent.agent import DevAgent
from devagent.api import create_app

BUILD = [sys.executable, str(FIX / "fake_build.py"), "{worktree:EasiPlayer}"]
BROKEN = EditSet(summary="x", edits=CPP_OK.edits + [e("insert_after", "    m_step = i;", "        BROKEN_CALL();")])
FIX_EDIT = EditSet(summary="remove the call that does not exist", edits=[e("delete", "        BROKEN_CALL();")])


async def test_build_failure_is_fixed_from_compiler_output(cfg, world, plan):
    cfg.build_command = BUILD
    llm = FakeLLM({H: HEADER_OK, CPP: BROKEN}, fixes={CPP: FIX_EDIT})
    rep = await DevAgent(cfg, llm).apply(plan)
    assert rep.status == "applied", (rep.status_reason, rep.build)
    assert rep.build.ran and rep.build.ok and rep.build.rounds == 1
    fix_prompt = llm.prompts_for("fix", CPP)[0]
    assert "BROKEN_CALL" in fix_prompt and "was not declared" in fix_prompt                  # le LLM voit l'erreur du compilateur
    assert "BROKEN_CALL" not in rep.diff and "BROKEN_CALL" not in git_out(world / "EasiPlayer", "show", rep.commits["EasiPlayer"])
    assert "BROKEN_CALL" not in (open(rep.worktrees["EasiPlayer"] + "/core/runner.cpp").read())
    assert not [w for w in rep.warnings if w.code == "build_not_verified"]
    assert any(x.get("op") == "build_fix" for x in rep.files[1].edits)


async def test_unfixable_build_reverts_everything(cfg, world, plan):
    cfg.build_command = BUILD
    giveup = EditSet(summary="", edits=[], cannot_apply="I cannot see where BROKEN_CALL should come from.")
    rep = await DevAgent(cfg, FakeLLM({H: HEADER_OK, CPP: BROKEN}, fixes={CPP: giveup})).apply(plan)
    assert rep.status == "needs_review" and "compilation" in rep.status_reason.lower()
    assert not rep.diff_applied and "BROKEN_CALL" in rep.diff                                  # diff proposé pour comprendre
    assert git_out(world / "EasiPlayer", "branch", "--list", "agent/*").strip() == "" and rep.worktrees == {}
    assert git_out(world / "EasiPlayer", "status", "--porcelain").strip() == ""
    assert (cfg.work_dir / "D0002312" / "proposed.diff").exists()


def test_api_flow(cfg, world, plan):
    app = create_app(llm_factory=lambda: FakeLLM({H: HEADER_OK, CPP: CPP_OK}), settings=cfg)
    with TestClient(app) as c:
        body = {"plan": plan.model_dump()}
        assert c.post("/changes", json=body).status_code == 202
        for _ in range(100):
            st = c.get("/changes/D0002312").json()
            if st["state"] == "done":
                break
            time.sleep(0.05)
        assert st["status"] == "applied" and st["branches"]["EasiPlayer"] == "agent/D0002312"
        assert "+++ b/EasiPlayer/core/runner.h" in c.get("/changes/D0002312/diff").text
        assert "Rapport du Développeur" in c.get("/changes/D0002312/report").text
        assert c.get("/changes/D0002312?full=true").json()["report"]["files"][0]["path"] == H
        assert c.get("/changes/inconnu").status_code == 404
        assert c.delete("/changes/D0002312?drop_branch=true").json()["branch_dropped"] is True
        assert git_out(world / "EasiPlayer", "branch", "--list", "agent/*").strip() == ""


def test_api_token_and_validation(cfg, plan):
    cfg.api_token = "s3cret"
    with TestClient(create_app(llm_factory=lambda: FakeLLM(), settings=cfg)) as c:
        assert c.post("/changes", json={"plan": plan.model_dump()}).status_code == 401
        h = {"Authorization": "Bearer s3cret"}
        assert c.post("/changes", json={}, headers=h).status_code == 422
