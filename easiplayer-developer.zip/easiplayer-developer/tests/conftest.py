from __future__ import annotations

import json
import re
import shutil
import subprocess
from pathlib import Path

import pytest

from devagent.config import Settings
from devagent.models import Edit, EditSet, NewFile, PlanInput

FIX = Path(__file__).parent / "fixtures"
H, CPP = "EasiPlayer/core/runner.h", "EasiPlayer/core/runner.cpp"


def sh(*args, cwd=None) -> str:
    return subprocess.run(args, cwd=cwd, capture_output=True, text=True, check=True,
                          env={"GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t",
                                "PATH": "/usr/bin:/bin:/usr/local/bin", "HOME": "/tmp"}).stdout


def init_repos(world: Path) -> None:
    for repo in [p for p in world.iterdir() if p.is_dir()]:
        sh("git", "init", "-q", "-b", "main", cwd=repo)
        sh("git", "add", "-A", cwd=repo)
        sh("git", "commit", "-q", "-m", "init", cwd=repo)


@pytest.fixture
def world(tmp_path) -> Path:
    w = tmp_path / "world"
    shutil.copytree(FIX / "toyworld", w)
    init_repos(w)
    return w


@pytest.fixture
def cfg(tmp_path, world) -> Settings:
    return Settings(world_root=world, work_dir=tmp_path / "work", max_edit_attempts=3)


@pytest.fixture
def plan() -> PlanInput:
    return PlanInput.model_validate_json((FIX / "sample_plan.json").read_text())


def plan_with(plan: PlanInput, **over) -> PlanInput:
    return PlanInput.model_validate({**json.loads(plan.model_dump_json()), **over})


def with_files(plan: PlanInput, *changes: dict) -> PlanInput:
    d = json.loads(plan.model_dump_json())
    d["plan"]["files_to_modify"] = list(changes)
    return PlanInput.model_validate(d)


def e(op, anchor, new="", reason="plan", near=0) -> Edit:
    return Edit(op=op, anchor=anchor, new_text=new, reason=reason, near_line=near)


# --- éditions « correctes » pour le plan d'exemple (finished émis une seule fois) ---------------------------
HEADER_OK = EditSet(summary="Add m_aborted guard member", edits=[e("insert_after", "    bool m_running = false;", "    bool m_aborted = false;")])
CPP_OK = EditSet(summary="Guard the final finished emission", edits=[
    e("insert_after", "    m_running = true;", "    m_aborted = false;"),
    e("replace", "    emit finished(0);", "    if (!m_aborted)\n        emit finished(0);"),
    e("replace", "    m_running = false;\n    emit finished(-1);", "    m_running = false;\n    m_aborted = true;\n    emit finished(-1);")])


class FakeLLM:
    """Réponses scriptées par fichier : EDIT -> by_path[path], BUILDFIX -> fixes[path], NEWFILE -> new[path]."""

    def __init__(self, by_path=None, fixes=None, new=None, testfixes=None):
        self.by_path = {k: list(v) if isinstance(v, list) else [v] for k, v in (by_path or {}).items()}
        self.fixes = {k: list(v) if isinstance(v, list) else [v] for k, v in (fixes or {}).items()}
        self.new = {k: list(v) if isinstance(v, list) else [v] for k, v in (new or {}).items()}
        self.testfixes = {k: list(v) if isinstance(v, list) else [v] for k, v in (testfixes or {}).items()}
        self.prompts: list[tuple[str, str, str]] = []
        self.usage = {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0}

    async def json(self, system, user, schema, retries=3):
        if user.startswith("TASK: the build failed"):
            kind, path = "fix", re.search(r"Fix ONLY the compile errors caused by our changes in (\S+),", user).group(1)
            src = self.fixes
        elif user.startswith("TASK: the project builds, but the Squish"):
            kind, path, src = "testfix", re.search(r"Fix OUR change in (\S+) so", user).group(1), self.testfixes
        elif user.startswith("TASK: create the NEW file"):
            kind, path, src = "new", re.search(r"NEW file (\S+) required", user).group(1), self.new
        else:
            kind, path, src = "edit", re.search(r"FILE TO CHANGE: (\S+)", user).group(1), self.by_path
        self.prompts.append((kind, path, user))
        q = src[path]
        return q.pop(0) if len(q) > 1 else q[0]

    def prompts_for(self, kind, path):
        return [u for k, p, u in self.prompts if k == kind and p == path]


def git_out(repo: Path, *args) -> str:
    return sh("git", *args, cwd=repo)
