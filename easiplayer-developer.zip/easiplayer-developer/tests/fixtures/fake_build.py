"""Faux compilateur de test : échoue (format gcc) tant que runner.cpp contient BROKEN_CALL."""
import sys
from pathlib import Path

f = Path(sys.argv[1]) / "core" / "runner.cpp"
for i, line in enumerate(f.read_text().splitlines(), 1):
    if "BROKEN_CALL" in line:
        print(f"{f}:{i}:5: error: 'BROKEN_CALL' was not declared in this scope")
        sys.exit(1)
print("build ok")
