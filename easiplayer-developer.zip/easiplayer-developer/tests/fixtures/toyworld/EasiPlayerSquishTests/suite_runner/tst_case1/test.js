function main() {
    startApplication("easiplayer");
    clickButton(waitForObject(":MainWindow.Start_QPushButton"));
    test.verify(waitFor("object.exists(':StatusBar')", 5000), "status bar shown during run");
    test.compare(findObject(":MainWindow").windowTitle, "0");
    var x = 1;
}
