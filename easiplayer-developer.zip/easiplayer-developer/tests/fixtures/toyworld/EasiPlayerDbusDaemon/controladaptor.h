#pragma once
#include <QDBusAbstractAdaptor>
class ControlAdaptor : public QDBusAbstractAdaptor
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "com.easi.Daemon.Control")
public:
    explicit ControlAdaptor(QObject *parent);
public slots:
    void startProcess(const QString &name);
    void stopProcess(const QString &name);
signals:
    void processExited(const QString &name, int code);
};
