#include "../EasiPlayer/core/dbusconst.h"
#include "controladaptor.h"
#include <QCoreApplication>
#include <QDBusConnection>

int main(int argc, char **argv)
{
    QCoreApplication app(argc, argv);
    QObject *daemon = new QObject;
    new ControlAdaptor(daemon);
    QDBusConnection bus = QDBusConnection::sessionBus();
    bus.registerService(DAEMON_SERVICE);
    bus.registerObject(DAEMON_OBJECT_PATH, daemon);
    return app.exec();
}
