// script utilisateur évalué par QScriptEngine
runner.start("demo");
if (runner.step > 3) { runner.abort(); }
print(runner.describe());
