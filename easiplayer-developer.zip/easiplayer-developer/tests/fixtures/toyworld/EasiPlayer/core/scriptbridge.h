#pragma once
#include <QScriptEngine>
class Runner;
class ScriptBridge : public QObject
{
    Q_OBJECT
public:
    ScriptBridge(Runner *r, QObject *parent = nullptr);
    QScriptValue eval(const QString &code);
private:
    QScriptEngine m_engine;
    Runner *m_runner;
    int pad1 = 0;
};
