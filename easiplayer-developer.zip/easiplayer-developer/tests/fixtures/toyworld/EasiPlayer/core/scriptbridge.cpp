#include "scriptbridge.h"
#include "runner.h"

ScriptBridge::ScriptBridge(Runner *r, QObject *parent) : QObject(parent), m_runner(r)
{
    QScriptValue v = m_engine.newQObject(r);
    m_engine.globalObject().setProperty("runner", v);
}

QScriptValue ScriptBridge::eval(const QString &code)
{
    return m_engine.evaluate(code);
}
