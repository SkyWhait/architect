#pragma once
#include <QObject>
#include <QString>
class Runner : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int step READ step)
public:
    explicit Runner(QObject *parent = nullptr);
    void start(const QString &script);
    Q_INVOKABLE QString describe() const;
    int step() const { return m_step; }
signals:
    void finished(int code);
    void progress(int percent);
public slots:
    void abort();
private:
    bool m_running = false;
    int m_step = 0;
    QString m_script;
};
