add_library(easicore runner.cpp runner.h scriptbridge.cpp scriptbridge.h)
target_link_libraries(easicore Qt5::Core Qt5::DBus Qt5::Script)
