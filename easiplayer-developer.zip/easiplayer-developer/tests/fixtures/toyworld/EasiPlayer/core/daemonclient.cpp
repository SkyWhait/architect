#include "dbusconst.h"
#include <QDBusInterface>
#include <QDBusMessage>
#include <QDBusConnection>

void startOnDaemon(const QString &name)
{
    QDBusInterface iface(DAEMON_SERVICE, DAEMON_OBJECT_PATH, DAEMON_IFACE, QDBusConnection::sessionBus());
    iface.call("startProcess", name);
}

void stopOnDaemon(const QString &name)
{
    QDBusMessage msg = QDBusMessage::createMethodCall(DAEMON_SERVICE, DAEMON_OBJECT_PATH, DAEMON_IFACE, "stopProcess");
    msg << name;
    QDBusConnection::sessionBus().send(msg);
}
