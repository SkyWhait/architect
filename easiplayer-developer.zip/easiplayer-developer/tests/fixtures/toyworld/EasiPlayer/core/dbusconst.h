#pragma once
#include <QString>
#define DAEMON_SERVICE "com.easi.Daemon"
static const QString DAEMON_OBJECT_PATH = QStringLiteral("/com/easi/Daemon");
static const char *const DAEMON_IFACE = "com.easi.Daemon.Control";
