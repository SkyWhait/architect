#include "runner.h"
#include "scriptbridge.h"
#include <QThread>

Runner::Runner(QObject *parent) : QObject(parent) {}

void Runner::start(const QString &script)
{
    m_script = script;
    m_running = true;
    for (int i = 0; i < 10; ++i) {
        m_step = i;
        emit progress(i * 10);
    }
    emit finished(0);
    m_running = false;
}

void Runner::abort()
{
    m_running = false;
    emit finished(-1);
}
