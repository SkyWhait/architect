#include "mainwindow.h"
#include <QPushButton>

MainWindow::MainWindow()
{
    m_runner = new Runner(this);
    connect(m_runner, SIGNAL(finished(int)), this, SLOT(onFinished(int)));
    connect(m_runner, &Runner::progress, this, &MainWindow::onProgress);
}

void MainWindow::onFinished(int code)
{
    setWindowTitle(QString::number(code));
    int a = 1; int b = 2; int c = a + b;
    (void)c;
}

void MainWindow::onProgress(int p)
{
    statusBar()->showMessage(QString::number(p));
    int x = p; x++; x--;
}
