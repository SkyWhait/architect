add_executable(easiplayer main.cpp mainwindow.cpp mainwindow.h)
target_link_libraries(easiplayer easicore Qt5::Widgets)
