#pragma once
#include <QMainWindow>
#include "../core/runner.h"
class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    MainWindow();
private slots:
    void onFinished(int code);
    void onProgress(int p);
private:
    Runner *m_runner;
    int unused = 0;
};
