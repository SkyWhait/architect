"""Connexion à l'Architecte : faux Architecte (cas limites) + VRAI Architecte en mémoire (contrat /kb/symbol), ignoré s'il n'est pas installé."""
from __future__ import annotations

import json

import httpx
import pytest

from conftest import CPP, CPP_OK, H, HEADER_OK, FakeLLM, plan_with, with_files
from devagent.agent import DevAgent
from devagent.architect import ArchitectUnavailable, HttpArchitect, candidate_types
from devagent.models import PlanFile


class FakeArch:
    def __init__(self, symbols=None, boom=False):
        self.symbols, self.boom, self.calls = symbols or {}, boom, []

    async def find_symbol(self, name):
        self.calls.append(name)
        if self.boom:
            raise ArchitectUnavailable("connection refused")
        return self.symbols.get(name, [])

    async def aclose(self):
        pass


RUNNER = {"Runner": [{"path": "EasiPlayer/core/runner.h", "kind": "class", "name": "Runner", "bases": '["QObject"]', "line_start": 3, "line_end": 20}]}


def test_candidate_types_skip_qt_and_types_defined_in_the_file():
    pf = PlanFile(path="EasiPlayer/core/a.cpp", symbols=["Runner::abort"], logic_change="Use GmtTime and InfoData with a QTimer; Declare a flag.")
    assert candidate_types(pf, [], set(), 6) == ["Runner", "GmtTime", "InfoData"]
    assert candidate_types(pf, [], {"GmtTime"}, 6) == ["Runner", "InfoData"]


async def test_declarations_reach_the_prompt_and_are_read_from_the_repository(cfg, world, plan):
    llm = FakeLLM({H: HEADER_OK, CPP: CPP_OK})
    rep = await DevAgent(cfg, llm, FakeArch(RUNNER)).apply(plan)
    assert rep.status == "applied"
    p = llm.prompts_for("edit", CPP)[0]
    assert "DECLARATIONS OF TYPES" in p and "class Runner : public QObject" in p and "EasiPlayer/core/runner.h lines 3-20" in p
    assert rep.meta["architect_facts"] == ["Runner -> EasiPlayer/core/runner.h:3-20"]
    assert "class Runner" not in llm.prompts_for("edit", H)[0].split("DECLARATIONS OF TYPES")[1].split("CURRENT FILE")[0]    # défini dans le .h lui-même : rien à ajouter


async def test_stale_index_is_ignored_not_trusted(cfg, world, plan):
    stale = {"Runner": [{**RUNNER["Runner"][0], "line_start": 12, "line_end": 18}]}          # l'index dit ligne 12 : le dépôt n'y a plus `class Runner`
    llm = FakeLLM({H: HEADER_OK, CPP: CPP_OK})
    rep = await DevAgent(cfg, llm, FakeArch(stale)).apply(plan)
    assert rep.status == "applied" and rep.meta["architect_facts"] == []
    assert "class Runner" not in llm.prompts_for("edit", CPP)[0].split("CURRENT FILE")[0]
    assert any(w.code == "stale_index" for w in rep.warnings)


async def test_unreachable_architect_never_blocks_the_work(cfg, world, plan):
    rep = await DevAgent(cfg, FakeLLM({H: HEADER_OK, CPP: CPP_OK}), FakeArch(boom=True)).apply(plan)
    assert rep.status == "applied" and any(w.code == "architect_unavailable" for w in rep.warnings)


async def test_without_architect_the_prompt_says_none(cfg, world, plan):
    llm = FakeLLM({H: HEADER_OK, CPP: CPP_OK})
    assert (await DevAgent(cfg, llm).apply(plan)).status == "applied"
    assert "(none)" in llm.prompts_for("edit", CPP)[0].split("DECLARATIONS OF TYPES")[1].split("CURRENT FILE")[0]


async def test_forbidden_paths_from_the_index_are_never_read(cfg, world, plan):
    evil = {"Runner": [{"path": "EasiPlayer/redist/x.h", "kind": "class", "name": "Runner", "bases": "[]", "line_start": 1, "line_end": 5}]}
    rep = await DevAgent(cfg, FakeLLM({H: HEADER_OK, CPP: CPP_OK}), FakeArch(evil)).apply(plan)
    assert rep.status == "applied" and rep.meta["architect_facts"] == []


# ------------------------------------------------------------------- VRAI Architecte (en mémoire)
@pytest.fixture
def real_arch(tmp_path, monkeypatch, world):
    pytest.importorskip("archagent")
    from archagent.api import create_app
    from archagent.config import get_settings
    from archagent.stages.index import run_index
    from archagent.store import Store
    monkeypatch.setenv("ARCH_REPO_ROOT", str(world / "EasiPlayer"))
    monkeypatch.setenv("ARCH_EXTRA_ROOTS", json.dumps([str(world / "EasiPlayerDbusDaemon"), str(world / "EasiPlayerSquishTests")]))
    monkeypatch.setenv("ARCH_WORK_DIR", str(tmp_path / "archwork"))
    acfg = get_settings()
    store = Store(acfg.db_path)
    run_index(acfg, store)
    return HttpArchitect("http://architect", transport=httpx.ASGITransport(app=create_app()), retries=0)


async def test_contract_with_the_real_architect(cfg, world, plan, real_arch):
    rows = await real_arch.find_symbol("Runner")
    assert any(r["kind"] == "class" and r["path"] == "EasiPlayer/core/runner.h" and r["line_start"] == 4 for r in rows)     # le contrat que build_facts consomme
    llm = FakeLLM({H: HEADER_OK, CPP: CPP_OK})
    rep = await DevAgent(cfg, llm, real_arch).apply(plan)
    assert rep.status == "applied", rep.status_reason
    assert rep.meta["architect_facts"] and rep.meta["architect_facts"][0].startswith("Runner -> EasiPlayer/core/runner.h:4-")
    assert "Q_PROPERTY(int step READ step)" in llm.prompts_for("edit", CPP)[0]            # vraie déclaration, lue dans le dépôt


async def test_api_wires_the_architect_and_writes_the_audit_log(cfg, world, plan, real_arch):
    from fastapi.testclient import TestClient
    from devagent.api import create_app
    llm = FakeLLM({H: HEADER_OK, CPP: CPP_OK})
    app = create_app(llm_factory=lambda: llm, settings=cfg, architect_factory=lambda: real_arch)
    with TestClient(app) as c:
        r = c.post("/changes", json={"plan": json.loads(plan.model_dump_json()), "eap_ref": "EAP-12610"})
        assert r.status_code == 202
        import time
        for _ in range(100):
            st = c.get("/changes/D0002312").json()
            if st["state"] == "done":
                break
            time.sleep(0.1)
        assert st["status"] == "applied"
        rep = c.get("/changes/D0002312", params={"full": True}).json()["report"]
        assert rep["commit_subject"].startswith("[EAP-12610][General]") and rep["meta"]["architect_facts"]
        assert c.get("/health").json()["version"] == "0.2.0"
    log = [json.loads(l) for l in (cfg.work_dir / "audit.jsonl").read_text().splitlines()]
    assert [x["action"] for x in log] == ["apply_start", "apply_done"] and log[1]["status"] == "applied" and log[0]["eap_ref"] == "EAP-12610"
    assert "diff" not in json.dumps(log) and "root_cause" not in json.dumps(log)                  # pas de code ni de contenu dans l'audit
