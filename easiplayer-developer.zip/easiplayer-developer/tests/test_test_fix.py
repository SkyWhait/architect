"""Boucle QA -> Développeur : les tests Squish échouent avec la modification, le Développeur la corrige avec le plan du Stratège et le retour de la QA sous les yeux."""
from __future__ import annotations

import time

from fastapi.testclient import TestClient

from conftest import CPP, CPP_OK, H, HEADER_OK, EditSet, FakeLLM, e, git_out
from devagent.api import create_app
from devagent.fix import apply_test_fix
from devagent.models import DevReport, TestFixRequest
from test_agent import clean, wt
from test_fix import applied

QA_FEEDBACK = """The Squish tests do NOT pass with your change.

### 1. FAILING TEST: tst_STD-EAP-SEQUENCER-00002 (zone SEQUENCER) — NEW failure; passed in the reference run
What this test verifies: Stop interrupts the sequence once
Failure: [FAIL] Comparison at test.py:9: Values are not equal: expected 'Stopped', got 'Finished'
Parts of YOUR change related to this test: EasiPlayer/core/runner.cpp (shares: runner)

Fix the change so that these tests pass without breaking what it was meant to fix. Do not edit the tests."""

FIX_OK = EditSet(summary="reset the guard when a new run starts and also when aborting", edits=[e("replace", "    m_aborted = true;\n    emit finished(-1);", "    m_aborted = true;\n    m_step = 0;\n    emit finished(-1);")])


async def test_test_failure_is_fixed_with_the_plan_and_the_qa_report_in_the_prompt(cfg, world, plan):
    await applied(cfg, plan)
    llm = FakeLLM(testfixes={CPP: FIX_OK, H: EditSet(summary="nothing here", edits=[], cannot_apply="the header only declares m_aborted; the symptom is in runner.cpp")})
    res = await apply_test_fix(cfg, llm, "D0002312", TestFixRequest(feedback=QA_FEEDBACK, round=1))
    assert res.status == "fixed" and {f["path"]: f["status"] for f in res.files} == {H: "failed", CPP: "applied"}      # le .h n'a rien à corriger : dit pourquoi, sans bloquer
    p = llm.prompts_for("testfix", CPP)[0]
    assert "STRATEGIST PLAN" in p and plan.plan.root_cause in p                                   # le rapport du Stratège
    assert "FAILING TEST: tst_STD-EAP-SEQUENCER-00002" in p and "expected 'Stopped', got 'Finished'" in p      # le retour de la QA, tel quel
    assert "+    m_aborted = true;" in p                                                         # notre propre changement, en diff
    cpp = (wt(res_report(cfg)) / "core/runner.cpp").read_text()
    assert "    m_aborted = true;\n    m_step = 0;\n" in cpp and "emit finished(-1);" in cpp
    log = git_out(wt(res_report(cfg)), "log", "--format=%s")
    assert "Fix test failure (round 1)" in log
    rep = DevReport.model_validate_json((cfg.work_dir / "D0002312" / "dev_report.json").read_text())
    assert rep.meta["test_fix_rounds"] == 1 and any(ed.get("op") == "test_fix" for f in rep.files for ed in f.edits) and rep.status == "applied"
    assert "m_step = 0" in rep.diff                                                              # le rapport mis à jour contient le nouveau diff (le Compilateur le relit)


def res_report(cfg):
    return DevReport.model_validate_json((cfg.work_dir / "D0002312" / "dev_report.json").read_text())


async def test_edits_outside_the_zones_we_changed_are_refused(cfg, world, plan):
    await applied(cfg, plan)
    cfg.scope_slack_lines = 0
    far = EditSet(summary="x", edits=[e("replace", "Runner::Runner(QObject *parent) : QObject(parent) {}", "Runner::Runner(QObject *parent) : QObject(parent) { m_step = 1; }")])
    llm = FakeLLM(testfixes={CPP: far, H: EditSet(summary="", edits=[], cannot_apply="n/a")})
    res = await apply_test_fix(cfg, llm, "D0002312", TestFixRequest(feedback=QA_FEEDBACK))
    assert res.status == "no_change" and "edit_outside_scope" in res.reason
    assert "m_step = 1" not in (wt(res_report(cfg)) / "core/runner.cpp").read_text()


async def test_scope_limit_and_cannot_apply_give_no_change(cfg, world, plan):
    await applied(cfg, plan)
    llm = FakeLLM(testfixes={CPP: EditSet(summary="", edits=[], cannot_apply="the symptom is not caused by this file"), H: EditSet(summary="", edits=[], cannot_apply="nor this one")})
    res = await apply_test_fix(cfg, llm, "D0002312", TestFixRequest(feedback=QA_FEEDBACK))
    assert res.status == "no_change" and "the symptom is not caused by this file" in res.reason
    assert (cfg.work_dir / "D0002312" / "dev_report.json").exists() and res_report(cfg).meta.get("test_fix_rounds", 0) == 0     # rien n'a changé


async def test_conventions_apply_to_test_fixes_too(cfg, world, plan):
    await applied(cfg, plan)
    bad = EditSet(summary="x", edits=[e("replace", "    m_aborted = true;\n    emit finished(-1);", "    m_aborted = true;\n    auto p = std::make_unique<int>(0);\n    emit finished(-1);")])
    llm = FakeLLM(testfixes={CPP: bad, H: EditSet(summary="", edits=[], cannot_apply="n/a")})
    res = await apply_test_fix(cfg, llm, "D0002312", TestFixRequest(feedback=QA_FEEDBACK))
    assert res.status == "no_change" and "cxx11_violation" in res.reason
    assert "make_unique" not in (wt(res_report(cfg)) / "core/runner.cpp").read_text()


async def test_endpoint_and_audit(cfg, world, plan):
    await applied(cfg, plan)
    llm = FakeLLM(testfixes={CPP: FIX_OK, H: EditSet(summary="", edits=[], cannot_apply="n/a")})
    with TestClient(create_app(llm_factory=lambda: llm, settings=cfg)) as c:
        r = c.post("/changes/D0002312/fix_tests", json={"feedback": QA_FEEDBACK, "round": 1})
        assert r.status_code == 200 and r.json()["status"] == "fixed" and r.json()["round"] == 1
        assert c.post("/changes/inconnu/fix_tests", json={"feedback": "x"}).json()["status"] == "rejected"
    assert any('"fix_tests"' in l for l in (cfg.work_dir / "audit.jsonl").read_text().splitlines())
