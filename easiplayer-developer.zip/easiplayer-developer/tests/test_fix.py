from __future__ import annotations

import json
import time

from fastapi.testclient import TestClient

from conftest import CPP, CPP_OK, H, HEADER_OK, EditSet, FakeLLM, e, git_out
from devagent.agent import DevAgent
from devagent.api import create_app
from devagent.fix import apply_fix
from devagent.models import FixRequest

BROKEN = EditSet(summary="x", edits=CPP_OK.edits + [e("insert_after", "    m_step = i;", "        BROKEN_CALL();")])
REMOVE = EditSet(summary="remove the call that does not exist", edits=[e("delete", "        BROKEN_CALL();")])


def diag(path=CPP, line=14, msg="'BROKEN_CALL' was not declared in this scope", **kw):
    return {"path": path, "line": line, "column": 9, "category": "undeclared_identifier", "message": msg, "hints": ["`BROKEN_CALL` is not declared here"], **kw}


async def applied(cfg, plan, llm=None):
    rep = await DevAgent(cfg, llm or FakeLLM({H: HEADER_OK, CPP: BROKEN})).apply(plan)
    assert rep.status == "applied"
    return rep


async def test_fix_round_corrects_commits_and_updates_the_report(cfg, world, plan):
    rep = await applied(cfg, plan)
    sha0 = rep.commits["EasiPlayer"]
    llm = FakeLLM(fixes={CPP: REMOVE})
    res = await apply_fix(cfg, llm, "D0002312", FixRequest(diagnostics=[diag()], round=1))
    assert res.status == "fixed" and res.files[0]["status"] == "applied"
    wt = rep.worktrees["EasiPlayer"]
    assert "BROKEN_CALL" not in open(wt + "/core/runner.cpp").read() and "m_aborted" in open(wt + "/core/runner.cpp").read()      # le correctif d'origine est conservé
    assert res.commits["EasiPlayer"] != sha0 and "Fix build errors (round 1)" in git_out(wt, "log", "-1", "--format=%B")
    assert git_out(wt, "status", "--porcelain").strip() == ""
    prompt = llm.prompts_for("fix", CPP)[0]
    assert "was not declared" in prompt and "hint:" in prompt and "BROKEN_CALL" in prompt
    saved = json.loads((cfg.work_dir / "D0002312" / "dev_report.json").read_text())
    assert saved["meta"]["fix_rounds"] == 1 and saved["commits"]["EasiPlayer"] == res.commits["EasiPlayer"]
    assert any(x.get("op") == "build_fix" for f in saved["files"] for x in f["edits"])
    assert "BROKEN_CALL" not in (cfg.work_dir / "D0002312" / "changes.diff").read_text() and "m_aborted" in saved["diff"]      # diff TOTAL depuis la base


async def test_diagnostics_outside_the_plan_are_not_editable(cfg, world, plan):
    await applied(cfg, plan)
    res = await apply_fix(cfg, FakeLLM(fixes={}), "D0002312", FixRequest(diagnostics=[diag(path="EasiPlayer/core/scriptbridge.cpp")]))
    assert res.status == "rejected" and "aucun diagnostic dans les fichiers du plan" in res.reason and res.issues[0].code == "out_of_plan"


async def test_fix_may_edit_a_suggested_header_of_the_plan_first(cfg, world, plan):
    await applied(cfg, plan, FakeLLM({H: HEADER_OK, CPP: CPP_OK}))
    d = diag(msg="'m_extra' was not declared in this scope", hints=["`m_extra` looks like a member of Runner but is not declared in EasiPlayer/core/runner.h:4: declare it"],
             suggest_files=[H], line=18)
    header_fix = EditSet(summary="declare m_extra", edits=[e("insert_after", "    bool m_aborted = false;", "    int m_extra = 0;")])
    cpp_fix = EditSet(summary="use it", edits=[e("insert_after", "    m_aborted = true;", "    m_extra = 1;")])
    llm = FakeLLM(fixes={H: header_fix, CPP: cpp_fix})
    res = await apply_fix(cfg, llm, "D0002312", FixRequest(diagnostics=[d]))
    assert res.status == "fixed" and [f["path"] for f in res.files] == [H, CPP]                   # en-tête d'abord
    assert "int m_extra = 0;" in llm.prompts_for("fix", CPP)[0]                                    # le .cpp voit ce qui vient d'être fait dans l'en-tête
    assert "may require a change HERE" in llm.prompts_for("fix", H)[0]


async def test_unfixable_or_wrong_edits_change_nothing(cfg, world, plan):
    rep = await applied(cfg, plan)
    before = open(rep.worktrees["EasiPlayer"] + "/core/runner.cpp").read()
    wrong = EditSet(summary="x", edits=[e("delete", "        NOT_THERE();")])
    res = await apply_fix(cfg, FakeLLM(fixes={CPP: wrong}), "D0002312", FixRequest(diagnostics=[diag()]))
    assert res.status == "no_change" and "anchor_not_found" in res.reason
    giveup = EditSet(summary="", edits=[], cannot_apply="I do not see where BROKEN_CALL comes from")
    res2 = await apply_fix(cfg, FakeLLM(fixes={CPP: giveup}), "D0002312", FixRequest(diagnostics=[diag()]))
    assert res2.status == "no_change" and "cannot_apply" in res2.reason
    assert open(rep.worktrees["EasiPlayer"] + "/core/runner.cpp").read() == before and git_out(rep.worktrees["EasiPlayer"], "status", "--porcelain").strip() == ""


async def test_fix_is_scoped_to_the_error_lines(cfg, world, plan):
    await applied(cfg, plan)
    cfg.scope_slack_lines = 2
    sneaky = EditSet(summary="x", edits=[e("replace", "Runner::Runner(QObject *parent) : QObject(parent) {}", "Runner::Runner(QObject *parent) : QObject(parent) { m_step = 5; }")])
    res = await apply_fix(cfg, FakeLLM(fixes={CPP: sneaky}), "D0002312", FixRequest(diagnostics=[diag(line=14)]))
    assert res.status == "no_change" and "edit_outside_scope" in res.reason


async def test_fix_requires_a_previous_successful_application(cfg, world, plan):
    res = await apply_fix(cfg, FakeLLM(fixes={}), "D4040", FixRequest(diagnostics=[diag()]))
    assert res.status == "rejected" and "aucun rapport" in res.reason
    bad = await DevAgent(cfg, FakeLLM({H: HEADER_OK, CPP: EditSet(summary="", edits=[], cannot_apply="no")})).apply(plan)
    assert bad.status == "needs_review"
    assert (await apply_fix(cfg, FakeLLM(fixes={}), "D0002312", FixRequest(diagnostics=[diag()]))).status == "rejected"


def test_fix_endpoint(cfg, world, plan):
    import asyncio
    asyncio.run(applied(cfg, plan))
    app = create_app(llm_factory=lambda: FakeLLM(fixes={CPP: REMOVE}), settings=cfg)
    with TestClient(app) as c:
        r = c.post("/changes/D0002312/fix", json={"diagnostics": [diag()], "round": 2}).json()
        assert r["status"] == "fixed" and r["round"] == 2 and r["commits"]
        assert c.post("/changes/D0002312/fix", json={"diagnostics": []}).json()["status"] == "rejected"
        assert c.post("/changes/D0002312/fix", json={}).status_code == 422


async def test_fix_round_sees_the_strategist_plan(cfg, world, plan):
    """Le rapport du Stratège (cause racine, intention pour CE fichier, risques) est relu à chaque tour de correction du build."""
    await applied(cfg, plan)
    assert (cfg.work_dir / "D0002312" / "plan.json").exists()
    llm = FakeLLM(fixes={CPP: REMOVE})
    await apply_fix(cfg, llm, "D0002312", FixRequest(diagnostics=[diag()], round=1))
    prompt = llm.prompts_for("fix", CPP)[0]
    body = plan.plan
    mine = next(f for f in body.files_to_modify if f.path == CPP)
    assert "STRATEGIST PLAN" in prompt and body.root_cause in prompt and mine.logic_change in prompt and "Root cause:" in prompt
    assert any(f.path != CPP and f.path in prompt for f in body.files_to_modify)           # et ce qui est prévu dans les autres fichiers
