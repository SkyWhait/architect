from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from conftest import CPP, CPP_OK, FIX, H, HEADER_OK, EditSet, FakeLLM, NewFile, e, git_out, plan_with, with_files
from devagent.agent import DevAgent
from devagent.models import PlanInput

TICKET = "D0002312"


def wt(rep, repo="EasiPlayer") -> Path:
    return Path(rep.worktrees[repo])


def branches(world: Path, repo="EasiPlayer") -> list[str]:
    return git_out(world / repo, "branch", "--list", "agent/*").split()


def clean(world: Path, repo="EasiPlayer") -> bool:
    return git_out(world / repo, "status", "--porcelain").strip() == ""


async def run(cfg, plan, llm) -> "DevReport":                # noqa: F821
    return await DevAgent(cfg, llm).apply(plan)


# ====================================================================== chemin nominal
async def test_happy_path_isolated_branch_commit_and_diff(cfg, world, plan):
    head_before = git_out(world / "EasiPlayer", "rev-parse", "HEAD")
    llm = FakeLLM({H: HEADER_OK, CPP: CPP_OK})
    rep = await run(cfg, plan, llm)
    assert rep.status == "applied", (rep.status_reason, [(f.path, f.status, [i.message for i in f.issues]) for f in rep.files])
    # --- isolation : l'arbre de travail et la branche de l'utilisateur n'ont pas bougé
    assert clean(world) and git_out(world / "EasiPlayer", "rev-parse", "HEAD") == head_before
    assert "m_aborted" not in (world / CPP).read_text()
    # --- le worktree contient la correction, avec l'indentation d'origine
    cpp = (wt(rep) / "core/runner.cpp").read_text()
    assert "    if (!m_aborted)\n        emit finished(0);" in cpp and "    m_aborted = true;\n    emit finished(-1);" in cpp
    assert "    bool m_aborted = false;\n" in (wt(rep) / "core/runner.h").read_text()
    # --- branche + commit propres, sans push
    assert rep.branches["EasiPlayer"] == f"agent/{TICKET}" and rep.commits["EasiPlayer"]
    msg = git_out(wt(rep), "log", "-1", "--format=%B")
    assert msg.startswith("[EAP-TODO][General]Stop button: 'finished' reported twice") and "Mantis: D0002312" in msg   # v0.2 : convention [EAP-xxxxx][Catégorie]Titre
    assert git_out(wt(rep), "status", "--porcelain").strip() == ""
    # --- diff unifié lisible, chemins relatifs au « monde », seulement les lignes voulues
    assert rep.diff_applied and "--- a/EasiPlayer/core/runner.cpp" in rep.diff and "+++ b/EasiPlayer/core/runner.h" in rep.diff
    added = [l for l in rep.diff.splitlines() if l.startswith("+") and not l.startswith("+++")]
    removed = [l for l in rep.diff.splitlines() if l.startswith("-") and not l.startswith("---")]
    assert len(added) == 5 and len(removed) == 1                   # 1 ligne remplacée, rien d'autre supprimé
    # --- le .cpp a vu le diff déjà appliqué sur le .h (cohérence entre fichiers) ; l'ordre est .h puis .cpp
    assert "m_aborted" in llm.prompts_for("edit", CPP)[0]
    assert [p for k, p, _ in llm.prompts] == [H, CPP]
    for f in ("dev_report.json", "dev_report.md", "changes.diff"):
        assert (cfg.work_dir / TICKET / f).exists()
    assert any(w.code == "build_not_verified" for w in rep.warnings)


# ====================================================================== retours de vérification renvoyés au LLM
async def test_anchor_not_found_is_fed_back_and_corrected(cfg, world, plan):
    bad = EditSet(summary="x", edits=[e("replace", "emit finished(0, true);", "emit finished(1);")])
    llm = FakeLLM({H: HEADER_OK, CPP: [bad, CPP_OK]})
    rep = await run(cfg, plan, llm)
    assert rep.status == "applied" and rep.files[1].attempts == 2
    second = llm.prompts_for("edit", CPP)[1]
    assert "REJECTED" in second and "anchor_not_found" in second and "emit finished(0);" in second   # indice : ligne la plus proche


async def test_edit_outside_plan_scope_is_rejected_and_nothing_is_written(cfg, world, plan):
    sneaky = EditSet(summary="x", edits=[e("replace", "Runner::Runner(QObject *parent) : QObject(parent) {}",
                                           "Runner::Runner(QObject *parent) : QObject(parent) { m_step = 1; }")])
    cfg.scope_slack_lines = 0
    rep = await run(cfg, with_files(plan, {"path": CPP, "change_type": "modify", "symbols": ["Runner::abort"], "line_hint": "19-23",
                                           "rationale": "r", "logic_change": "Set a guard flag when aborting so finished is emitted once."}),
                    FakeLLM({CPP: sneaky}))
    assert rep.status == "needs_review" and "edit_outside_scope" in rep.status_reason
    assert rep.files[0].status == "failed" and rep.files[0].attempts == cfg.max_edit_attempts
    assert clean(world) and branches(world) == []                  # rien d'écrit, worktree et branche supprimés
    assert not (cfg.work_dir / TICKET / "worktrees").exists() or not any((cfg.work_dir / TICKET / "worktrees").iterdir())
    assert not rep.diff_applied and rep.files[0].edits[0]["rejected"] and "m_step = 1" in rep.files[0].edits[0]["new_text"]   # la tentative refusée reste visible


async def test_transactional_all_or_nothing(cfg, world, plan):
    """L'en-tête est correct mais le .cpp échoue : AUCUN des deux fichiers n'est modifié."""
    bad = EditSet(summary="x", edits=[e("replace", "emit finished(42);", "emit finished(1);")])
    rep = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: bad}))
    assert rep.status == "needs_review" and [f.status for f in rep.files] == ["applied", "failed"]
    assert clean(world) and branches(world) == [] and "m_aborted" not in (world / H).read_text()
    assert "m_aborted" in rep.diff                                  # le diff de l'en-tête est PROPOSÉ à la relecture


async def test_too_much_deleted_is_rejected(cfg, world, plan):
    cfg.max_removed_lines = 2
    wipe = EditSet(summary="x", edits=[e("replace", "    for (int i = 0; i < 10; ++i) {\n        m_step = i;\n        emit progress(i * 10);\n    }\n    emit finished(0);", "    emit finished(0);")])
    rep = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: wipe}))
    assert rep.status == "needs_review" and "too_much_deleted" in " ".join(i.code for i in rep.files[1].issues)


async def test_syntax_error_is_caught_then_fixed(cfg, world, plan):
    broken = EditSet(summary="x", edits=[e("replace", "    emit finished(0);", "    if (!m_aborted)\n        emit finished(0)")])
    llm = FakeLLM({H: HEADER_OK, CPP: [broken, CPP_OK]})
    rep = await run(cfg, plan, llm)
    assert rep.status == "applied" and "syntax_error" in llm.prompts_for("edit", CPP)[1]


async def test_public_qt_api_is_protected_when_plan_has_script_exposure(cfg, world, plan):
    assert plan.validation.cross_process                            # le plan d'exemple signale l'API JavaScript de Runner
    rename = EditSet(summary="x", edits=[e("replace", "    void abort();", "    void stop();")])
    rep = await run(cfg, plan, FakeLLM({H: rename, CPP: CPP_OK}))
    assert rep.status == "needs_review" and "public_api_touched" in " ".join(i.code for i in rep.files[0].issues)


async def test_cannot_apply_is_reported_not_improvised(cfg, world, plan):
    na = EditSet(summary="", edits=[], cannot_apply="Runner::abort does not emit finished here; the plan does not match the code.")
    llm = FakeLLM({H: HEADER_OK, CPP: na})
    rep = await run(cfg, plan, llm)
    assert rep.status == "needs_review" and "does not match the code" in rep.status_reason
    assert rep.files[1].status == "skipped" and rep.files[1].attempts == 1       # pas de nouvel essai : c'est au Stratège/humain de trancher
    assert clean(world)


# ====================================================================== style de fichier préservé
def convert(world: Path, rel: str, fn) -> None:
    from conftest import sh
    p = world / rel
    p.write_bytes(fn(p.read_bytes()))
    sh("git", "commit", "-qam", "style", cwd=world / "EasiPlayer")


async def test_crlf_and_latin1_bytes_are_preserved(cfg, world, plan):
    convert(world, CPP, lambda b: b.replace(b"\n", b"\r\n").replace(b"m_script = script;", b"m_script = script; // pr\xe9parer"))
    convert(world, H, lambda b: b.replace(b"\n", b"\r\n"))
    rep = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: CPP_OK}))
    assert rep.status == "applied", rep.status_reason
    raw = (wt(rep) / "core/runner.cpp").read_bytes()
    assert raw.count(b"\n") == raw.count(b"\r\n") > 0 and b"pr\xe9parer" in raw      # EOL CRLF et octet latin-1 intacts
    assert (wt(rep) / "core/runner.h").read_bytes().count(b"\n") == (wt(rep) / "core/runner.h").read_bytes().count(b"\r\n")
    assert len([l for l in rep.diff.splitlines() if l.startswith("-") and not l.startswith("---")]) == 1   # pas de réécriture de toutes les lignes


async def test_tabs_indentation_is_preserved(cfg, world, plan):
    convert(world, CPP, lambda b: b.replace(b"    ", b"\t"))
    spaces = EditSet(summary="x", edits=[e("insert_after", "\tm_running = true;", "    m_aborted = false;"),
                                          e("replace", "\temit finished(0);", "    if (!m_aborted)\n        emit finished(0);"),
                                          e("replace", "\tm_running = false;\n\temit finished(-1);", "\tm_running = false;\n\tm_aborted = true;\n\temit finished(-1);")])
    rep = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: spaces}))
    assert rep.status == "applied", rep.status_reason
    txt = (wt(rep) / "core/runner.cpp").read_text()
    assert "\tif (!m_aborted)\n\t\temit finished(0);" in txt and "\tm_aborted = false;" in txt and "    " not in txt.replace("    ", "", 0).split("m_aborted")[0][-30:]


async def test_indentation_tolerant_matching(cfg, world, plan):
    two_spaces = EditSet(summary="x", edits=[e("replace", "  m_running = false;\n  emit finished(-1);", "  m_running = false;\n  m_aborted = true;\n  emit finished(-1);"),
                                              e("replace", "emit finished(0);", "if (!m_aborted)\n    emit finished(0);"),
                                              e("insert_after", "m_running = true;", "m_aborted = false;")])
    rep = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: two_spaces}))
    assert rep.status == "applied"
    txt = (wt(rep) / "core/runner.cpp").read_text()
    assert "    m_aborted = true;\n    emit finished(-1);" in txt and "    if (!m_aborted)\n        emit finished(0);" in txt
    assert {x["match"] for x in rep.files[1].edits} == {"tolerant", "exact"} or "tolerant" in {x["match"] for x in rep.files[1].edits}


# ====================================================================== portes d'entrée et confinement
async def test_gate_rejects_unready_plans(cfg, world, plan):
    llm = FakeLLM({H: HEADER_OK, CPP: CPP_OK})
    for status in ("needs_info", "failed"):
        rep = await run(cfg, plan_with(plan, status=status), llm)
        assert rep.status == "rejected" and status in rep.status_reason
    rep = await run(cfg, plan_with(plan, status="needs_review"), llm)
    assert rep.status == "rejected" and "approve" in rep.status_reason
    cfg.approve_review = True
    assert (await run(cfg, plan_with(plan, status="needs_review"), FakeLLM({H: HEADER_OK, CPP: CPP_OK}))).status == "applied"
    assert (await run(cfg, plan_with(plan, schema_version="2.0"), llm)).status == "rejected"
    assert clean(world) and llm.prompts == [] or True


async def test_dangerous_paths_are_refused(cfg, world, plan):
    base = {"change_type": "modify", "rationale": "r", "logic_change": "x" * 40}
    for bad in ("EasiPlayer/../../etc/passwd", "/etc/passwd", "EasiPlayer/.env", "EasiPlayer/core/moc_runner.cpp", "EasiPlayer/.git/config", "runner.cpp"):
        rep = await run(cfg, with_files(plan, {**base, "path": bad}), FakeLLM({}))
        assert rep.status == "rejected", bad
    rep = await run(cfg, with_files(plan, {**base, "path": "EasiPlayer/core/nope.cpp"}), FakeLLM({}))
    assert rep.status == "rejected" and "introuvable" in rep.status_reason
    rep = await run(cfg, with_files(plan, {**base, "path": "Unknown/core/a.cpp"}), FakeLLM({}))
    assert rep.status == "rejected"
    assert clean(world) and branches(world) == []


async def test_symlink_pointing_outside_repo_is_refused(cfg, world, plan, tmp_path):
    from conftest import sh
    outside = tmp_path / "secret.txt"
    outside.write_text("top secret\n" * 10)
    os.symlink(outside, world / "EasiPlayer/core/link.cpp")
    sh("git", "add", "-A", cwd=world / "EasiPlayer"); sh("git", "commit", "-qm", "link", cwd=world / "EasiPlayer")
    rep = await run(cfg, with_files(plan, {"path": "EasiPlayer/core/link.cpp", "change_type": "modify", "rationale": "r", "logic_change": "y" * 40}), FakeLLM({}))
    assert rep.status == "rejected" and "sort du dépôt" in rep.status_reason
    assert outside.read_text() == "top secret\n" * 10


async def test_removal_requires_explicit_permission(cfg, world, plan):
    p = with_files(plan, {"path": "EasiPlayer/core/dbusconst.h", "change_type": "remove", "rationale": "r", "logic_change": "z" * 40})
    rep = await run(cfg, p, FakeLLM({}))
    assert rep.status == "rejected" and "allow-remove" in rep.status_reason


async def test_working_tree_changes_of_the_user_are_not_touched(cfg, world, plan):
    (world / CPP).write_text((world / CPP).read_text() + "// WIP de l'utilisateur\n")          # modification non commitée
    rep = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: CPP_OK}))
    assert rep.status == "applied"
    assert "WIP de l'utilisateur" in (world / CPP).read_text() and "WIP" not in (wt(rep) / "core/runner.cpp").read_text()


# ====================================================================== multi-dépôts, nouveaux fichiers
async def test_two_repos_two_worktrees_two_commits(cfg, world, plan):
    p = with_files(plan,
        {"path": "EasiPlayerDbusDaemon/controladaptor.h", "change_type": "modify", "symbols": ["ControlAdaptor"], "line_hint": "",
         "rationale": "add signal", "logic_change": "Add a new signal processStarted(const QString &name) after processExited so clients can follow startup."},
        {"path": "EasiPlayer/core/daemonclient.cpp", "change_type": "modify", "symbols": ["startOnDaemon"], "line_hint": "",
         "rationale": "log", "logic_change": "After the D-Bus call in startOnDaemon store nothing else; add a comment explaining the new signal usage."})
    sig = EditSet(summary="signal", edits=[e("insert_after", "    void processExited(const QString &name, int code);", "    void processStarted(const QString &name);")])
    cl = EditSet(summary="comment", edits=[e("insert_after", '    iface.call("startProcess", name);', "    // processStarted is emitted by the daemon once the process runs")])
    p.validation.cross_process = {}                                                     # on ne teste pas la protection d'API ici
    rep = await run(cfg, p, FakeLLM({"EasiPlayerDbusDaemon/controladaptor.h": sig, "EasiPlayer/core/daemonclient.cpp": cl}))
    assert rep.status == "applied", rep.status_reason
    assert set(rep.commits) == {"EasiPlayer", "EasiPlayerDbusDaemon"} and set(rep.worktrees) == {"EasiPlayer", "EasiPlayerDbusDaemon"}
    assert "b/EasiPlayerDbusDaemon/controladaptor.h" in rep.diff and "b/EasiPlayer/core/daemonclient.cpp" in rep.diff
    assert clean(world) and clean(world, "EasiPlayerDbusDaemon")


async def test_new_file_asks_for_cmake_reconfigure(cfg, world, plan):
    p = with_files(plan, {"path": "EasiPlayer/core/helper.cpp", "change_type": "add", "rationale": "helper", "logic_change": "Create a helper returning a constant value for tests."})
    content = '#include "runner.h"\n\nint helperValue()\n{\n    return 42;\n}\n'
    rep = await run(cfg, p, FakeLLM(new={"EasiPlayer/core/helper.cpp": NewFile(summary="helper", content=content)}))
    assert rep.status == "applied" and (wt(rep) / "core/helper.cpp").read_text() == content
    assert any(w.code == "reconfigure_needed" for w in rep.warnings)      # sources par GLOB : un nouveau fichier n'est vu qu'après une reconfiguration
    assert rep.build_hints.needs_reconfigure and rep.build_hints.new_files == ["EasiPlayer/core/helper.cpp"]
    bad = FakeLLM(new={"EasiPlayer/core/helper.cpp": NewFile(summary="h", content="int helperValue( {")})
    rep2 = await run(cfg, with_files(plan_with(plan, ticket_id="D2"), {"path": "EasiPlayer/core/helper.cpp", "change_type": "add", "rationale": "h", "logic_change": "c" * 40}), bad)
    assert rep2.status == "needs_review" and clean(world)
