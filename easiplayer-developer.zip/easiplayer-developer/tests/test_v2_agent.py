"""V2 de bout en bout (LLM scripté, vrais dépôts git, VRAI clang-format avec le VRAI .clang-format du projet)."""
from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest

from conftest import CPP, CPP_OK, FIX, H, HEADER_OK, EditSet, FakeLLM, NewFile, e, git_out, plan_with, sh, with_files
from devagent.agent import DevAgent
from test_agent import branches, clean, wt

HAS_CF = shutil.which("clang-format") is not None


def with_style(world: Path) -> None:
    shutil.copy(FIX / "real.clang-format", world / "EasiPlayer" / ".clang-format")
    sh("git", "add", ".clang-format", cwd=world / "EasiPlayer")
    sh("git", "commit", "-qm", "style", cwd=world / "EasiPlayer")


async def run(cfg, plan, llm, **kw):
    return await DevAgent(cfg, llm).apply(plan, **kw)


# ---------------------------------------------------------------- conventions renvoyées au LLM
async def test_cxx14_is_fed_back_then_corrected(cfg, world, plan):
    bad = EditSet(summary="x", edits=[e("replace", "    emit finished(0);", "    auto p = std::make_unique<int>(0);\n    if (!m_aborted)\n        emit finished(0);")])
    llm = FakeLLM({H: HEADER_OK, CPP: [bad, CPP_OK]})
    rep = await run(cfg, plan, llm)
    assert rep.status == "applied" and rep.files[1].attempts == 2
    assert "cxx11_violation" in llm.prompts_for("edit", CPP)[1] and "make_unique" in llm.prompts_for("edit", CPP)[1]


async def test_modern_connect_is_rejected(cfg, world, plan):
    bad = EditSet(summary="x", edits=[e("insert_after", "    m_running = true;", "    connect(this, &Runner::finished, this, &Runner::abort);")])
    rep = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: bad}))
    assert rep.status == "needs_review" and "connect_modern_syntax" in rep.status_reason and clean(world)


async def test_qt_api_too_new_is_rejected(cfg, world, plan):
    bad = EditSet(summary="x", edits=[e("insert_after", "    m_running = true;", '    QStringList l = m_script.split(",", Qt::SkipEmptyParts);')])
    rep = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: bad}))
    assert rep.status == "needs_review" and "qt_api_too_new" in rep.status_reason


async def test_forbidden_zone_in_a_plan_is_refused_before_anything_happens(cfg, world, plan):
    p = with_files(plan, {"path": "EasiPlayer/redist/x.h", "change_type": "modify", "rationale": "r", "logic_change": "z" * 40})
    rep = await run(cfg, p, FakeLLM({}))
    assert rep.status == "rejected" and "zone interdite" in rep.status_reason and branches(world) == []


# ---------------------------------------------------------------- formatage des seules lignes modifiées
@pytest.mark.skipif(not HAS_CF, reason="clang-format absent")
async def test_clang_format_touches_only_the_changed_lines(cfg, world, plan):
    with_style(world)
    kr = EditSet(summary="x", edits=[e("replace", "    emit finished(0);", "    if (!m_aborted) {\n        emit finished(0);\n    }")])
    rep = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: kr}))
    assert rep.status == "applied", (rep.status_reason, [(f.path, [i.message for i in f.issues]) for f in rep.files])
    cpp = (wt(rep) / "core/runner.cpp").read_text()
    assert "    if (!m_aborted)\n    {\n        emit finished(0);\n    }\n" in cpp                       # K&R -> Allman
    assert "for (int i = 0; i < 10; ++i) {" in cpp                                                      # le code ancien (K&R) n'est PAS reformaté
    assert rep.meta["format"].get("formatted", 0) >= 1


@pytest.mark.skipif(not HAS_CF, reason="clang-format absent")
async def test_aligned_assignments_follow_the_project_style(cfg, world, plan):
    with_style(world)
    sh("bash", "-c", "printf '\\nvoid Runner::config()\\n{\\n    int timeout     = 1;\\n    int beforeDelay = 2;\\n}\\n' >> core/runner.cpp && git commit -qam cfg", cwd=world / "EasiPlayer")
    p = with_files(plan, {"path": CPP, "change_type": "modify", "symbols": ["Runner::config"], "line_hint": "",
                          "rationale": "r", "logic_change": "Add a third delay variable next to the other two inside config()."})
    ed = EditSet(summary="x", edits=[e("replace", "    int timeout     = 1;\n    int beforeDelay = 2;",
                                       "    int timeout     = 1;\n    int beforeDelay = 2;\n    int retryDelay = 3;")])
    rep = await run(cfg, p, FakeLLM({CPP: ed}))
    assert rep.status == "applied", rep.status_reason
    assert "    int timeout     = 1;\n    int beforeDelay = 2;\n    int retryDelay  = 3;\n" in (wt(rep) / "core/runner.cpp").read_text()    # `=` aligné par clang-format


async def test_missing_clang_format_is_reported_not_fatal(cfg, world, plan):
    with_style(world)
    cfg.clang_format_bin = "clang-format-does-not-exist"
    rep = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: CPP_OK}))
    assert rep.status == "applied" and any("format_skipped_no_binary" == i.code for f in rep.files for i in f.issues)


async def test_format_off(cfg, world, plan):
    with_style(world)
    cfg.format_mode = "off"
    rep = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: CPP_OK}))
    assert rep.status == "applied" and not rep.meta["format"].get("formatted")


# ---------------------------------------------------------------- commit, indices pour la suite de la chaîne, retour au Stratège
async def test_commit_follows_the_project_convention_and_hints_are_exposed(cfg, world, plan):
    p = plan_with(plan, ticket={**plan.ticket, "category": "Sequencer", "title": "[EAP 6.1.0] Stop button: finished reported twice"})
    rep = await run(cfg, p, FakeLLM({H: HEADER_OK, CPP: CPP_OK}), eap_ref="EAP-12610")
    assert rep.commit_subject == "[EAP-12610][Sequencer]Stop button: finished reported twice"
    assert git_out(wt(rep), "log", "-1", "--format=%s").strip() == rep.commit_subject
    assert not any(w.code == "commit_ref_missing" for w in rep.warnings) and rep.meta["commit_prefix"] == "[EAP-12610][Sequencer]"
    h = rep.build_hints
    assert h.changed_files == [H, CPP] and not h.needs_reconfigure
    assert h.build_targets == ["easicore"] and h.squish_tests == ["EasiPlayerSquishTests/suite_runner/tst_case1/test.js"]
    assert len(rep.meta["plan_sha256"]) == 64 and rep.meta["agent_version"] == "0.2.0"


async def test_missing_eap_reference_is_never_invented(cfg, world, plan):
    rep = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: CPP_OK}))
    assert rep.commit_subject.startswith("[EAP-TODO][General]") and any(w.code == "commit_ref_missing" for w in rep.warnings)
    assert any("EAP-TODO" in s for s in rep.next_steps)


async def test_feedback_for_strategist_when_the_plan_does_not_match(cfg, world, plan):
    na = EditSet(summary="", edits=[], cannot_apply="Runner::abort does not emit finished here.")
    rep = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: na}))
    fb = rep.feedback_for_strategist
    assert rep.status == "needs_review" and "CANNOT APPLY" in fb and "Runner::abort does not emit finished here." in fb and CPP in fb and "nothing was written" in fb
    assert json.loads(rep.model_dump_json())["feedback_for_strategist"] == fb


async def test_restart_replaces_a_previous_attempt(cfg, world, plan):
    r1 = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: CPP_OK}))
    assert r1.status == "applied"
    r2 = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: CPP_OK}))
    assert r2.status == "rejected" and "déjà présent" in r2.status_reason                      # sans restart : refus explicite
    r3 = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: CPP_OK}), restart=True)
    assert r3.status == "applied" and [b for b in branches(world) if b not in "+*"] == ["agent/D0002312"]                  # l'ancienne branche a été remplacée, pas dupliquée


# ---------------------------------------------------------------- suppression de fichier (--allow-remove) et fichiers non C++
async def test_file_removal_is_really_executed_when_allowed(cfg, world, plan):
    cfg.allow_remove = True
    p = with_files(plan, {"path": "EasiPlayer/core/dbusconst.h", "change_type": "remove", "rationale": "obsolete", "logic_change": "Delete the obsolete header, nothing includes it. " * 2})
    rep = await run(cfg, p, FakeLLM({}))
    assert rep.status == "applied", rep.status_reason
    assert not (wt(rep) / "core/dbusconst.h").exists() and (world / "EasiPlayer/core/dbusconst.h").exists()      # supprimé dans le worktree seulement
    assert "deleted file mode" in rep.diff and rep.build_hints.needs_reconfigure


async def test_ui_file_is_edited_and_kept_well_formed(cfg, world, plan):
    ui = world / "EasiPlayer/ui/main.ui"
    ui.write_text('<?xml version="1.0" encoding="UTF-8"?>\n<ui version="4.0">\n <widget class="QPushButton" name="mRunBt">\n  <property name="text">\n   <string>Run</string>\n  </property>\n </widget>\n</ui>\n')
    sh("git", "add", "-A", cwd=world / "EasiPlayer")
    sh("git", "commit", "-qm", "ui", cwd=world / "EasiPlayer")
    p = with_files(plan, {"path": "EasiPlayer/ui/main.ui", "change_type": "modify", "symbols": ["mRunBt"], "line_hint": "",
                          "rationale": "r", "logic_change": "Rename the button label from Run to Start in the form."})
    good = EditSet(summary="x", edits=[e("replace", "   <string>Run</string>", "   <string>Start</string>")])
    bad = EditSet(summary="x", edits=[e("replace", "   <string>Run</string>", "   <string>Start & go</string>")])
    llm = FakeLLM({"EasiPlayer/ui/main.ui": [bad, good]})
    rep = await run(cfg, p, llm)
    assert rep.status == "applied" and "xml_not_well_formed" in llm.prompts_for("edit", "EasiPlayer/ui/main.ui")[1]
    assert "<string>Start</string>" in (wt(rep) / "ui/main.ui").read_text()


# ---------------------------------------------------------------- politique git : branches LOCALES partant de `development`, jamais de push ni de merge
async def test_branch_starts_from_development_and_nothing_leaves_the_machine(cfg, world, plan, tmp_path):
    repo = world / "EasiPlayer"
    sh("git", "branch", "-M", "main", cwd=repo)
    sh("git", "checkout", "-qb", "development", cwd=repo)
    (repo / "core" / "notes.txt").write_text("work on development\n")
    sh("git", "add", "-A", cwd=repo)
    sh("git", "commit", "-qm", "development work", cwd=repo)
    dev_sha = git_out(repo, "rev-parse", "development").strip()
    main_sha = git_out(repo, "rev-parse", "main").strip()
    remote = tmp_path / "origin.git"
    sh("git", "init", "-q", "--bare", str(remote), cwd=tmp_path)
    sh("git", "remote", "add", "origin", str(remote), cwd=repo)
    sh("git", "checkout", "-q", "main", cwd=repo)                          # l'utilisateur est sur une autre branche : l'agent ne la touche pas
    cfg.base_ref = "development"
    rep = await run(cfg, plan, FakeLLM({H: HEADER_OK, CPP: CPP_OK}))
    assert rep.status == "applied"
    assert git_out(repo, "merge-base", "--is-ancestor", dev_sha, rep.branches["EasiPlayer"]) == ""            # la branche du ticket descend de `development`
    assert (wt(rep) / "core/notes.txt").exists()
    assert git_out(repo, "rev-parse", "development").strip() == dev_sha and git_out(repo, "rev-parse", "main").strip() == main_sha   # rien n'est fusionné
    assert git_out(repo, "branch", "--show-current").strip() == "main"
    assert git_out(tmp_path, "-C", str(remote), "for-each-ref").strip() == ""                                  # rien n'a été poussé
